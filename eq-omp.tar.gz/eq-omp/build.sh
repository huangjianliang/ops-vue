#!/bin/bash

version="2.0"
rm -rf dist
npm run build

_date=$(date +%Y%m%d%H%M)
tag="${version}-${_date}"

sudo docker build -t registry.eqfleetcmder.com/eq/ops/omp:$tag -f docker/Dockerfile .
sudo docker push registry.eqfleetcmder.com/eq/ops/omp:$tag

echo "registry.eqfleetcmder.com/eq/ops/omp:$tag"
