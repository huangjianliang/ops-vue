import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { resolve } from 'path';
import { createHtmlPlugin } from "vite-plugin-html";

export default defineConfig({
    resolve: {
        alias: {
            "@": resolve(__dirname, "./src")
        }
    },
    css: {
        preprocessorOptions: {
            scss: {
                // additionalData: `@import "@/styles/global.scss"`
            }
        }
    },
    plugins: [
        vue(),
        createHtmlPlugin({
			inject: {
				data: {
					title: '运维管理平台'
				}
			}
		}),
    ],
    server: {
        host: "0.0.0.0",
        port: '3000',
        open: true,
        cors: true,
        proxy: {
            // "/eqq": {
            //     target: "http://ops.eacon.com", 
            //     // target: "http://10.10.85.156:8813",
			// 	changeOrigin: true,
			// 	rewrite: path => path.replace(/^\/eqq/, "")
            // },
            "/eqq": {
                target: "http://10.10.85.156:8816", 
				changeOrigin: true,
				rewrite: path => path.replace(/^\/eqq/, "")
            }
        }
    },
    esbuild: {
		pure: ["console.log", "debugger"] 
	},
	build: {
		outDir: "dist",
		minify: "esbuild",
		rollupOptions: {
			output: {
				chunkFileNames: "assets/js/[name]-[hash].js",
				entryFileNames: "assets/js/[name]-[hash].js",
				assetFileNames: "assets/[ext]/[name]-[hash].[ext]"
			}
		}
	}
})
