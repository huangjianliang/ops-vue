// 全局地址配置
window.config = {
	// 后端服务地址
	API_URL: "https://ops.eacon.com",
	// 日志websocket地址
	WS_LOG_URL: "wss://ops.eacon.com/logger/tail",
	// 日志下载帮助文档地址
	HELP_FILE_URL:
		"https://yikongzhijia.feishu.cn/wiki/wikcnYHyhRvHp9jhlYXucrVzIok",
	// 车辆网络实时地址
	WS_TRUNK_URL: "wss://ops.eacon.com/monitor/vehicle/trunk/network/realtime/ws",

	// 环境地图
	ENV_LAT_LNGS: {
		azc: [[35.26208543, 116.98313055], 17],
		nlt: [[44.80992638, 89.21981110], 14],
		zdk: [[44.82520268055628, 89.13135051727295], 14],
		jer: [[44.65716103, 90.15041918], 14],
		hlh: [[44.80357667797159, 89.10627408202889], 14],
	},

	// 车辆网络指标
	datatypeOptions: [
		{
			index: 0,
			name: "signal",
			label: "基站信号",
			min: -95,
			max: -80,
			unit: "dBm",
		},
		{ index: 1, name: "ping", label: "ping延时", min: 15, max: 80, unit: "ms" },
	],
};
