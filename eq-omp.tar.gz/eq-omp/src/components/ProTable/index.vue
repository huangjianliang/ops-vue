

<template>
    <!-- 查询表单 -->
    <SearchForm :addShow="addShow" :add="add" :search="search" :searchLabel="searchLabel" :resetLabel="resetLabel" :selectedListIds="selectedListIds"
        :selectList="selectedList" :isSelected="isSelected" :button_props="props.button_props" :reset="reset"
        :searchParam="searchParam" :columns="searchColumns" v-show="isShowSearch" :changeTableEnum="changeTableEnum" />
    <div class="card table">
        <!-- 表格头部 操作按钮 -->
        <div class="table-header">
            <div class="header-button-lf">
                <el-button v-if="isSelected" type="primary" :icon="button_props.icon"
                    @click="button_action(searchParam, selectedList)">
                    {{ button_props.label }}
                </el-button>
            </div>
        </div>
        <!-- 表格主体 -->
        <el-table ref="tableRef" :data="tableData" :border="border" @selection-change="selectionChange"
            :row-key="getRowKeys" :stripe="stripe" :tree-props="{ children: childrenName }">
            <template v-for="item in tableColumns" :key="item">
                <!-- selection || index -->
                <el-table-column v-if="item.type == 'selection' || item.type == 'index'" :type="item.type"
                    :reserve-selection="item.type == 'selection'" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :fixed="item.fixed">
                    <template #default="scope" v-if="item.type === 'index'">
                        {{ (pageable.pageSize * (pageable.pageNum - 1)) + scope.$index + 1 }}
                    </template>
                </el-table-column>
                <el-table-column v-if="item.type === 'link'" :type="item.type" :reserve-selection="item.type == 'selection'"
                    :label="item.label" :width="item.width" :min-width="item.minWidth" :fixed="item.fixed">
                    <!-- <template slot-scope="scope"> -->
                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <span>
                                <el-link type="primary" :href="scope.row[item.prop]" :underline="false" target="_blank">{{
                                    item.label }}</el-link>
                            </span>
                        </slot>
                    </template>
                    <!-- </template> -->
                </el-table-column>
                <el-table-column v-if="item.type === 'button'" :type="item.type"
                    :reserve-selection="item.type == 'selection'" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :fixed="item.fixed">
                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <span>
                                <el-button type="primary" :disabled="(!scope.row[item.prop])"
                                    @click="item.action(scope.row)">{{ item.label }}</el-button>
                            </span>
                        </slot>
                    </template>
                </el-table-column>

                <el-table-column v-if="item.type === 'rtkbutton'" :type="item.type"
                    :reserve-selection="item.type == 'selection'" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :fixed="item.fixed">
                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <span>
                                <el-popconfirm :title="'切换到 ' + scope.row['rtkId'] + ' 号基站'" @confirm="item.action(scope.row)">
                                    <template #reference>
                                    <el-button type="primary" :disabled="(scope.row['status'] != '1' || scope.row['enableStatus'] == '1')">{{ item.label }}</el-button>
                                    </template>
                                </el-popconfirm>
                            </span>
                        </slot>
                    </template>
                </el-table-column>

                <el-table-column v-if="item.type === 'appbutton'" :type="item.type"
                    :reserve-selection="item.type == 'selection'" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :fixed="item.fixed">
                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <el-dropdown>
                                <el-button :type="item.btType" :disabled="(!scope.row[item.prop])">
                                    {{ item.label }}
                                    <el-icon class="el-icon--right"><arrow-down /></el-icon>
                                </el-button>
                                <template #dropdown>
                                    <el-dropdown-menu>
                                        <el-dropdown-item @click="item.action(scope.row, 'start')"><el-icon>
                                                <Sunny />
                                            </el-icon>启动</el-dropdown-item>
                                        <el-dropdown-item @click="item.action(scope.row, 'reload')"><el-icon>
                                                <Cloudy />
                                            </el-icon>重启</el-dropdown-item>
                                        <el-dropdown-item @click="item.action(scope.row, 'stop')" divided><el-icon>
                                                <Sunset />
                                            </el-icon>停止</el-dropdown-item>
                                    </el-dropdown-menu>
                                </template>
                            </el-dropdown>
                        </slot>
                    </template>
                </el-table-column>

                <el-table-column v-if="item.type === 'color'" :prop="item.prop" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :sortable="item.sortable" :show-overflow-tooltip="item.prop !== 'operation'"
                    :resizable="true" :fixed="item.fixed">

                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <span
                                v-if="scope.row[item.prop] == 'online' || scope.row['is_running'] || scope.row[item.prop] == 'SUCCESS'"
                                style="color: green;">
                                {{ scope.row[item.prop] }}
                            </span>
                            <span v-else style="color: red;">
                                {{ scope.row[item.prop] }}
                            </span>
                        </slot>
                    </template>

                </el-table-column>

                <el-table-column v-if="item.type === 'status'" :prop="item.prop" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :sortable="item.sortable" :show-overflow-tooltip="item.prop !== 'operation'"
                    :resizable="true" :fixed="item.fixed">

                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <span
                                v-if="scope.row[item.prop] == '1'"
                                style="color: green;">
                                {{item.truelabel}}
                            </span>
                            <span v-else style="color: red;">
                                {{item.falselabel}}
                            </span>
                        </slot>
                    </template>

                </el-table-column>


                <el-table-column v-if="item.type === 'jenkins_status'" :prop="item.prop" :label="item.label"
                    :width="item.width" :min-width="item.minWidth" :sortable="item.sortable"
                    :show-overflow-tooltip="item.prop !== 'operation'" :resizable="true" :fixed="item.fixed">

                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <span v-if="scope.row['building']" style="color: red;">
                                执行中
                            </span>
                            <span v-else style="color: green;">
                                已完成
                            </span>
                        </slot>
                    </template>

                </el-table-column>

                <!-- expand（展开自定义详细信息，请使用作用域插槽） -->
                <el-table-column v-if="item.type == 'expand'" :type="item.type" :label="item.label" :width="item.width"
                    :min-width="item.minWidth" :fixed="item.fixed" v-slot="scope">
                    <slot :name="item.type" :row="scope.row"></slot>
                </el-table-column>
                <!-- other -->
                <el-table-column v-if="!item.type && item.prop && item.isShow" :prop="item.prop" :label="item.label"
                    :width="item.width" :min-width="item.minWidth" :sortable="item.sortable"
                    :show-overflow-tooltip="item.prop !== 'operation'" :resizable="true" :fixed="item.fixed">
                    <!-- 自定义 header (使用组件渲染 tsx 语法) -->
                    <template #header v-if="item.renderHeader">
                        <component :is="item.renderHeader" :row="item"> </component>
                    </template>

                    <!-- 自定义配置每一列 slot（使用作用域插槽） -->
                    <template #default="scope">
                        <slot :name="item.prop" :row="scope.row">
                            <!-- tag 标签（自带格式化内容） -->
                            <el-tag v-if="item.tag"
                                :type="filterEnum(scope.row[item.prop], item.enum, item.searchProps, 'tag')">
                                {{
                                    item.enum?.length
                                    ? filterEnum(scope.row[item.prop], item.enum, item.searchProps)
                                    : formatValue(scope.row[item.prop])
                                }}
                            </el-tag>
                            <!-- 文字（自带格式化内容） -->
                            <span v-else   >
                                <!-- {{
									item.enum?.length
										? filterEnum(scope.row[item.prop], item.enum, item.searchProps)
											: formatValue(scope.row[item.prop])
									}} -->
                                <!-- <el-button v-if="item.clip" @click="clip(scope.row[item.prop])"  :icon="CopyDocument" size="small" circle round/> -->
                                <!-- {{ scope.row[item.prop] }} -->
                                
                                <span v-if="item.clip" class="clipSpan" @click="clip(scope.row[item.prop])">{{ scope.row[item.prop] }}</span>
                                <span v-else>{{ scope.row[item.prop] }}</span>
                            </span>
                        </slot>
                    </template>
                </el-table-column>
            </template>
            <template #empty>
                <div class="table-empty">
                    <img src="@/assets/images/notData.png" alt="notData" />
                    <div>暂无数据</div>
                </div>
            </template>
        </el-table>
        <!-- 分页组件 -->
        <Pagination v-if="pagination" :pageable="pageable" :handleSizeChange="handleSizeChange"
            :handleCurrentChange="handleCurrentChange" />
    </div>
</template>

<script setup>
import { ref, watch } from "vue";
import { useTable } from "@/hooks/useTable";
import { useSelection } from "@/hooks/useSelection";
import { filterEnum, formatValue } from "@/utils/util";
import SearchForm from "@/components/SearchForm/index.vue";
import Pagination from "./components/Pagination.vue";
import { CopyDocument } from '@element-plus/icons-vue'
import useClipboard from 'vue-clipboard3';
import { ElMessage } from 'element-plus';

// 表格 DOM 元素
const tableRef = ref();

// 是否显示搜索模块
const isShowSearch = ref(true);

const props = defineProps({
    columns: {
        type: Array,
        default: () => []
    },
    pagination: {
        type: Boolean,
        default: true
    },
    initParam: {
        type: Object,
        default: () => { }
    },
    border: {
        type: Boolean,
        default: true
    },
    stripe: {
        type: Boolean,
        default: false
    },
    toolButton: {
        type: Boolean,
        default: true
    },
    childrenName: {
        type: String,
        default: "children"
    },
    selectId: {
        type: String,
        default: "id"
    },
    requestApi: {
        type: Function
    },
    button_props: {
        type: Object,
        default: () => { }
    },
    button_action: {
        type: Function
    },
    searchLabel: {
        type: String,
        default: '搜索'
    },
    resetLabel: {
        type: String,
        default: '重置'
    },
    add: {
        type: Function
    },
    addShow: {
        type: Boolean,
        default: false
    }
});

// 表格多选 Hooks
const { selectionChange, getRowKeys, selectedList, selectedListIds, isSelected } = useSelection(props.selectId);

// 表格操作 Hooks
const { tableData, pageable, searchParam, searchInitParam, getTableList, search, reset, handleSizeChange, handleCurrentChange } =
    useTable(props.requestApi, props.initParam, props.pagination, props.dataCallback);

// 监听页面 initParam 改化，重新获取表格数据
watch(() => props.initParam, () => {
    getTableList();
},
    { deep: true }
);

// 表格列配置项处理（添加 isShow 属性，控制显示/隐藏）
const tableColumns = ref();

tableColumns.value = props.columns.map(item => {
    return {
        ...item,
        isShow: item.isShow ?? true
    };
});

// 如果当前 enum 为后台数据 需要请求数据，则调用该请求接口，获取enum数据
tableColumns.value.forEach(async item => {
    if (item.enum && typeof item.enum === "function") {
        const { data } = await item.enum();
        if (data) {
            item.enum = data;
        } else {
            item.enum = [];
        }
    }
});

// 过滤需要搜索的配置项
const searchColumns = tableColumns.value.filter(item => item.search);

// 设置搜索表单的默认值
searchColumns.forEach(column => {
    if (column.searchInitParam !== undefined && column.searchInitParam !== null) {
        searchInitParam.value[column.prop] = column.searchInitParam;
    }
});

const changeTableEnum = (prop, options) => {
    const index = tableColumns.value.findIndex(item => {
        return item.prop === prop;
    });
    if (index === -1) return;
    tableColumns.value[index].enum = options;
};

const clip = (msg) => {
    const { toClipboard } = useClipboard()
    toClipboard(msg);
    ElMessage.success('复制成功！');
};

// 暴露给父组件的参数和方法
defineExpose({ searchParam, getTableList });

</script>
