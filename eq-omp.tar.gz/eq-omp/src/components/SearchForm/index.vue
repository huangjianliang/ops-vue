<template>
	<div class="card table-search" v-if="columns.length">
		<el-form ref="formRef" :model="searchParam" :inline="true">
			<template v-for="item in getSearchList" :key="item.prop">
				<el-form-item :label="item.label">
					<SearchFormItem :item="item" :searchParam="searchParam" :changeTableEnum="changeTableEnum"/>
				</el-form-item>
			</template>
		</el-form>
		<div class="search-operation">
			<el-button type="primary" v-if="addShow" @click="add">新增</el-button>
			<el-button type="primary" @click="search">{{searchLabel}}</el-button>
			<el-button type="warning" @click="reset">{{resetLabel}}</el-button>
			<el-button type="primary" link class="search-isOpen" @click="searchShow = !searchShow" v-if="columns.length > maxLength">
				{{ searchShow ? "合并" : "展开" }}
				<el-icon class="el-icon--right">
					<component :is="searchShow ? ArrowUp : ArrowDown"></component>
				</el-icon>
			</el-button>
		</div>
	</div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import SearchFormItem from "./components/SearchFormItem.vue";
import { Delete, Search, ArrowDown, ArrowUp } from "@element-plus/icons-vue";

// 支持自定义 button
//const default_button_props = {
//	isShow: false,
//	icon : "",
//	click_action: "",
//	label: ""
//}

const props = defineProps({
	columns: {
		type: Array,
		default: () => []
	},
	searchParam: {
		type: Object,
		default: () => {}
	},
	add: {
		type: Function
	},
	addShow: {
		type: Boolean,
		default: false
	},
	search: {
		type: Function
	},
	reset: {
		type: Function
	},
	changeTableEnum: {
		type: Function
	},
	searchLabel:{
		type: String,
		default: '确定'
	},
	resetLabel:{
		type: String,
		default: '搜索'
	},
});

const maxLength = ref(4);

onMounted(() => {
	if (props.columns.length >= 4) {
		const searchTypeArr = ["datetimerange", "daterange"];
		searchTypeArr.includes(props.columns[3].searchType) ? (maxLength.value = 3) : null;
		props.columns.slice(0, 3).forEach(item => {
			searchTypeArr.includes(item.searchType) ? (maxLength.value = 3) : null;
		});
	}
});

// 是否展开搜索项
const searchShow = ref(false);

// 根据是否展开配置搜索项长度
const getSearchList = computed(() => {
	if (searchShow.value) return props.columns;
	return props.columns.slice(0, maxLength.value);
});

</script>
