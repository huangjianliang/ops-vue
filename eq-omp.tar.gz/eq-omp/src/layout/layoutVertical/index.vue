<!-- 纵向布局 -->
<template>
	<el-container class="layout-vertical">
		<el-aside>
			<div class="menu" :style="{ width: isCollapse ? '65px' : '220px' }">
				<div class="logo flx-center">
					<img src="@/assets/images/logo1.png" alt="logo" />
					<span v-show="!isCollapse">运维管理平台</span>
				</div>
				<el-scrollbar>
					<el-menu
						:default-active="activeMenu"
						:router="false"
						:collapse="isCollapse"
						:collapse-transition="false"
						:unique-opened="false"
						:default-openeds="defaultOpeneds"
						background-color="#191a20"
						text-color="#bdbdc0"
						active-text-color="#ffffff"
					>
						<SubMenu :menuList="menuList" />
					</el-menu>
				</el-scrollbar>
			</div>
		</el-aside>
		<el-container>
			<el-header>
				<ToolBarLeft />
				<ToolBarRight />
			</el-header>
			<MainCom /> 
		</el-container>
	</el-container>
</template>

<script setup name="layoutVertical">
import { computed, ref } from "vue";
import { useRoute } from "vue-router";
import { useMenuStore } from "@/store/modules/menu";

import MainCom from "@/layout/components/Main/index.vue";
import ToolBarLeft from "@/layout/components/Header/ToolBarLeft.vue";
import ToolBarRight from "@/layout/components/Header/ToolBarRight.vue";
import SubMenu from "@/layout/components/Menu/SubMenu.vue";

const route = useRoute();
const menuStore = useMenuStore();

const activeMenu = computed(() => route.path);
const menuList = computed(() => menuStore.menuList);
const isCollapse = computed(() => menuStore.isCollapse);

const defaultOpeneds = ref(['/releaseCenter', '/applyCenter', '/trunkCenter', '/midCenter', '/configCenter']);

</script>

<style scoped lang="scss">
@import "./index.scss";
</style>

<style lang="scss">
.vertical {
	.el-menu,
	.el-menu--popup {
		.el-menu-item {
			&.is-active {
				background: #060708;
				&::before {
					position: absolute;
					top: 0;
					bottom: 0;
					left: 0;
					width: 4px;
					content: "";
					background: var(--el-color-primary);
				}
			}
		}
	}
}
</style>
