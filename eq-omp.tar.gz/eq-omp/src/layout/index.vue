<template>
    <LayoutVertical />
</template>

<script setup>
import { onMounted } from 'vue';
// import { useAuthStore } from '@/store/modules/auth';
import { useMenuStore } from '@/store/modules/menu';
// import { getAuthButtons, getAuthMenu } from '@/api/modules/login';
import { menuList } from '@/config/menuList';

import LayoutVertical from './layoutVertical/index.vue';

// const authStore = useAuthStore();
const menuStore = useMenuStore();

onMounted(() => {
    // getAuthButtonsList();
	getMenuList();
});

// 获取按钮权限列表
// const getAuthButtonsList = async () => {
// 	const { data } = await getAuthButtons();
// 	data && authStore.setAuthButtons(data);
// };

// 获取菜单列表中
const getMenuList = async () => {
	// const { data } = await getAuthMenu();
	// const data = menuList;
	
	// 把路由菜单处理成一维数组（存储到 pinia ）
	// data && authStore.setAuthRouter(handleRouter(data));
	menuStore.setMenuList(menuList);
};
</script>

<style lang="scss" scoped>

</style>