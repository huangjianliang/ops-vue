<template>
	<div class="breadcrumb-box">
		<el-breadcrumb :separator-icon="ArrowRight">
			<transition-group name="breadcrumb" mode="out-in">
				<!-- <el-breadcrumb-item :to="{ path: HOME_URL }" key="/home" class="homeTab">首页</el-breadcrumb-item> -->
				<el-breadcrumb-item v-for="item in matched" :key="item.path" :to="{ path: item.path }">
					<i :class="['iconfont tabIcon', `icon-${item.meta.icon}`]"></i>
					<span class="breadcrumb-title">{{ item.meta.title }}</span>
				</el-breadcrumb-item>
			</transition-group>
		</el-breadcrumb>
	</div>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { useRoute } from "vue-router";
import { ArrowRight } from "@element-plus/icons-vue";
import { HOME_URL } from "@/config/config.js";
const route = useRoute();

const matched = computed(() => {
	const data = route.matched.filter(item => item.meta && item.meta.title && item.meta.title !== "首页");
	console.log('data', { path: HOME_URL, meta: { icon: "shouye", title: "首页" } }, ...data);
	return [{ path: HOME_URL, meta: { icon: "shouye", title: "首页" } }, ...data];
});

</script>

<style scoped lang="scss">
.breadcrumb-box {
	display: flex;
	align-items: center;
	padding-right: 50px;
	overflow: hidden;
	mask-image: linear-gradient(90deg, #000000 0%, #000000 calc(100% - 50px), transparent);
	.el-breadcrumb {
		white-space: nowrap;
		.homeTab{
			display: inline-block;
			padding-bottom: 2px;
		}
		.el-breadcrumb__item {
			position: relative;
			display: inline-block;
			float: none;
			:deep(.el-breadcrumb__inner) {
				display: inline-flex;
				.breadcrumb-icon {
					display: inline-block;
					margin-top: 2px;
					margin-right: 6px;
					font-size: 16px;
				}
				.tabIcon{
				    font-size: 16px;
				    display: inline-block;
				    margin-right: 5px;
				}
				.breadcrumb-title {
					margin-top: 2px;
				}
			}
			:deep(.el-breadcrumb__separator) {
				position: relative;
				top: 2px;
			}
		}
	}
}
.no-icon {
	.el-breadcrumb {
		.el-breadcrumb__item {
			top: -2px;
			:deep(.el-breadcrumb__separator) {
				top: 2px;
			}
		}
	}
}
</style>
