<template>
	<div class="fullscreen">
		<i :class="['iconfont', isFullscreen ? 'icon-fullscreen-shrink' : 'icon-fullscreen-expand']" class="toolBar-icon" @click="toggle"></i>
	</div>
</template>

<script setup>

import { useFullscreen } from "@vueuse/core";
const { toggle, isFullscreen } = useFullscreen();

</script>

<style scoped lang="scss">
    i{
	    cursor: pointer;
	    font-weight: 600;
	}
</style>
