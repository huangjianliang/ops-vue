<template>
	<div class="tool-bar-ri">
		<div class="header-icon">
			<SearchMenu id="searchMenu" />
			<Fullscreen id="fullscreen" />
		</div>
		<span class="username">{{userName}}</span>
		<Avatar />
	</div>
</template>

<script setup>
import { computed } from 'vue';

import SearchMenu from "./components/SearchMenu.vue";
import Fullscreen from "./components/Fullscreen.vue";
import Avatar from "./components/Avatar.vue";
import { useGlobalStore } from "../../../store";

const globalStore = useGlobalStore();

const userName = computed(() => {
	return globalStore.userInfo.cn_name;
});

</script>

<style scoped lang="scss">
.tool-bar-ri {
	display: flex;
	align-items: center;
	justify-content: center;
	margin: 0 30px;
	.header-icon {
		display: flex;
		align-items: center;
		justify-content: space-between;
		// width: 230px;
		// margin-right: 22px;
	}
	.username {
		margin: 0 20px 0 0;
		font-size: 15px;
	}
}
</style>
