<template>
	<el-dropdown trigger="click">
		<el-button size="small" type="primary">
			<span>更多</span>
			<el-icon class="el-icon--right"><arrow-down /></el-icon>
		</el-button>
		<template #dropdown>
			<el-dropdown-menu>
				<el-dropdown-item @click="refresh">
					<el-icon><Refresh /></el-icon>刷新
				</el-dropdown-item>
				<el-dropdown-item @click="closeCurrentTab">
					<el-icon><Remove /></el-icon>关闭当前
				</el-dropdown-item>
				<el-dropdown-item @click="closeOtherTab">
					<el-icon><CircleClose /></el-icon>关闭其它
				</el-dropdown-item>
				<el-dropdown-item @click="closeAllTab">
					<el-icon><Delete /></el-icon>关闭所有
				</el-dropdown-item>
			</el-dropdown-menu>
		</template>
	</el-dropdown>
</template>

<script setup lang="ts">
import { inject } from "vue";
import { useTabsStore } from "@/store/modules/tabs";
import { HOME_URL } from "@/config/config";
import { ElMessage } from "element-plus";

const tabStore = useTabsStore();
const reload = inject("refresh");

// 刷新当前页面
const refresh = () => {
	ElMessage({ type: "success", message: "刷新当前页面 🚀" });
	reload();
};

// 关闭当前页面
const closeCurrentTab = () => {
	if (tabStore.tabsMenuValue === HOME_URL) return;
	tabStore.removeTabs(tabStore.tabsMenuValue);
};

// 关闭其它页面
const closeOtherTab = () => {
	tabStore.closeMultipleTab(tabStore.tabsMenuValue);
};

// 关闭所有页面
const closeAllTab = () => {
	tabStore.closeMultipleTab();
	tabStore.goHome();
};
</script>

<style scoped lang="scss">
@import "../index.scss";
</style>
