<template>
	<div class="tabs-box">
		<div class="tabs-menu">
			<el-tabs v-model="tabsMenuValue" type="card" @tab-click="tabClick" @tab-remove="removeTab">
				<el-tab-pane
					v-for="item in tabsMenuList"
					:key="item.path"
					:path="item.path"
					:label="item.title"
					:name="item.path"
					:closable="item.close"
				>
					<template #label>
						<i :class="['iconfont tabIcon', `icon-${item.icon === 'home-filled' ? 'shouye' : item.icon}`]"></i>
						{{ item.title }}
					</template>
				</el-tab-pane>
			</el-tabs>
			<MoreButton />
		</div>
	</div>
</template>

<script setup lang="ts">
import { computed, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useTabsStore } from "@/store/modules/tabs";
import MoreButton from "./components/MoreButton.vue";

const tabStore = useTabsStore();

const tabsMenuList = computed(() => tabStore.tabsMenuList);

const tabsMenuValue = computed({
	get: () => {
		return tabStore.tabsMenuValue;
	},
	set: val => {
		tabStore.setTabsMenuValue(val);
	}
});

const route = useRoute();
const router = useRouter();

// 监听路由的变化（防止浏览器后退/前进不变化 tabsMenuValue）
watch(
	() => route.path,
	() => {
		let params = {
			title: route.meta.title,
			path: route.path,
			close: true,
			icon: route.meta.icon
		};
		tabStore.addTabs(params);
	},
	{
		immediate: true
	}
);

// tab 点击事件
const tabClick = (tabItem) => {
	let path = tabItem.props.name;
	router.push(path);
};

// 移除tab
const removeTab = (activeTabPath: string) => {
	tabStore.removeTabs(activeTabPath);
};

</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
