<template>
	<div class="footer flx-center">
		<a href="https://www.eq.com/" target="_blank">北京易控智驾科技有限公司  邮箱：hr@eacon.com  电话：010-62575785 北京总部-北京市海淀区中关村东路8号东升大厦B座701-B室</a>
	</div>
</template>

<style scoped lang="scss">
@import "./index.scss";
</style>
