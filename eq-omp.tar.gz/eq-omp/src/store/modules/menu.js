import { defineStore } from 'pinia';
import piniaPersistConfig from '../../config/piniaPersist';

export const useMenuStore = defineStore('menuState', {
    state: () => ({
        isCollapse: false,
        menuList: []
    }),
    getters: {},
    actions: {
        async setCollapse () {
            this.isCollapse = !this.isCollapse;
        },
        async setMenuList(menuList) {
            this.menuList = menuList;
        }
    },
    persist: piniaPersistConfig('menuState')
});