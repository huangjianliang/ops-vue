import { defineStore } from 'pinia';
import piniaPersistConfig from '../../config/piniaPersist';

export const useAuthStore = defineStore('authState',{
    state: () => ({
        // 用户按钮权限列表
        authButtons: {},
        // 路由权限列表
        authRouter: []
    }),
    getters: {
    
    },
    actions: {
        setAuthButtons (val) {
            this.authButtons = val;
        },
        setAuthRouter (val) {
            this.authRouter = val;
        }
    },
    persist: piniaPersistConfig('authState')
});