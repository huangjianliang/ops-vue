import { defineStore } from 'pinia';

export const useTrunkCenterStore = defineStore('trunkCenterState', {
    state: () => ({
        monitorType: 0,         // 车辆监听类型  0: 基站信号 1: ping延时
        historyDatas: [],       // 车辆历史数据
        realTimeDatas: [],      // 车辆实时数据
    }),
    getters: {
    },
    actions: {
        setMonitorType (type) {
            this.monitorType = type;
        },
        setRealTimeDatas (datas) {
            this.realTimeDatas = datas;
        },
    }
});