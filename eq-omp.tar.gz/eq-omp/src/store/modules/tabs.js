import { defineStore } from "pinia";

import piniaPersistConfig from "@/config/piniaPersist";
import router from "@/router/index";
import { HOME_URL, TABS_WHITE_LIST } from "@/config/config";

export const useTabsStore = defineStore('tabsState',{
    state: () => ({
        tabsMenuValue: HOME_URL,
        tabsMenuList: [{ title: "首页", path: HOME_URL, icon: "shouye", close: false }]
    }),
    getters: {},
    actions: {
		// 添加tab
		async addTabs(tabItem) {
			// 排除白名单中的tab
			if (TABS_WHITE_LIST.includes(tabItem.path)) return;
			const tabInfo = {
				title: tabItem.title,
				path: tabItem.path,
				close: tabItem.close,
				icon: tabItem.icon
			};
			if (this.tabsMenuList.every(item => item.path !== tabItem.path)) {
				this.tabsMenuList.push(tabInfo);
			}
			this.setTabsMenuValue(tabItem.path);
		},
		
		// 移除当前tab
		async removeTabs(tabPath) {
			let tabsMenuValue = this.tabsMenuValue;
			const tabsMenuList = this.tabsMenuList;
			if (tabsMenuValue === tabPath) {
				tabsMenuList.forEach((item, index) => {
					if (item.path !== tabPath) return;
					const nextTab = tabsMenuList[index + 1] || tabsMenuList[index - 1];
					if (!nextTab) return;
					tabsMenuValue = nextTab.path;
					router.push(nextTab.path);
				});
			}
			this.tabsMenuValue = tabsMenuValue;
			this.tabsMenuList = tabsMenuList.filter(item => item.path !== tabPath);
		},
		
		// 修改当前tab
		async changeTabs(tabItem) {
			this.tabsMenuList.forEach(item => {
				if (item.title === tabItem.label) router.push(item.path);
			});
		},
		
		// 设置当前tab
		async setTabsMenuValue(tabsMenuValue) {
			this.tabsMenuValue = tabsMenuValue;
		},
		
		// 设置tab列表
		async setTabsMenuList(tabsMenuList) {
			this.tabsMenuList = tabsMenuList;
		},
		
		// 关闭多个tab
		async closeMultipleTab(tabsMenuValue) {
			this.tabsMenuList = this.tabsMenuList.filter(item => {
				return item.path === tabsMenuValue || item.path === HOME_URL;
			});
		},
		
		// 回到首页
		async goHome() {
			router.push(HOME_URL);
			this.tabsMenuValue = HOME_URL;
		}
	},
	persist: piniaPersistConfig("tabsState")
});