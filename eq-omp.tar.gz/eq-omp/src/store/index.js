import { createPinia, defineStore } from 'pinia';
import piniaPluginPersistedstate from "pinia-plugin-persistedstate";

import piniaPersistConfig from '@/config/piniaPersist';

// defineStore 调用后返回一个函数, 调用该函数获得store实体
export const useGlobalStore = defineStore('globalState', {
    state: () => ({
        token: "",          // 用户token
        userInfo: {},       // 用户信息
        themeConfig: {  
            // 深色模式  
            isDark: false,  
            // 面包屑导航 
			breadcrumb: true,   
            // 标签页
			tabs: true,   
            // 页脚
			footer: true  
        }
    }) ,
    getters: {
        userName: (state) => {
            return state.userInfo?.user_name;
        }
    },
    actions: {
        setToken(val){
            this.token = val;
        },
        setUserInfo(val){
            this.userInfo = val;
        }
    },
    persist: piniaPersistConfig("globalState")
});

// piniaPersist(持久化)
const pinia = createPinia();
pinia.use(piniaPluginPersistedstate)

export default pinia;