/**  车辆中心模块 **/

import http from "@/api";
// const baseUrl = '/eqq';
const baseUrl = "";

// 获取环境列表
export const getEnvTrunkTerminalListApi = () => {
    const params ={ "permission": "trunk_terminal_read"};
    return http.post( `/api/v1/auth/getenvbyperm`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 获取车辆列表
export const getTrunkCenterListApi = (params) => {
    return http.post(`${baseUrl}/api/v1/ops/trunk/list`, params, { headers: { showLoading: false } }); 
};

// 获取设备地址
export const getDeviceUrl = (params) => {
    return http.post(`${baseUrl}/api/v1/ops/trunk/device/url`, params, { headers: { showLoading: false } }); 
};

// 获取车辆列表（网络监控）
export const getTrunkListApi = (params) => {
    return http.post(`/monitor/vehicle/trunk/list`, params, { headers: { showLoading: false } }); 
};

// 获取车辆网络历史数据
export const getTrunkNetApi = (params) => {
    return http.post(`/monitor/vehicle/trunk/network/history`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 获取车辆流媒体数据
export const getMediaListApi = (params) => {
    return http.post(`/api/v1/ops/livings/search`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 
export const stopMediaApi = (params) => {
    return http.post(`/api/v1/ops/livings/stop`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 基站 PCI list 
export const pciListApi = (params) => {
    return http.post( `/monitor/vehicle/trunk/pci/list`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 基站 ping 
export const pingApi = (params) => {
    return http.post( `/monitor/vehicle/trunk/basestation/ping`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 基站信号
export const signalApi = (params) => {
    return http.post( `/monitor/vehicle/trunk/basestation/signal`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 在线终端
export const activeApi = (params) => {
    return http.post( `/monitor/vehicle/trunk/basestation/active`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 带宽
export const bandwidthApi = (params) => {
    return http.post( `/monitor/vehicle/trunk/basestation/bandwidth`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 获取离线区域
export const offlineApi = (params) => {
    return http.post( `/monitor/vehicle/trunk/network/offlineregion`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 同步车辆信息
export const syncTrunkApi = (params) => {
    return http.post( `/api/v1/ops/trunk/device/url`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 获取RTK基站状态
export const rtkListApi = (params) => {
    return http.post( `/api/v1/ops/rtk/status`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// RTK基站切换
export const rtkSwitchApi = (params) => {
    return http.post( `/api/v1/ops/rtk/switch`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};
