/**  首页模块 **/


import http from "@/api";

// 获取运营天数
export const getOperateDaysApi = (params) => {
    return http.post( `/api/v1/ops/hp/ntd`, params, { headers: { showLoading: false } }); 
};

// 获取实时sla
export const getRealTimeSlaApi = (params) => {
    return http.post( `/api/v1/ops/hp/daysla`, params, { headers: { showLoading: false } }); 
};

// 获取趋势sla
export const getTrendSlaApi = (params) => {
    return http.post( `/api/v1/ops/hp/slagraph`, params, { headers: { showLoading: false } }); 
};

