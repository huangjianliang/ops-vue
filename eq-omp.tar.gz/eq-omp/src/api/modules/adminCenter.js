/**  车辆中心模块 **/

import http from "@/api";

// 获取审计内容
export const getAuditListApi = (params) => {
    return http.post( `/api/v1/ops/search/record`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 审计接口
export const recordApi = (params) => {
    return http.post( `/api/v1/ops/record`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};