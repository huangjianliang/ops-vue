/**  车辆中心模块 **/

import http from "@/api";
// const baseUrl = '/eqq';
const baseUrl = "";

// 通用配置项列表
export const itemListApi = (params) => {
    return http.post(`/api/v1/ops/config/item/list`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 新增配置项
export const itemAddApi = (params) => {
    return http.post(`/api/v1/ops/config/item/add`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 查询配置项字典
export const dictListApi = (params) => {
    return http.post(`/api/v1/ops/config/key/dict/search`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 新增字典
export const dictAddApi = (params) => {
    return http.post(`/api/v1/ops/config/key/dict/upval`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 模板列表
export const tempListApi = (params) => {
    return http.post(`/api/v1/ops/config/model/search`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 新增模板
export const tempAddApi = (params) => {
    return http.post(`/api/v1/ops/config/model/add`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// dataId列表
export const dataIdListApi = (params) => {
    return http.post(`/api/v1/ops/config/get/dataid`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 模板类型列表
export const modelTypeListApi = (params) => {
    return http.post(`/api/v1/ops/config/model/type`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};