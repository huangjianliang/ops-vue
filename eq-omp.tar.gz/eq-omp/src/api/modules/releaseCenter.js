/**  发布中心模块 **/

import http from "@/api";


// 获取应用列表
export const getApplyListApi = (params) => {
    return http.post( `/deploy/deploy/GetAppList`, params, { headers: { showLoading: false } }); 
};

// 获取环境列表
export const getEnvListApi = (params) => {
    return http.post( `/deploy/deploy/GetEnvList`, params, { headers: { showLoading: false } }); 
};

// 获取环境列表
export const getEnvByPermListApi = (params) => {
    return http.post( `/api/v1/auth/getenvbyperm`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};

// 发布记录 - 获取发布记录列表
export const getReleaseRecordListApi = params => {
    return http.post( `/deploy/operate/recode/GetPage`, params, { headers: { showLoading: false } }); 
};

// 应用编译 - 应用列表
export const applyCompileListApi = () => {
    return http.post( `/deploy/build/GetAppList`, {}, { headers: { showLoading: false } }); 
};

// 应用编译 - 分支列表
export const applyCompileBranchListApi = (params) => {
    return http.post( `/deploy/build/GetBranchList`, params, { headers: { showLoading: false } }); 
};

// 应用编译 - 设备列表
export const applyCompileDeviceListApi = () => {
    return http.post( `/deploy/build/GetDeviceList`, {}, { headers: { showLoading: false } }); 
};

// 应用编译 - 执行编译
export const applyCompileExecuteApi = params => {
    return http.post( `/deploy/build/Exec`, params, { headers: { showLoading: false } }); 
};

// 应用编译 - 获取日志
export const getApplyCompileLogApi = params => {
    return http.post( `/deploy/build/Log`, params, { headers: { showLoading: false } });  
};


// 应用发布 - 应用列表
export const applyReleaseListApi = () => {
    return http.post( `/deploy/deploy/GetAppList`, {}, { headers: { showLoading: false } }); 
};

// 应用发布 - 版本列表
export const applyReleaseVersionListApi = (params) => {
    return http.post( `/deploy/deploy/GetProductList`, params, { headers: { showLoading: false } }); 
};

// 应用发布 - 环境列表
export const applyReleaseEnvListApi = () => {
    return http.post( `/deploy/deploy/GetEnvList`, {}, { headers: { showLoading: false } }); 
};

// 应用发布 - 执行发布
export const applyReleaseExecute = params => {
    return http.post( `/deploy/deploy/Exec`, params, { headers: { showLoading: false } }); 
};

// 应用发布 - 获取日志
export const getApplyReleaseLog = params => {
    return http.post( `/deploy/deploy/Log`, params, { headers: { showLoading: false } });  
};

// 制品管理 - 获取制品管理列表
export const productManageListApi = params => {
    return http.post( `/deploy/product/info/GetPage`, params, { headers: { showLoading: false } }); 
};


// 应用编译 - 任务列表
export const getBuildHistory = params => {
    return http.post( `/deploy/build/History`, params, { headers: { showLoading: false } }); 
};

// 应用发布 - 任务列表
export const getDeployHistory = params => {
    return http.post( `/deploy/deploy/History`, params, { headers: { showLoading: false } }); 
};

/** 提测单模块 **/

// 获取提测单列表
export const getSurveyList = params => {
    return http.post( `/process/detection/manifest/list`, params, { headers: { showLoading: false } });  
};

// 获取版本列表
export const getVersionList = params => {
    return http.post( `/process/detection/manifest/version`, params, { headers: { showLoading: false } });  
};

// 获取业务列表
export const getBusinessList = params => {
    return http.post( `/process/detection/manifest/business`, params, { headers: { showLoading: false } });  
};

// 提测单查看
export const surveyView = params => {
    return http.post( `/process/detection/manifest/view`, params, { headers: { showLoading: false } });  
};

// 获取历史提测单Id
export const getSurveyHistoryIds = params => {
    return http.post( `/process/detection/manifest/history`, params, { headers: { showLoading: false } });  
};

// 提测单历史详情
export const getSurveyHistoryDetail = params => {
    return http.post( `/process/detection/manifest/review`, params, { headers: { showLoading: false } });  
};

// 提测单创建
export const createSurvey = params => {
    return http.post( `/process/detection/manifest/create`, params, { headers: { showLoading: false } });  
};

// 提测单编辑
export const editSurvey = params => {
    return http.post( `/process/detection/manifest/edit`, params, { headers: { showLoading: false } });  
};

// 提测单保存
export const saveSurvey = params => {
    return http.post( `/process/detection/manifest/save`, params, { headers: { showLoading: false } });  
};

// 提测单描述编辑
export const editSurveyDes = params => {
    return http.post( `/process/detection/manifest/update`, params, { headers: { showLoading: false } });  
};

// 打开提测单
export const openSurvey = params => {
    return http.post( `/process/detection/manifest/open`, params, { headers: { showLoading: false } });  
};

// 关闭提测单
export const closeSurvey = params => {
    return http.post( `/process/detection/manifest/close`, params, { headers: { showLoading: false } });  
};

// 锁定提测单
export const clockSurvey = params => {
    return http.post( `/process/detection/manifest/lock`, params, { headers: { showLoading: false } });  
};

// 解锁提测单
export const unlockSurvey = params => {
    return http.post( `/process/detection/manifest/unlock`, params, { headers: { showLoading: false } });  
};

// 提测单归档
export const archivistSurvy = params => {
    return http.post( `/process/detection/manifest/archive`, params, { headers: { showLoading: false } });  
};

// 提测单拆档
export const shiftGearSurvey = params => {
    return http.post( `/process/detection/manifest/unarchive`, params, { headers: { showLoading: false } });  
};

// 一键部署
export const BatchDeploy = params => {
    return http.post( `/process/detection/manifest/deploy`, params, { headers: { showLoading: false } });  
};

// 一键部署版本对比
export const BatchDeployDiff = params => {
    return http.post( `/process/detection/manifest/diff/app`, params, { headers: { showLoading: false } });  
};