/**  应用中心模块 **/

import http from "@/api";


// 获取应用中心列表
export const getApplyCenterListApi = (params) => {
    return http.post(`/api/v1/ops/k8s/applist`, params, { headers: { showLoading: true } }); 
};

// 根据环境查询应用列表
export const getAppListApi = (params) => {
    return http.post(`/api/v1/ops/k8s/app/namelist`, params, { headers: { showLoading: true } }); 
};

// 根据环境查询应用列表（日志功能）
export const getAppsApi = (params) => {
    return http.post(`/logger/getapps`, params, { headers: { showLoading: false } }); 
};

// 根据环境查询应用列表
export const appEventApi = (params) => {
    return http.post(`/api/v1/ops/k8s/event/info`, params, { headers: { showLoading: false } }); 
};

// 应用操作
export const applyOperateApi = (params) => {
    return http.post(`/api/v1/ops/deployment/opera`, params, { headers: { showLoading: true } }); 
};

// 应用操作结果查询
export const applyOperateResultApi = (params) => {
    return http.post(`/api/v1/ops/deployment/info`, params, { headers: { showLoading: true } }); 
};

// 监控时间范围数据获取
export const getMonitorTimeApi = () => {
    return http.post(`/api/v1/ops/prom/timerange`, {}, { headers: { showLoading: true } }); 
};

// 监控数据获取
export const getMonitorDataApi = (params) => {
    return http.post(`/api/v1/ops/monitor/value`, params, { headers: { showLoading: false } }); 
};

// 获取实例列表(根据环境、应用名称查询)
export const getPodListApi = (params) => {
    return http.post(`/logger/getpods`, params, { headers: { showLoading: false } }); 
};

// 获取时间范围内日志列表
export const getTimeLogApi = (params) => {
    return http.post(`/logger/query`, params, { headers: { showLoading: true } }); 
};

// 获取时间范围内日志统计信息
export const getLogVectorApi = (params) => {
    return http.post("/logger/query_vector", params, { headers: { showLoading: true, "Content-Type": "application/json" } }); 
};

// 日志下载
export const downloadLogApi = (params) => {
    return http.post(`/logger/download`, params, { headers: { showLoading: false } }); 
};

// 获取配置
export const getNacos = (params) => {
    return http.post(`/api/v1/nacos/search`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 提交配置
export const updateNacos = (params) => {
    return http.post(`/api/v1/nacos/update`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 获取 YAML
export const getYamlApi = (params) => {
    return http.post(`/api/v1/ops/namespace/pod/yaml`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};

// 修改副本数
export const updateRcApi = (params) => {
    return http.post(`/api/v1/ops/k8s/update/replicas`, params, { headers: { showLoading: false, "Content-Type": "application/json" } }); 
};



