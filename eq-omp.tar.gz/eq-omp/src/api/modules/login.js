import http from "@/api";

export const loginApi = (params) => {
    return http.post( `/api/v1/login`, params, { headers: { showLoading: false } }); 
};