// 获取环境列表
import http from "@/api";


// export const getEnvListApi = (params) => {
//     return http.post( `/deploy/deploy/GetEnvList`, params, { headers: { showLoading: true } }); 
// };

export const getEnvListApi = (params) => {
    return http.post( `/cmdb/env/info/GetAll`, params, { headers: { showLoading: false } }); 
};