/**  车辆中心模块 **/

import http from "@/api";

// 获取 KAFKA
export const getKafkaListApi = () => {
    const params = {};
    return http.post( `/cmdb/env/info/GetKafkaUI`, params, { headers: { showLoading: true, "Content-Type": "application/json"} }); 
};

// 权限校验
export const checkpermApi = (params) => {
    return http.post( `/api/v1/auth/checkperm`, params, { headers: { showLoading: false, "Content-Type": "application/json"} }); 
};