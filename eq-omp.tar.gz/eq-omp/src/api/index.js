import axios, { HttpStatusCode } from 'axios';
import { useGlobalStore } from '@/store';
import router from "@/router";

import { AxiosCanceler } from './helper/axiosCancel';
import { checkStatus } from './helper/checkStatus';
import { showFullScreenLoading, tryHideFullScreenLoading } from '../config/serviceLoading';
import { resultStateMap } from '../constant/httpState';
import { ElMessage } from 'element-plus';

const axiosCanceler = new AxiosCanceler();

const { API_URL } = window.config;

const config = {
    // 默认请求地址
    baseURL: '',
    // 设置超时时间
    timeout: 20000,
    // 跨域时允许携带凭证
    withCredentials: true
};

class RequestHttp {
    constructor (config) {
        // 实例化axios
        this.service = axios.create(config);
        
       /**
       * @description 请求拦截器
       * 客户端发送请求 -> 请求拦截器 -> 服务器
       * token校验(JWT): 接受服务区返回的token，存储到vuex/pinia/本地存储当中
       */
        this.service.interceptors.request.use((config) => {
            // 将当前请求添加到 pending 中
            axiosCanceler.addPending(config);
            const globalStore = useGlobalStore();
            
            
            
            // 当前请求是否显示loading
            config.headers?.showLoading && showFullScreenLoading();
            
            // TODO 
            if(config.url && !config.url.includes('http:')){
                config.url = `https://ops.eacon.com${config.url}` 
            }
            
            console.log(config.url);
            
            const token = globalStore.token;
            console.log(config);
            return { ...config, headers: { ...config.headers, 'Authorization': `Bearer ${token}`}}
        }, (error) => {
            return Promise.reject(error);
        });
        
        this.service.interceptors.response.use((response) => {
            const { data, config } = response;
            const globalStore = useGlobalStore();
            
            // 请求结束后，移除本次请求，并关闭请求 loading
            axiosCanceler.removePending(config);
            tryHideFullScreenLoading();
            
            // 登陆失效(code === 400)
            if(data.code === resultStateMap.OVERDUE){
                ElMessage.error(data.msg);
                globalStore.setToken("");
                router.replace({
                    path: "/"
                });
                return Promise.reject(data);
            }
            
            // 全局错误信息拦截 
            if(data.code && data.code !== resultStateMap.SUCCESS){
                ElMessage.error(data.msg);
                return Promise.reject(data);
            }
            
            // 成功请求
            return data;
        }, async (error) => {
            const { response } = error;
            tryHideFullScreenLoading();
            
            // 请求超时单独判断，因为请求超时没有 response
            if(error.message.indexOf("timeout") !== -1) ElMessage.error("请求超时！请您稍后重试");
            
            // 根据相应的状态码，做不同的处理
            if(response) checkStatus(response.status);
            
            // 服务器结果都没有返回(可能服务器错误可能客户端断网), 断网处理：可以跳转到断网页面
            if(!window.navigator.onLine) router.replace({ path: '/500'});
            return Promise.reject(error);
        })
    }
    // 常用请求方法封装
    get (url, params, _object={}) {
        return this.service.get(url, { params, ..._object})
    }
    
    post (url, params, _object={}) {
        return this.service.post(url, params, _object);
    }
    
    put (url, params, _object={}) {
        return this.service.post(url, params, _object);
    }
    
    delete (url, params, _object={}) {
        return this.service.post(url, params, ..._object);
    }
}

export default new RequestHttp(config);