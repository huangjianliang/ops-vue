
/**
 * pinia持久化参数配置
 * @param {*} key 
 * @returns 
 */
const piniaPersistConfig = (key) => {
    const persist = {
        key, 
        storage: window.localStorage
    };
    return persist;
};

export default piniaPersistConfig;