/**  菜单列表  **/

export const menuList =  [
    {
        "icon": "shouye",
        "title": "首页",
        "path": "/home"
    },
    // {
    //     "icon": "data-analysis",
    //     "title": "内嵌页面",
    //     "path": "/dashboard",
    //     "children": [
    //         {
    //             "path": "/dashboard/siteNavigate",
    //             "title": "导航站点",
    //             "icon": "menu"
    //         }
    //     ]
    // },
    {
        "icon": "fabuzhongxin",
        "title": "发布中心",
        "path": "/releaseCenter",
        "children": [
            {
                "path": "/releaseCenter/releaseRecord",
                "title": "发布记录",
                "icon": "fabujilu"
            },
            {
                "path": "/releaseCenter/applyCompile",
                "title": "应用编译",
                "icon": "yingyongbianyi"
            },
            {
                "path": "/releaseCenter/applyPublish",
                "title": "应用发布",
                "icon": "yingyongfabu"
            },
            {
                "path": "/releaseCenter/productManage",
                "title": "制品管理",
                "icon": "zhipinguanli"
            },
            {
                "path": "/releaseCenter/surveyManage",
                "title": "提测管理",
                "icon": "zhipinguanli"
            }
        ]
    },
    {
        "icon": "yingyongzhongxin",
        "title": "应用中心",
        "path": "/applyCenter",
        "children": [
            {
                "path": "/applyCenter/applyList",
                "title": "应用列表",
                "icon": "yingyongliebiao"
            },
            {
                "path": "/applyCenter/applyLog",
                "title": "应用日志",
                "icon": "yingyongrizhi"
            }
        ]
    },
    {
        "icon": "cheliangzhongxin",
        "title": "车辆中心",
        "path": "/trunkCenter",
        "children": [
            {
                "path": "/trunkCenter/trunkList",
                "title": "车辆列表",
                "icon": "cheliangliebiao"
            },
            {
                "path": "/trunkCenter/TrunkTerm",
                "title": "车辆终端",
                "icon": "cheliangliebiao"
            },
            {
                "path": "/trunkCenter/networkMonitor",
                "title": "网络监控",
                "icon": "wangluo"
            },
            //{
            //    "path": "/trunkCenter/flow",
            //    "title": "流量统计",
            //    "icon": "wangluo"
            //},
            {
                "path": "/trunkCenter/BaseMonitor",
                "title": "基站监控",
                "icon": "wangluo"
            },
            //{
            //    "path": "/trunkCenter/Android",
            //    "title": "辅助设备",
            //    "icon": "cheliangliebiao"
            //},
            {
                "path": "/trunkCenter/RtkList",
                "title": "RTK 基站",
                "icon": "wangluo"
            },
            {
                "path": "/trunkCenter/MediaList",
                "title": "流媒体",
                "icon": "wangluo"
            }
        ]
    },
    {
        "icon": "jichuzujian",
        "title": "基础组件",
        "path": "/midCenter",
        "children": [
            {
                "path": "/midCenter/kafka",
                "title": "Kafka",
                "icon": "KAFKA"
            },
            {
                "path": "/midCenter/redis",
                "title": "Redis",
                "icon": "REDIS"
            },
            {
                "path": "/midCenter/pg",
                "title": "PGSQL",
                "icon": "PGSQL"
            },
        ]
    },
    {
        "icon": "jichuzujian",
        "title": "配置中心",
        "path": "/configCenter",
        "children": [
            {
                "path": "/configCenter/item",
                "title": "配置项",
                "icon": "KAFKA"
            },
            {
                "path": "/configCenter/dict",
                "title": "配置字典",
                "icon": "KAFKA"
            },
            {
                "path": "/configCenter/temp",
                "title": "模板",
                "icon": "KAFKA"
            },
        ]
    },
    {
        "icon": "jichuzujian",
        "title": "系统管理",
        "path": "/adminCenter",
        "children": [
            {
                "path": "/adminCenter/audit",
                "title": "审计",
                "icon": "KAFKA"
            }
        ]
    }
];

