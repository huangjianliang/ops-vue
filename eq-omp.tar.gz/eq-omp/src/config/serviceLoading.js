import { ElLoading } from 'element-plus';

// 全局请求 loading 
let loadingInstance;

const startLoading = () => {
    loadingInstance = ElLoading.service({
        fullscreen: true,
        lock: true,
        text: "加载中...",
        background: "rgba(0, 0, 0, 0.7)"
    })
};

const endLoading = () => {
    loadingInstance.close();
};

/**
 * 1、showFullScreenLoading() tryHideScreenLoading() 要做的事就是将同一时刻的请求合并
 * 2、声明一个变量 needLoadingRequestCount，每次调用showFullScreenLoading方法 needLoadingRequestCount + 1
 * 3、调用tryHideFullScreenLoading() 方法，needLoadingRequestCount - 1，needLoadingRequestCount 为0时，结束loading
 */
let needLoadingRequestCount = 0;

export const showFullScreenLoading = () => {
    if(needLoadingRequestCount === 0){
        startLoading();
    }
    needLoadingRequestCount ++;
};

export const tryHideFullScreenLoading = () => {
    if(needLoadingRequestCount <= 0) return;
    needLoadingRequestCount --;
    if(needLoadingRequestCount === 0) {
        endLoading();
    }
};
