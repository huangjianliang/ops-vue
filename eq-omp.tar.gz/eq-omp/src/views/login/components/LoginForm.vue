<template>
	<el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" size="large">
		<el-form-item prop="username">
			<el-input v-model="loginForm.username" placeholder="请输入用户名" clearable>
				<template #prefix>
					<el-icon class="el-input__icon"><user /></el-icon>
				</template>
			</el-input>
		</el-form-item>
		<el-form-item prop="password">
			<el-input type="password" v-model="loginForm.password" placeholder="请输入密码" show-password autocomplete="new-password" clearable>
				<template #prefix>
					<el-icon class="el-input__icon"><lock /></el-icon>
				</template>
			</el-input>
		</el-form-item>
	</el-form>
	<div class="login-btn">
		<!-- <el-button :icon="CircleClose" round @click="resetForm(loginFormRef)" size="large">重置</el-button> -->
		<el-button :icon="UserFilled" round @click="login(loginFormRef)" size="large" type="primary" :loading="loading" class="loginBtn">
			登录
		</el-button>
	</div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { useRouter } from "vue-router";
import { CircleClose, UserFilled } from "@element-plus/icons-vue";
import { ElNotification, ElMessage } from "element-plus";
import { loginApi } from "@/api/modules/login";
import { useGlobalStore } from "@/store";
import { useMenuStore } from "@/store/modules/menu";
import { useTabsStore } from "@/store/modules/tabs";
import { getTimeState } from "@/utils/util";

const globalStore = useGlobalStore();
const menuStore = useMenuStore();
const tabStore = useTabsStore();
const router = useRouter();

const loginFormRef = ref();
const loading = ref(false);

// 表单规则
const loginRules = reactive({
	username: [{ required: true, message: "请输入用户名", trigger: "blur" }],
	password: [{ required: true, message: "请输入密码", trigger: "blur" }]
});

// 登录表单数据
const loginForm = reactive({
	username: "",
	password: ""
});

onMounted(() => {
	const {token, userInfo} = globalStore;
	if (userInfo) {
		loginForm.username = userInfo['user_name'];
	}
	
	if(token) {
		// 跳转至首页
		router.push({ name: "home" });
	}
	console.log('globalStore', globalStore.token);


	// 监听enter事件（调用登录）
	document.onkeydown = (e) => {
		e = window.event || e;
		if (e.code === "Enter" || e.code === "enter" || e.code === "NumpadEnter") {
			if (loading.value) return;
			login(loginFormRef.value);
		}
	};
});

// 登录
const login = (formEl) => {
	if (!formEl) return;
	
	formEl.validate(async valid => {
		if (!valid) return;
		loading.value = true;
		
		try {
			const params = { ...loginForm, role: '1' };
			const res = await loginApi(params);
			
			if(res.code !== 200) {
				ElMessage.error('登录失败！')
				return;
			}
			
			// 存储 token
			globalStore.setToken(res.data?.token);
			globalStore.setUserInfo(res.data);
			
			// 登录成功之后清除上个账号的 menulist 和 tabs 数据
			menuStore.setMenuList([]);
			tabStore.closeMultipleTab();
			
			// 跳转至首页
			router.push({ name: "home" });
			
			ElNotification({
				title: getTimeState(),
				message: "欢迎登录易控运维管理平台",
				type: "success",
				duration: 3000
			});
		} finally {
			loading.value = false;
		}
	});
};

// 重置表单
const resetForm = (formEl) => {
	formEl && formEl.resetFields();
};

</script>

<style scoped lang="scss">
@import "../index.scss";
</style>
