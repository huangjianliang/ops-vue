<template>
	<div class="login-container flx-center">
		<div class="loginLeft" :class="{'active': isActive}">
		    <img src="@/assets/images/login/login-icon.png" alt="">
		</div>
		<div class="loginRight">
		    <div class="header">
		        <!-- <i class="iconfont icon-E"></i> -->
		        <div class="title">易控智驾运维管理平台</div>
		    </div>
		    <div class="login-form">
		        <LoginForm />
		    </div>
		</div>
	</div>
</template>

<script setup>
    import { onMounted, onUnmounted, ref } from 'vue';
    import LoginForm from './components/LoginForm.vue';
    
    let interval = null;
    
    const isActive = ref(true);
    
    onMounted(() => {
        interval = setInterval(() => {
            isActive.value = !isActive.value;
        }, 6000);
        setTimeout(() => {
            isActive.value = !isActive.value;
        });
    });
    
    onUnmounted(() => {
        interval && clearInterval(interval);
    });
</script>

<style scoped lang="scss">
    @import "./index.scss";
</style>
