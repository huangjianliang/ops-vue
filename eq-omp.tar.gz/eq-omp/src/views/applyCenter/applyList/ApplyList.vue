<!-- 应用列表 -->

<template>
	<div class="main-box">
		<div class="table-box">
			<ProTable ref="proTable" :columns="columns" :requestApi="getApplyCenterListApi" :initParam="initParam"></ProTable>
		</div>

		<div>
			<el-dialog :title="logInfo" center v-model="logVisible" width="80%" :before-close="clearLog" show-close>
				<el-row :gutter="24">
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>环境：{{ env_name }}</span>
					</el-col>
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>应用：{{ app_name }}</span>
					</el-col>
					<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<el-form-item label="选择实例：">
                        	<el-select v-model="pod" @change="getRealTimeLog" placeholder="请选择" filterable clearable>
                            	<el-option v-for="item in podOptions" :key="item" :label="item" :value="item">
                            	</el-option>
                        	</el-select>
                		</el-form-item>
					</el-col>
					<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<el-button v-if="isPaused" type="primary" @click="unPauseLog">恢复</el-button>
						<el-button v-else="isPaused" type="danger" @click="pauseLog">暂停</el-button>
					</el-col>
  				</el-row>

                <div id="logScroll" style="overflow-y: auto; height: 600px; font-size: 16px; font-family: Ubuntu Mono, Droid Sans Mono, monospace; background-color: #300a24; color: white;">
					<ul class="infinite-list" infinite-scroll-throttle-delay="500"
                    :infinite-scroll-disabled="busy" infinite-scroll-distance="10" style="overflow-y:auto" id="logScroll">
                    	<li v-for="log in queryLog">
                        	<span v-html="log.content" style="word-wrap: break-word;"></span>
                        	<span>&nbsp;</span>
                    	</li>
                	</ul>
                </div>
            </el-dialog>
        </div>

		<!-- 配置修改 -->
		<div>
			<el-dialog title="配置修改" center v-model="configVisible" width="80%" :before-close="clearConfig" show-close>
				<el-row :gutter="24">
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>环境：{{ env_name }}</span>
					</el-col>
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>应用：{{ app_name }}</span>
					</el-col>
					<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<el-form-item label="选择配置：">
                        	<el-select v-model="configGroup" @change="configSingleGet" placeholder="请选择" filterable>
                            	<el-option v-for="item in configGroupOptions" :key="item" :label="item" :value="item">
                            	</el-option>
                        	</el-select>
                		</el-form-item>
					</el-col>
					<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<el-button type="primary" @click="configCommit" :disabled="disableSaveBtn">保存</el-button>
						<el-button type="danger" @click="configCommitRestart" :disabled="disableSaveBtn">保存并重启</el-button>
					</el-col>
  				</el-row>

                <div style="height: 600px; width: 100%">
                    <Codemirror 
                        class="code" 
                        v-model="configInput" 
                        :style="{ height: '100%'}" 
                        :extensions="extensions" 
                        :autofocus="true"
                        :disabled="false"
                        @change="disableConfigSaveBtn"/>
                </div>

                <!--
                <div id="config">
					<textarea v-model="configInput" @input="disableConfigSaveBtn" style="height: 600px; width: 100%; font-size: 16px; font-family: Ubuntu Mono, Droid Sans Mono, monospace; background-color: #300a24; color: white;" />
				</div>
                -->
            </el-dialog>
        </div>

		<div >
            <el-dialog  class="echartContainer" v-model="dialogVisible" width="50%" :before-close="clearMonitor" show-close>
				<el-row :gutter="25">
    				<el-col :span="3"><div class="grid-content ep-bg-purple" />
						<span>环境：{{ env_name }}</span>
					</el-col>
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span type="info">应用：{{ app_name }}</span>
					</el-col>
					<el-col :span="5"><div class="grid-content ep-bg-purple" />
						<el-form-item label="时间区间">
                        	<el-select v-model="trange" @change="getMonitorData" placeholder="请选择" filterable>
                            	<el-option v-for="item in timeOptions" :key="item.trange" :label="item.label"
                                	:value="item.trange" />
                        	</el-select>
                    	</el-form-item>
					</el-col>
					<el-col :span="5"><div class="grid-content ep-bg-purple" />
						<el-form-item label="选择实例：">
                        	<el-select v-model="pod" @change="getMonitorData" placeholder="请选择" filterable clearable>
                            	<el-option v-for="item in podOptions" :key="item" :label="item" :value="item">
                            	</el-option>
                        	</el-select>
                		</el-form-item>
					</el-col>
					<el-col :span="5">
						<el-button type="primary" @click="getMonitorData">刷新</el-button>
					</el-col>
  				</el-row>

				<div class="echart-item" style="background-color: rgba(0, 0, 0, 0.8);" ref="cpuEchartRef"></div>
        		<div class="echart-item" style="background-color: rgba(0, 0, 0, 0.8);" ref="gpuEchartRef"></div>

            </el-dialog>
    	</div>

        <!-- 事件 -->
		<div>
			<el-dialog title="事件" center v-model="eventVisible" width="30%" show-close>
			    <span>{{ appEventData }}</span>
            </el-dialog>
        </div>

        <!-- YAML 查看 -->
		<div>
			<el-dialog title="YAML" center v-model="yamlVisible" width="80%" show-close>
				<el-row :gutter="24">
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>环境：{{ env_name }}</span>
					</el-col>
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>应用：{{ app_name }}</span>
					</el-col>
					<el-col :span="5"><div class="grid-content ep-bg-purple" />
						<el-form-item label="选择实例：">
                        	<el-select v-model="pod" @change="getYaml(null)" placeholder="请选择" filterable clearable>
                            	<el-option v-for="item in podOptions" :key="item" :label="item" :value="item">
                            	</el-option>
                        	</el-select>
                		</el-form-item>
					</el-col>
  				</el-row>

                <div style="height: 600px; width: 100%">
                    <Codemirror 
                        class="code" 
                        v-model="yamlInput" 
                        :style="{ height: '100%'}" 
                        :extensions="extensions" 
                        :autofocus="true"
                        :disabled="true"/>
                </div>
            </el-dialog>
        </div>

        <!-- 修改副本数 -->
		<div>
			<el-dialog title="调整副本" center v-model="updateRcVisible" width="30%" show-close>
                <el-form label-width="100px">
                    <el-form-item label="环境">
                        <span>{{rcEnv}}</span>
                    </el-form-item>
                    <el-form-item label="应用">
                        <span>{{rcApp}}</span>
                    </el-form-item>
                    <el-form-item label="副本数">
                        <el-select v-model="rcCommit" placeholder="请选择" filterable clearable>
                            <el-option v-for="item in rcOptions" :key="item.value" :label="item.label" :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="updateRc">提交</el-button>
                    </el-form-item>
                </el-form>
            </el-dialog>
        </div>

	</div>
</template>

<script setup name="applyList">
import { ref, reactive  } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { getEnvByPermListApi } from '@/api/modules/releaseCenter';
import { getApplyCenterListApi, getAppListApi, applyOperateApi, getPodListApi, getMonitorDataApi, getMonitorTimeApi, getNacos, updateNacos, appEventApi, getYamlApi, updateRcApi } from '@/api/modules/applyCenter';
import { ElMessage } from "element-plus";
import * as echarts from "echarts";
import { useEcharts } from "@/hooks/useEcharts";
import { getTimeFromStamp } from '@/utils/util';
import { useGlobalStore } from '@/store';

import { Codemirror } from "vue-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { oneDark } from "@codemirror/theme-one-dark";

// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 监控图表
const dialogVisible = ref(false);
let cpuEachart = null;
let gpuEachart = null;
const cpuEchartRef = ref(null);
const gpuEchartRef = ref(null);
const podOptions = ref([]);
const env_name = ref('');
const app_name = ref('');
const pod = ref('');
const timeOptions = ref([]);
const trange = ref('3');

const getOptions = (xdata, ydata, title, unit) => {
    return {
        color: ['#80FFA5'],
        title: {
            show: true,
            text: title,
            textStyle: {
                color: '#fff',
                fontStyle: 'normal',
                fontWeight: 'normal',
                fontFamily: 'sans-serif',
                fontSize: 18,
                lineHeight: 18,
            },
            left: 'center',
            top: 'top'
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        legend: {
            data: [title],
            right: 10,
            textStyle: {
                color: "#fff"
            },
            itemWidth: 14,
            itemHeight: 10,
            itemGap: 13
        },
        xAxis: {
            type: 'category',
            data: xdata,
            boundaryGap: false,
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                },
                formatter: function (value) {
                    if (value.includes(' ')) {
                        return value.split(' ')[1];
                    }
                    return value;
                },
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        yAxis: {
            name: unit,
            type: 'value',
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                }
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        series: [
            {
                name: title,
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(128, 255, 165)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(1, 191, 236)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: ydata
            },
        ]
    };
};

// 获取实例列表
const getPodList = async () => {
	const { start, end } = getRangeTime(trange.value);
    const params = { env: env_name.value, app: app_name.value, start, end };
    try {
        const res = await getPodListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            podOptions.value = data;
			if (! pod.value) {
				pod.value = data[0];
			}
            
        }else{
            podOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 根据时间范围获取具体开始结束时间
const getRangeTime = (val) => {
    // 获取当前日期时间戳
    const now = new Date();
    const endTimeStamp = now.getTime();
    const startTimeStamp = endTimeStamp - Number(val) * 3600000;
    const start = getTimeFromStamp(startTimeStamp);
    const end = getTimeFromStamp(endTimeStamp);

    return { start, end };
};

// 获取监控数据
const getMonitorData = async () => {
    try {
		await getPodList();

        const res = await getMonitorDataApi({ env_name: env_name.value, pod: pod.value, trange: trange.value });

        const { code, data } = res;
        if (code === 200 && data) {
            const { cpu, mem } = data;

            const cupOptions = getOptions(cpu.timeSt, cpu.monitorValue, 'CPU', '核数');
            const gpuOptions = getOptions(mem.timeSt, mem.monitorValue, '内存', 'MB');

			console.log(cupOptions)
            cpuEachart.setOption(cupOptions);
            gpuEachart.setOption(gpuOptions);
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取时间范围列表数据
const getTimeList = async () => {
    try {
        const res = await getMonitorTimeApi();
        const { code, data } = res;
        if (code === 200 && data) {
            timeOptions.value = data;
        } else {
            timeOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 实例化图标
const initEcharts = () => {
	!cpuEachart && (cpuEachart = echarts.init(cpuEchartRef.value));
	!gpuEachart && (gpuEachart = echarts.init(gpuEchartRef.value));
};

// 监控图表
const getMonitor = async (items) => {
	dialogVisible.value = true;
	env_name.value = items['env_name']
	app_name.value = items['app_name']
	await getTimeList();
	await initEcharts();
	await getMonitorData();
};

// 清理监控图表
const clearMonitor = async () => {
	dialogVisible.value = false;
	cpuEachart.value = null;
	gpuEachart.value = null;
	env_name.value = '';
	app_name.value = '';
	trange.value = '3';
	pod.value = '';
	isPaused.value = false;
};


// 实时日志
let socket = null;
const logVisible = ref(false);
const queryLog = ref([]);
const isPaused = ref(false);

const globalStore = useGlobalStore();

const getLog = async (items) => {
	env_name.value = items['env_name'];
	app_name.value = items['app_name']
	await getPodList();
	pod.value = '';
	logVisible.value = true;
	getRealTimeLog(items);
};

const clearLog = async () => {
	logVisible.value = false;
	env_name.value = '';
	app_name.value = '';
	pod.value = '';
	socket.close();
	queryLog.value = [];
};

const pauseLog = async () => {
	isPaused.value = true;
};

const unPauseLog = async () => {
	isPaused.value = false;
};

// 实时
const getRealTimeLog = () => {
	if (socket) {
		socket.close();
	}

	queryLog.value = [];

    const { WS_LOG_URL } = window.config;
	const env = env_name.value;
	const app = app_name.value;
	const ipod = pod.value;

    const { token } = globalStore;
    let url = `${WS_LOG_URL}?env=${env}&app=${app}&token=${token}`;
    if(ipod) (url = `${url}&pod=${ipod}`);
    //if(key) (url = `${url}&key=${key}`);

    socket = new WebSocket(url);

    socket.onopen = function () {
        console.log("连接状态：已连接");
        // 发送认证信息
        socket.send(JSON.stringify({
            type: 'auth',
            Authorization: `Bearer ${token}`
        }));
    }

    socket.onmessage = function (event) {
		if (!isPaused.value) {
			const logdata = {'content': event.data};
			const maxlines = 500;
			if (queryLog.value.length > maxlines) {
				queryLog.value.splice(0, queryLog.value.length - maxlines);
			}
        	queryLog.value.push(logdata)
        	const scrollBox = document.getElementById('logScroll');
        	scrollBox.scrollTop = scrollBox.scrollHeight;
		}
    }

    socket.onclose = function () {
        console.log('关闭');
    }
};


// 配置
const configVisible = ref(false);
const configInput = ref('');

const configGroup = ref('');
const configGroupOptions = ref([]);

const configItems = ref(null);
const disableSaveBtn = ref(true);

const disableConfigSaveBtn = async () => {
	disableSaveBtn.value = false;
};

const configGet = async (items) => {
	configItems.value = items;
	env_name.value = items['env_name'];
	app_name.value = items['app_name'];

	configGroupOptions.value = [];
	configGroup.value = '';

	const params = {env_name: env_name.value, dataId: app_name.value };

	try {
        const res = await getNacos(params);
        const { code, data } = res;
        if (code === 200 && data) {
			for (var i = 0; i < data['pageItems'].length; i ++) {
				configGroupOptions.value.push(data['pageItems'][i]['group'])
			}
			configGroup.value = data['pageItems'][0]['group']
			configSingleGet()
        }
    } catch (error) {
		ElMessage.error("获取配置信息失败！");
        throw new Error(error);
    }

	configVisible.value = true;
};

const configSingleGet = async () => {
	configInput.value = '';

	const params = {"env_name": env_name.value, dataId: app_name.value, group: configGroup.value};

	try {
        const res = await getNacos(params);
        const { code, data } = res;
        if (code === 200 && data) {
			if (data['pageItems'].length == 1) {
				if (data['pageItems'][0]['dataId'] == app_name.value) {
					configInput.value = data['pageItems'][0]['content'];
				}
			}
        }
    } catch (error) {
		ElMessage.error("获取配置信息失败！");
        throw new Error(error);
    }
};

const clearConfig = async () => {
	env_name.value = '';
	app_name.value = '';
	configGroup.value = '';
	configGroupOptions.value = [];
	configItems.value = '';
	configVisible.value = false;
	disableSaveBtn.value = true;
};

const configCommit = async () => {

	const globalStore = useGlobalStore();

	const d = new Date();
	const n = d.toLocaleDateString() + ' ' + d.toLocaleTimeString();

	const params = {
		env_name: env_name.value, 
		dataId: app_name.value, 
		group: configGroup.value,
		content: configInput.value,
		desc: '操作人员：' + globalStore.userInfo['cn_name'] + '，操作时间：' + n
	};

	try {
        const res = await updateNacos(params);
        const { code, message } = res;
        if (code === 200) {
			ElMessage.success("配置修改成功！");
			configVisible.value = false;
        } else {
			ElMessage.error("配置保存错误！" + message)
		}
    } catch (error) {
		ElMessage.error("配置保存失败！");
        throw new Error(error);
    }

	disableSaveBtn.value = true;
};

const configCommitRestart = async () => {
	await configCommit();
	reload(configItems.value);
	configVisible.value = false;
};


// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认加载列表为空
	env_name: [],
	app_name: '',
	pageNum: 1,
	pageSize: 25
});

const selectEnv = (item) => {
    initParam.env_name = item.env_name
    return {"code": 200, "data": ""}
}

const selectApp = (item) => {
    initParam.app_name = item.app_name
    return {"code": 200, "data": ""}
}

// 执行
const runAction = async (items, action) => {
	if (action == 'start'){
		start(items);
	}
	if (action == 'reload'){
		reload(items);
	}
	if (action == 'stop'){
		stop(items);
	}
};

const start = async (item) => {
	//console.log(item);
	initParam.update = Date.now();
    const { app_name, env_name, status } = item;
	const replica = "start-" + status;
    if(!app_name) {
        ElMessage.warning('请选择应用名称！');
        return;
    }
    
    if(!replica) {
        ElMessage.warning('请选择操作类型！');
        return;
    }
    try {
        const res = await applyOperateApi({ app_name, env_name, replica });
        
        const { code } = res;
        if (code === 200) {
			console.log('start ok')
			ElMessage.success('启动应用成功！请稍后刷新页面。')
        }
    } catch (error) {
        throw new Error(error);
    }
};

const stop = async (item) => {
	//console.log(item);
	initParam.update = Date.now();
    const { app_name, env_name, status } = item;
	const replica = "stop-" + status;
    if(!app_name) {
        ElMessage.warning('请选择应用名称！');
        return;
    }
    
    if(!replica) {
        ElMessage.warning('请选择操作类型！');
        return;
    }
    try {
        const res = await applyOperateApi({ app_name, env_name, replica });
        
        const { code } = res;
        if (code === 200) {
			console.log('stop ok')
			ElMessage.success('停止应用成功！请稍后刷新页面。')
        }
    } catch (error) {
        throw new Error(error);
    }
};

const reload = async (item) => {
	//console.log(item);
	initParam.update = Date.now();
    const { app_name, env_name, status } = item;
	const replica = "reload-" + status;
    if(!app_name) {
        ElMessage.warning('请选择应用名称！');
        return;
    }
    
    if(!replica) {
        ElMessage.warning('请选择操作类型！');
        return;
    }
    try {
        const res = await applyOperateApi({ app_name, env_name, replica });
        
        const { code } = res;
        if (code === 200) {
			console.log('reload ok')
			ElMessage.success('重启应用成功！请稍后刷新页面。')
        }
    } catch (error) {
        throw new Error(error);
    }
};

const openTerm = async (items) => {
	window.open(items['terminal_url'], '_blank');
};

// 获取应用列表
const getAppList = async (params = {}) => {
    try {
        const res = await getAppListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
			console.log(res)
            return res;
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 事件
const eventVisible = ref(false);
const appEventData = ref('');
const appEvent = async (item) => {
    eventVisible.value = true;
    try {
        const res = await appEventApi(item);
        const { code, data } = res;
        if (code === 200 && data) {
			//console.log(res)
            appEventData.value = data.message;
            //console.log(appEventData.value)
        }
    } catch (error) {
        throw new Error(error);
    }
};

// YAML
const extensions = [javascript(), oneDark];
const yamlVisible = ref(false);
const yamlInput = ref('');
const yamlItems = ref(null);

const getYaml = async (items) => {
    yamlVisible.value = true;
    
    if (items){
        yamlItems.value = items;
        env_name.value = yamlItems.value['env_name'];
	    app_name.value = yamlItems.value['app_name'];
        pod.value = null;
        await getPodList();
    }

	const params = {env_name: env_name.value, podName: pod.value };

	try {
        const res = await getYamlApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            yamlInput.value = data
        }
    } catch (error) {
		ElMessage.error("获取配置信息失败！");
        throw new Error(error);
    }
};

// 修改副本数
const updateRcVisible = ref(false);
const rcCommit = ref('');
const rcEnv = ref('');
const rcApp = ref('');
const rcOptions = [
  {
    value: '0',
    label: '0',
  },
  {
    value: '1',
    label: '1',
  },
  {
    value: '2',
    label: '2',
  },
  {
    value: '3',
    label: '3',
  },
]
const showRcDialog = (item) => {
    updateRcVisible.value = true;
    rcEnv.value = item.env_name;
    rcApp.value = item.app_name;
};

const updateRc = async () => {
    const params = {"env_name": rcEnv.value, "app_name": rcApp.value, "replica": rcCommit.value}

    try {
        const res = await updateRcApi(params);
        
        const { code, message } = res;
        if (code === 200) {
			ElMessage.success('提交成功!');
        } else {
            ElMessage.error(message);
        }
    } catch (error) {
        throw new Error(error);
    }
    updateRcVisible.value = false;
};

// 表格配置项
const columns = [
	{
		prop: "app_name",
		label: "名称",
		search: true,
		searchType: "select",
		enum: getAppList,
		searchProps: { label: "label", value: "label" },
		sortable: true,
		changeProps: { api: selectApp},
        clip: true
	},
	{
		prop: "env_name",
		label: "环境",
		search: true,
		searchType: "multipleSelect",
		enum: getEnvByPermListApi,
		searchProps: { label: "label", value: "env_name" },
		sortable: true,
		changeProps: { api: selectEnv},
        width: 80
	},
	{ 
	    prop: "status", 
	    label: "READY",
	},
	{ 
	    prop: "deploy_time", 
	    label: "启动时间",
		sortable: true,
		width: 150
	},
	{
		prop: "version",
		label: "运行版本",
		width: 200,
        clip: true
	},
	{
        prop: "restart_count",
		label: "重启",
        width: 80
	},
    { 
        type: "button", 
	    prop: "status", 
	    label: "调整副本",
		action: showRcDialog
	},
    {
		type: "button",
        prop: "restart_count",
		label: "YAML",
        action: getYaml
	},
	{ 
		type: "button", 
	    prop: "op_permission", 
	    label: "终端",
		action: openTerm
	},
	{ 
		type: "button", 
	    prop: "op_permission", 
	    label: "配置",
		action: configGet
	},
	{ 
		type: "button", 
	    prop: "app_name", 
	    label: "监控",
		action: getMonitor
	},
	{ 
		type: "button", 
	    prop: "app_name", 
	    label: "日志",
		action: getLog
	},
	{ 
		type: "appbutton", 
	    prop: "op_permission", 
	    label: "操作",
		btType: "warning",
		action: runAction,
	},
	
];

</script>

<style lang="scss" scoped>
.echartContainer {
    width: 100%;
    height: 100%;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.8);
    box-sizing: border-box;

    .echart-item {
        width: 100%;
        height: 250px;
        padding: 2%;
        box-sizing: border-box;
    }

    .divide {
        display: inline-block;
        height: 1px;
        width: 100%;
        background-color: rgba(0, 0, 0, 0.3);
    }
}
</style>

