<!--  应用日志  -->

<template>
    <div class="main-box">
        <div class="table-box">
            <!-- 查询表单 -->
            <div class="card table-search log-search">
                <el-form ref="formRef" :model="searchForm" :inline="true">
                    <el-form-item label="应用">
                        <el-select v-model="searchForm.env" @change="getLogAppList" filterable clearable placeholder="环境" allow-create 
                            style="width: 100px;">
                            <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label"
                                :value="item.env_name" />
                        </el-select>
                        <el-select v-model="searchForm.app" filterable clearable placeholder="应用" allow-create>
                            <el-option v-for="item in appOptions" :key="item.label" :label="item.label"
                                :value="item.label" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="时间">
                        <el-date-picker v-model="searchForm.time" format="YYYY-MM-DD HH:mm:ss"
                            value-format="YYYY-MM-DD HH:mm:ss" type="datetimerange" start-placeholder="开始"
                            end-placeholder="结束" :shortcuts="shortcuts" :unlink-panels=true range-separator="至" editable
                            style="width: 350px;" />
                    </el-form-item>
                    <el-form-item label="实例">
                        <el-select v-model="searchForm.pod" @focus="getPodList" placeholder="可选" filterable clearable>
                            <el-option v-for="item in podOptions" :key="item" :label="item" :value="item">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-select v-model="searchForm.direction">
                            <el-option v-for="item in directionOptions" :key="item.name" :label="item.label"
                                :value="item.name">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="关键字">
                        <el-input v-model="searchForm.key" placeholder="关键字：A|B; 正则：|~ 表达式 " clearable autosize
                            type="textarea" style="width: 260px" :rows="1"/>
                    </el-form-item>
                    <el-form-item label="上下文行数" v-if="searchForm.key">
                        <el-select v-model="searchForm.context_limit">
                            <el-option v-for="item in context_limitOptions" :key="item" :label="item" :value="item">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <div class="search-operation">
                    <el-button type="primary" @click="getLog('query')">查询</el-button>
                    <el-button type="success" @click="getLog('real')">{{ isStart ? '停止实时' : '实时' }}</el-button>
                    <el-button type="primary" @click="dowload">下载</el-button>
                    <el-button v-if="isShowLogChart" type="primary" @click="hideLogChart">隐藏</el-button>
                    <el-button v-else="isShowLogChart" type="primary" @click="showLogChart">图表</el-button>
                </div>
            </div>
            <div class="echart-item" v-show="isShowLogChart" style="background-color: #fff; margin-bottom: 10px;">
                <div class="item" style="width: 100%; height: 200px;" ref="logChartRef"></div>
            </div>

            <div class="card table logBox" style="font-size: 16px; font-family: Ubuntu Mono, Droid Sans Mono, monospace; background-color: #300a24;">
                <ul class="infinite-list" v-infinite-scroll="getTimeLog" infinite-scroll-throttle-delay="500"
                    :infinite-scroll-disabled="busy" infinite-scroll-distance="10" style="overflow-y:auto" id="logScroll">
                    <li v-for="log in queryLog" :class="{ 'important': log.ishighlight }">
                        <span v-html="log.content"></span>
                        <span>&nbsp;</span>
                        <el-tooltip class="box-item" effect="dark" placement="top" content="显示上下文">
                            <el-button v-if="log.showcontextbutton" @click="LogContext(log.time)" circle
                                style="width: 10px; height: 10px;">
                                <el-icon>
                                    <DCaret />
                                </el-icon>
                            </el-button>
                        </el-tooltip>


                    </li>
                </ul>
            </div>

            <div>
                <el-dialog :title="logInfo" center v-model="isShowDownloadDialog" width="30%" :before-close="clearLog"
                    show-close>
                    <ul class="downloadBox">
                        <li>
                            <div class="title">1. 安装命令行工具</div>
                            <div>
                                &nbsp&nbsp&nbsp请参考：
                                <el-link :href="HELP_FILE_URL" target="_blank">
                                    {{ HELP_FILE_URL }}
                                </el-link>
                            </div>
                        </li>
                        <li>
                            <span>&nbsp;</span>
                        </li>
                        <li>
                            <span class="title">2. 如果需要内容包含实例等元数据信息，日志格式请选择 json</span>
                        </li>
                        <li>
                            <span>&nbsp;</span>
                        </li>
                        <li>
                            <span class="title">3. 使用命令行工具，在终端执行如下命令，请选择日志格式：</span>
                            <el-select v-model="logformat" @change="getDownloadCmd" placeholder="日志格式" style="width: 80px;">
                                <el-option v-for="item in logFormatOptions" :key="item.name" :label="item.label"
                                    :value="item.name" />
                            </el-select>

                            <div class="linkBox">
                                <div class="linkUrl" id="linkUrl"
                                    style="font-size: 16px; font-family: Ubuntu Mono, Droid Sans Mono, monospace; background-color: #300a24; color: white;">
                                    {{ downloadCmd }}</div>
                                <span>&nbsp;</span>
                                <div class="btns" style="display: flex; justify-content: center;">
                                    <el-button type="primary" class="copyBtn" id="copyBtn">复制</el-button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </el-dialog>
            </div>

        </div>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted, watch, onUnmounted, createHydrationRenderer } from "vue";
import { getAppsApi, getPodListApi, getTimeLogApi, downloadLogApi, getLogVectorApi} from '@/api/modules/applyCenter';
import { getEnvByPermListApi } from '@/api/modules/releaseCenter';
import { ElMessage, ElMessageBox, ElButton } from 'element-plus';
import useClipboard from 'vue-clipboard3';
import { getNowDate } from '@/utils/util';
import { useGlobalStore } from '@/store';
import * as echarts from "echarts";

let socket = null;
const globalStore = useGlobalStore();

const { toClipboard } = useClipboard()

const searchForm = reactive({
    env: '',
    app: '',
    pod: '',
    key: '',
    context: '',
    context_limit: 15,
    direction: "forward",
    time: [new Date('2023-03-22 12:00:00'), new Date('2023-03-22 12:00:00')],
});

const curBtn = ref('query');

const rangeStart = ref("");
const rangeEnd = ref("");

const isEnded = ref(false);         // 查询日志结束标识
const queryLog = ref([]);           // 查询日志

const isStart = ref(false);         // 实时日志状态(开始、停止)
const busy = ref(false);            // 滚动加载状态

const envOptions = ref([]);         // 环境列表
const appOptions = ref([]);         // 应用列表
const podOptions = ref([]);         // 应用实例options

const context_limitOptions = [15, 100, 200, 500];

const directionOptions = [
    { "name": "forward", "label": "正序" },
    { "name": "backward", "label": "倒序" },
]

const shortcuts = [
    {
        text: '最近 1 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 1 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 5 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 5 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 15 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 15 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 30 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 30 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 1 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 4 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 4 * 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '今天',
        value: () => {
            const end = new Date()
            const start = new Date(end.getFullYear(), end.getMonth(), end.getDate()); // 将时分秒设置为0，获取今天零点的时间
            return [start, end]
        },
    },
    {
        text: '昨天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate())
            return [start, end]
        },
    },
    {
        text: '前天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            return [start, end]
        },
    },
]

onMounted(() => {
    initDate();
    getLogEnvList();
    logChart = echarts.init(logChartRef.value);
});

onUnmounted(() => {
    if (socket) {
        socket.close();
        socket = null;
    }
});

watch([searchForm.env, searchForm.app, searchForm.time], () => {
    getPodList();
});

watch(searchForm, () => {
    if (socket) {
        socket.close();
        socket = null;
        isStart.value = false;
    }
});


// 初始化时间
const initDate = () => {
    const { year, month, day, hour, minute, second } = getNowDate();
    const startHour = hour - 1 > 0 ? hour - 1 : hour;
    const startDate = `${year}-${month}-${day} ${startHour}:${hour === startHour ? "00" : minute}:${hour === startHour ? "00" : second}`;
    const endDate = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    searchForm.time = [startDate, endDate];
};

// 日志上下文
const LogContext = (time) => {
    searchForm.context = time;
    getLog('query');
    searchForm.context = '';
}

// 获取环境列表数据
const getLogEnvList = async () => {
    const params = { "permission": "log" };
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取应用列表数据
const getLogAppList = async () => {
    const params = { env: searchForm.env, start: searchForm.time[0], end: searchForm.time[1] };
    try {
        const res = await getAppsApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            appOptions.value = data;
            searchForm.pod = '';
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取实例列表
const getPodList = async () => {
    rangeStart.value = '';
    rangeEnd.value = '';
    searchForm.pod = '';
    const params = { env: searchForm.env, app: searchForm.app, start: searchForm.time[0], end: searchForm.time[1] };
    try {
        const res = await getPodListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            podOptions.value = data;
            console.log(podOptions.value)
        } else {
            podOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 日志查询
const getLog = (type) => {
    curBtn.value = type;
    isEnded.value = false;

    const logFnMap = {
        'query': getTimeLog,
        'real': getRealTimeLog
    };

    const { app } = searchForm;
    if (app.length < 2) {
        ElMessage.warning('请选择应用名称！');
        return;
    }

    if (type === 'query') {
        isStart.value = false;
        busy.value = false;
        rangeStart.value = "";
        rangeEnd.value = "";
        socket && socket.close();
        socket = null;
    }

    if (type === 'real') {
        isStart.value = !isStart.value;
        busy.value = true;

        if (!isStart.value) {
            socket && socket.close();
            socket = null;
            return;
        }
    }

    queryLog.value = [];
    logFnMap[type]();
};

// 生产查询参数
const queryParams = ref();

const handleSearchForm = async () => {
    const { time, app, context, context_limit, pod, key } = searchForm;

    let params = { env: searchForm.env, app: app, context: context, context_limit: context_limit, direction: searchForm.direction };

    if (time.length === 2) {
        params['start'] = time[0];
        params['end'] = time[1];
    }

    if (rangeStart.value && rangeEnd.value) {
        params['range_start'] = rangeStart.value;
        params['range_end'] = rangeEnd.value;
    }

    pod && (params['pod'] = pod);
    key && (params['key'] = key);

    queryParams.value = params;
};

// 查询
const getTimeLog = async () => {
    if (isEnded.value || curBtn.value !== 'query') return;

    handleSearchForm();

    try {
        const res = await getTimeLogApi(queryParams.value);
        const { code, data, range_start, range_end, ended } = res;
        if (code === 200 && data) {
            rangeStart.value = range_start;
            rangeEnd.value = range_end;
            isEnded.value = ended;
            queryLog.value = [...queryLog.value, ...data];
        }
    } catch (error) {
        throw new Error(error);
    }

    if (isShowLogChart.value){
        showLogChart();
    }
};

// 图表隐藏
const isShowLogChart = ref(false);

const hideLogChart = async() => {
    isShowLogChart.value = false;
};
const showLogChart = async() => {
    getLogVector(queryParams.value);
    isShowLogChart.value = true;
};

// 获取日志统计信息
const logChartRef = ref(null);
var logChart = null;
const getLogVector = async (params) => {
    try {
        const res = await getLogVectorApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            let xdata = data["time"];
            let ydata = data["value"];
            logChart.setOption(getOptions(xdata, ydata));
            setTimeout(() => {
                logChart.resize();
            })
        }
    } catch (error) {
        throw new Error(error);
    };
    addChartEvent([logChart]);
};

// 表格数据
const getOptions = (xdata, ydata) => {
    return {
        title: {
            text: ''
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            top: '10%',
            left: '2%',
            right: '2%',
            bottom: '6%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: xdata,
        },
        yAxis: {
            type: 'value',
            data: ydata
        },
        series: [
            {
                data: ydata,
                type: 'bar',
                smooth: true,
				areaStyle: {},

				stack: 'Total',
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(128, 255, 165)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(1, 191, 236)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
            }
        ]
    };
};

// 图表添加事件
const addChartEvent = (charts) => {
    charts.forEach(chart => {
        chart.getZr().on('click', (params) => {
            let pointInPixel = [params.offsetX, params.offsetY];
            if (chart.containPixel('grid', pointInPixel)) {
                let pointInGrid = chart.convertFromPixel({
                    seriesIndex: 0
                }, pointInPixel);
                let xIndex = pointInGrid[0]; 
                let handleIndex = Number(xIndex);
                let seriesObj = chart.getOption();
                let op = chart.getOption();
                //获得图表中点击的列
                let pre = op.xAxis[0].data[Number(xIndex)-1];
                let now = op.xAxis[0].data[handleIndex];
                let next = op.xAxis[0].data[Number(xIndex)+1]

                if (! pre) {
                    searchForm.time = [now, next]
                }

                if (! next) {
                    searchForm.time = [pre, now]
                }

                if (pre && now && next){
                    searchForm.time = [pre, next]
                }

                console.log(searchForm.time)

                getLog('query')
                //emits('setCurPointData', catchDataMap[month]);
                // console.log(handleIndex, seriesObj);
            };
        });
    });
};

// 实时
const getRealTimeLog = () => {
    hideLogChart();
    const { WS_LOG_URL } = window.config;
    const { env, app, pod, key } = searchForm;
    const { token } = globalStore;
    curBtn.value = 'real';
    let url = `${WS_LOG_URL}?env=${env}&app=${app}&token=${token}`;
    if (pod) (url = `${url}&pod=${pod}`);
    if (key) (url = `${url}&key=${key}`);

    socket = new WebSocket(url);

    socket.onopen = function () {
        console.log("连接状态：已连接");
        // 发送认证信息
        socket.send(JSON.stringify({
            type: 'auth',
            Authorization: `Bearer ${token}`
        }));
    }

    socket.onmessage = function (event) {
        const logdata = { 'content': event.data }
        const maxlines = 1000;
        if (queryLog.value.length > maxlines) {
            queryLog.value.splice(0, queryLog.value.length - maxlines);
        }
        queryLog.value.push(logdata)
        const scrollBox = document.getElementById('logScroll');
        scrollBox.scrollTop = scrollBox.scrollHeight;
    }

    socket.onclose = function () {
        console.log('关闭');
    }
};

// 下载
const { HELP_FILE_URL } = window.config;
const downloadCmd = ref('');
const isShowDownloadDialog = ref(false);
const logformat = ref('raw');
const logFormatOptions = [
    { "name": "jsonl", "label": "json" },
    { "name": "raw", "label": "raw" },
]

const getDownloadCmd = async () => {

    const { env, time, app, pod, key } = searchForm;
    if (app.length < 2) {
        ElMessage.warning('请选择应用名称！');
        return;
    }

    if (time.length < 2) {
        ElMessage.warning('请选择时间范围！');
        return;
    }

    let params = { env: env, app: app, pod: pod, logformat: logformat.value };

    if (time.length === 2) {
        params['start'] = time[0];
        params['end'] = time[1];
    }

    key && (params['key'] = key);
    try {
        const res = await downloadLogApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            downloadCmd.value = data;
        }
    } catch (error) {
        throw new Error(error);
    }
};

const dowload = async () => {
    isShowDownloadDialog.value = true;

    getDownloadCmd();

    setTimeout(() => {
        const copyBtn = document.getElementById('copyBtn');
        copyBtn.addEventListener('click', async () => {
            try {
                const msg = document.getElementById('linkUrl').innerText;
                await toClipboard(msg);
                ElMessage.success('复制成功！');
            } catch (error) {
                throw new Error(error);
            }
        })
    })
};

// 重置搜索选项
const resetSearchForm = () => {
    searchForm.env = '';
    searchForm.app = '';
    searchForm.pod = '';
    searchForm.key = '';
    queryLog.value = [];
}

</script>

<style lang="scss" scoped>
.log-search {
    padding-bottom: 0px;

    :deep(.el-form-item) {
        margin-bottom: 20px !important;
    }
}

.logBox {
    display: flex;
    flex-direction: column;
    background-color: #333333;
    height: 100%;
    border-radius: 5px;


    .infinite-list {
        // color: #BDBDC0;
        color: #fff;
        padding-right: 5px;
        word-wrap: break-word;

        .infinite-list-item {
            padding: 3px 0px;
            word-wrap: break-word;
        }

        // 日志上下文高亮锚点行内容
        .important {
            color: #00FF00;
            padding: 3px 0px;
            word-wrap: break-word;
        }
    }

    .logContent {
        padding: 10px;
        flex: 1;
        color: #BDBDC0;
    }
}

:deep(.table-search) {
    display: flex;
    padding: 18px 20px;
    margin-bottom: 10px;

    .el-form {
        flex: 1;

        .el-form-item {
            margin-right: 20px;
            margin-bottom: 0px;

            .el-input,
            .el-select,
            .el-date-editor--timerange {
                width: 100px;
            }

            .el-date-editor--datetimerange,
            .el-date-editor--daterange {
                width: 380px;
            }

            // 去除时间选择器上下 padding
            .el-range-editor.el-input__wrapper {
                padding: 0 10px;
            }

            // el-select 为多选时不换行显示
            .el-select__tags {
                overflow: hidden;
            }
        }
    }
}</style>
