<!--  应用监控  -->

<template>
    <div class="main-box">
        <div class="table-box">
            <!-- 查询表单 -->
            <div class="card table-search">
                <el-form ref="formRef" :model="searchForm" :inline="true">
                    <el-form-item label="选择应用">
                        <el-select v-model="searchForm.env" @change="getLogAppList" filterable clearable placeholder="环境" style="width: 100px;">
                            <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label" :value="item.env_name"/>
                        </el-select>
                        <el-select v-model="searchForm.app" @change="getPodList" filterable clearable placeholder="应用">
                            <el-option v-for="item in appOptions" :key="item.label" :label="item.label" :value="item.label"/>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="时间区间">
                        <el-select v-model="searchForm.trange" placeholder="请选择" filterable>
                            <el-option v-for="item in timeOptions" :key="item.trange" :label="item.label"
                                :value="item.trange" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="实例名称" :width="200">
                        <el-select v-model="searchForm.pod" placeholder="请选择" filterable clearable>
                            <el-option v-for="item in podOptions" :key="item" :label="item" :value="item">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <div class="search-operation">
                    <el-button type="primary" :icon="Search" @click="confirm">确定</el-button>
                    <el-button :icon="Delete" @click="reset">重置</el-button>
                </div>
            </div>
            <div class="card table echartBox">
                <div class="echartBox">
                    <div class="echart-item">
                        <div class="title">CPU使用(核)</div>
                        <div class="content">
                            <div class="item" ref="cpuEchartRef"></div>
                        </div>
                    </div>
                    <div class="echart-item">
                        <div class="title">MEM使用(MB)</div>
                        <div class="content">
                            <div class="item" ref="gpuEchartRef"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted, watch } from "vue";
import { getEnvByPermListApi } from '@/api/modules/releaseCenter';
import { getAppListApi, getMonitorTimeApi, getPodListApi, getMonitorDataApi } from '@/api/modules/applyCenter';
import * as echarts from "echarts";
import { useEcharts } from "@/hooks/useEcharts";
import { getTimeFromStamp } from '@/utils/util';

const defaultXData = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const defaultYData = [820, 932, 901, 934, 1290, 1330, 1320];

let cpuEachart = null;
let gpuEachart = null;

const timeOptions = ref([]);

const cpuEchartRef = ref(null);
const gpuEchartRef = ref(null);

const envOptions = ref([]);         // 环境列表
const appOptions = ref([]);         // 应用列表
const podOptions = ref([]);

const searchForm = reactive({
    env: "",
    app: "",
    pod: "",
    trange: "1"
});

// 获取环境列表数据
const getLogEnvList = async () => {
    const params ={ "permission": "log"};
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取应用列表数据
const getLogAppList = async () => {
    const params = { env_name: [searchForm.env] };
    try {
        const res = await getAppListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            appOptions.value = data;
            searchForm.app = data[0];
            searchForm.pod = '';
        }
    } catch (error) {
        throw new Error(error);
    }
};


onMounted(() => {
    getTimeList();
    initEcharts();
    getLogEnvList();
});

watch([searchForm.env, searchForm.app, searchForm.trange], () => {
    getPodList();
});

// 实例化图标
const initEcharts = () => {

    cpuEachart = echarts.init(cpuEchartRef.value);
    gpuEachart = echarts.init(gpuEchartRef.value);

    const options = getOptions(defaultXData, defaultYData);
    
    useEcharts(cpuEachart, options);
    useEcharts(gpuEachart, options);
};

// 获取时间范围列表数据
const getTimeList = async () => {
    try {
        const res = await getMonitorTimeApi();
        const { code, data } = res;
        if (code === 200 && data) {
            timeOptions.value = data;
        } else {
            timeOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};


// 获取实例列表
const getPodList = async () => {
    const { start, end } = getRangeTime(searchForm.trange);
    searchForm.pod = '';
    const params = { env: searchForm.env, app: searchForm.app, start, end };
    try {
        const res = await getPodListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            podOptions.value = data;
            searchForm.pod = data[0];
        }else{
            podOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 根据时间范围获取具体开始结束时间
const getRangeTime = (val) => {
    // 获取当前日期时间戳
    const now = new Date();
    const endTimeStamp = now.getTime();
    const startTimeStamp = endTimeStamp - Number(val) * 3600000;
    const start = getTimeFromStamp(startTimeStamp);
    const end = getTimeFromStamp(endTimeStamp);

    return { start, end };
};

// 确定
const confirm = async () => {
    try {
        const { env, trange, pod } = searchForm;
        const res = await getMonitorDataApi({ env_name: env, pod, trange });

        const { code, data } = res;
        if (code === 200 && data) {
            const { cpu, mem } = data;

            const cupOptions = getOptions(cpu.timeSt, cpu.monitorValue);
            const gpuOptions = getOptions(mem.timeSt, mem.monitorValue);

            cpuEachart.setOption(cupOptions);
            gpuEachart.setOption(gpuOptions);
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取表格配置项
const getOptions = (xdata, ydata) => {
    return {
        title: {
            text: ''
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: xdata
        },
        yAxis: {
            type: 'value',
            data: ydata
        },
        series: [
            {
                data: ydata,
                type: 'line',
                smooth: true
            }
        ]
    };
};

// 重置
const reset = () => {
    searchForm.app = [];
    searchForm.pod = "";
    searchForm.trange = "1";
    
    const options = getOptions(defaultXData, defaultYData);
    
    cpuEachart && cpuEachart.setOption(options);
    gpuEachart && gpuEachart.setOption(options);
};

</script>

<style lang="scss" scoped>
.echartBox {
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: space-between;

    .echart-item {
        width: 48%;
        border: 1px solid #e5e7eb;
        border-radius: 5px;
        display: flex;
        flex-direction: column;

        .title {
            padding: 10px 20px;
            font-family: DIN;
            font-size: 18px;
            font-weight: 700;
            border-bottom: 1px solid #e5e7eb;
        }

        .content {
            padding: 15px;
            width: 100%;
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;

            .item {
                height: 100%;
                width: 100%;
            }
        }
    }
}</style>