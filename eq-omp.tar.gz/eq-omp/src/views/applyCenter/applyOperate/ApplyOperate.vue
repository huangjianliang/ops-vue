<!--  应用操作 -->

<template>
    <div class="main-box">
        <div class="table-box">
            <!-- 查询表单 -->
            <div class="card table-search">
                <el-form ref="formRef" :model="searchForm" :inline="true">
                    <el-form-item label="环境名称">
                        <el-select v-model="searchForm.env_name" placeholder="请选择" filterable @change="envChange">
                            <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label"
                                :value="item.env_name" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="应用名称">
                        <el-select v-model="searchForm.app_name" placeholder="请选择" filterable @change="appChange">
                            <el-option v-for="item in appOptions" :key="item.app_name" :label="item.label"
                                :value="item.app_name" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="操作类型">
                        <el-select v-model="searchForm.replica" filterable placeholder="请选择">
                            <el-option v-for="item in operateOptions" :key="item.value" :label="item.label"
                                :value="item.value" :disabled="item.disabled"/>
                        </el-select>
                    </el-form-item>
                </el-form>
                <div class="search-operation">
                    <el-button type="primary" :icon="Search" @click="execute">执行</el-button>
                    <el-button :icon="Delete" @click="reset">重置</el-button>
                </div>
            </div>
            <div class="card table">
                <el-table ref="tableRef" :data="tableData" :border="true" :stripe="stripe" :tree-props="{ children: childrenName }">
                    <template v-for="item in tableColumns" :key="item">
                        <el-table-column :prop="item.prop" :label="item.label"
                            :width="item.width" :min-width="item.minWidth" :sortable="item.sortable"
                            :show-overflow-tooltip="item.prop !== 'operation'" :resizable="true" :fixed="item.fixed">
                            <template #default="scope" v-if="item.type !== 'index'">
                                {{ scope.row[item.prop] }}
                            </template>
                            <template #default="scope" v-if="item.type === 'index'">
                                {{ scope.$index + 1 }}
                            </template>
                        </el-table-column>
                    </template>
                    <template #empty>
                        <div class="table-empty">
                            <img src="@/assets/images/notData.png" alt="notData" />
                            <div>暂无数据</div>
                        </div>
                    </template>
                </el-table>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { getEnvByPermListApi } from '@/api/modules/releaseCenter';
import { getAppListApi, applyOperateApi } from '@/api/modules/applyCenter';
import { ElMessage } from 'element-plus';

const defaultOperateOptions = [
    {
        label: '停止服务',
        value: 'stop',
        disabled: false
    },
    {
        label: '启动服务',
        value: 'start',
        disabled: false
    },
    {
        label: '重启服务',
        value: 'reload',
        disabled: false
    }
];

const envOptions = ref([]);
const appOptions = ref([]);
const operateOptions = ref(defaultOperateOptions);

const tableData = ref([]);

const searchForm = reactive({
    env_name: '',
    app_name: '',
    replica: ''
});

const tableColumns = [
	{ 
	    type: "index", 
	    label: "序号", 
	    width: 80
	},
	{
		prop: "env_name",
		label: "环境名称",
	},
	{
		prop: "app_name",
		label: "应用名称",
	},
	{
		prop: "status",
		label: "状态",
	},
	{ 
	    prop: "deploy_time", 
	    label: "发布时间", 
	},
	{
		prop: "version",
		label: "版本",
		sortable: true
	}
];

onMounted(() => {
    getEnvList();
});

// 获取环境列表数据
const getEnvList = async () => {
    const params ={ "permission": "op"};
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
        } else {
            envOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取应用列表数据
const getAppList = async () => {
    const { env_name, app_name } = searchForm;
    try {
        const res = await getAppListApi({ "env_name":  [env_name]});
        const { code, data } = res;
        if (code === 200 && data) {
            appOptions.value = data;
            if(app_name){
                const target = data.find(item => item.app_name.includes(app_name.split('_')[0]));
                appChange(target.app_name);
            }
        } else {
            appOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 环境名称切换事件
const envChange = () => {
    searchForm.app_name = "";
    getAppList();
};

// 应用名称切换事件
const appChange = (val) => {
    searchForm.replica = '';
    const options = JSON.parse(JSON.stringify(operateOptions.value));
    const num = val.split('_');
    if(num[1] === "0"){
        operateOptions.value = options.map(item => {
            const {value} = item;
            value === 'start'?  item.disabled = false : item.disabled = true;
            return item;
        });
    }else{
        operateOptions.value = options.map(item => {
            const {value} = item;
            value === 'start'? item.disabled = true : item.disabled = false;
            return item;
        });
    }
};

// 执行
const execute = async () => {
    const { app_name, env_name, replica } = searchForm;
    if(!app_name) {
        ElMessage.warning('请选择应用名称！');
        return;
    }
    
    if(!replica) {
        ElMessage.warning('请选择操作类型！');
        return;
    }
    try {
        const appArr = app_name.split('_');
        const operateType = replica === 'stop'? replica: `${replica}-${appArr[1]}`;
        const res = await applyOperateApi({ app_name: appArr[0], env_name, replica: operateType });
        
        const { code, data } = res;
        if (code === 200 && data) {
            tableData.value = data;
            searchForm.replica = '';
            getAppList();
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 重置
const reset = () => {
    Object.keys(searchForm).forEach(key => searchForm[key] = "");
    tableData.value = [];
};

</script>



