<!-- 应用列表 -->

<template>
	<div class="main-box" v-if=isShow>
		<div class="table-box">
		    <ProTable ref="proTable" :columns="columns" :requestApi="getKafkaListApi" :initParam="initParam"></ProTable>
		</div>
	</div>
</template>

<script setup name="kafka">
import { ref, reactive, onMounted } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { getKafkaListApi, checkpermApi } from '@/api/modules/midCenter.js';
import { useGlobalStore } from '@/store';

// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认值为不存在的环境
	//"env_name": 'aaa',
	"pageNum": 1,
	"pageSize": 20
});

const isShow = ref(false)
const checkperm = async () => {
	const globalStore = useGlobalStore();
    const { token } = globalStore;

    try {
        const params = { "env": "nlt", "permission": "log", "token": token };
        const res = await checkpermApi(params);
        const { code, data } = res
        if (code === 200) {
            isShow.value = data
        } else {
            ElMessage.error('权限校验失败')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 表格配置项
const columns = [
	{
		prop: "env_name",
		label: "运行环境"
	},
	{ 
		type: "link", 
	    prop: "url", 
	    label: "控制台"
	},
];

onMounted(() => {
    checkperm();
});

</script>

