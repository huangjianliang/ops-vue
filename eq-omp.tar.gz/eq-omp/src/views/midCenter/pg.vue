<!-- 在主页面中定义 iframe -->
<template>
  <div v-if=isShow>
	<iframe ref="myIframe" :src="url" style="width: 100%; height: 800px;" allow-same-origin></iframe>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { checkpermApi } from '@/api/modules/midCenter.js';
import { useGlobalStore } from '@/store';

const isShow = ref(false);
const checkperm = async () => {
	const globalStore = useGlobalStore();
    const { token } = globalStore;
    try {
        const params = { "env": "nlt", "permission": "log", "token": token };
        const res = await checkpermApi(params);
        const { code, data } = res
        if (code === 200) {
            isShow.value = data
        } else {
            ElMessage.error('权限校验失败')
        }
    } catch (error) {
        throw new Error(error);
    }
}

export default {
  setup() {
	onMounted(() => {
		checkperm()
    });
	//console.log(isShow.value)
	const url = ref('https://ops.eacon.com/postgresql/#/');
	return {url, isShow};
  },
};

</script>
