<template>
    <div class="box">
        <Codemirror 
            class="code" 
            v-model="code" 
            :style="{ height: '100%' }" 
            :extensions="extensions" 
            :autofocus="true"
            :disabled="false" 
            @change="handleClick('change', $event)"/>
    </div>
</template>

<script setup>
import { ref } from "vue";
import { Codemirror } from "vue-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { oneDark } from "@codemirror/theme-one-dark";

const props = defineProps({
    content: {
        type: String,
        default: ''
    }
});

const emit = defineEmits(['updateContent'])

const code = ref(props.content);

const extensions = [javascript(), oneDark];

const handleClick = (type, val) => {
    console.log(type, val);
    emit('updateContent', val); 
};


</script>

<style lang="scss" scoped>
.box {
    width: 100%;
    height: 500px;
}

.code {
    width: 300px;
    height: 300px;
}


</style>

<style>

</style>