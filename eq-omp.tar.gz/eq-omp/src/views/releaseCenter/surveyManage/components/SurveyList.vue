<template>
    <div class="surveyList">
        <div class="searchBox card table-search">
            <el-form ref="form" :model="form" label-width="45px">
                <el-form-item label="项目">
                    <el-select v-model="searchForm.business" @change="handleSearch" placeholder="请选择项目" clearable>
                        <el-option v-for="item in businessOptions" :label="item.label" :value="item.value"
                            :key="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="版本">
                    <el-select v-model="searchForm.version" @change="handleSearch" placeholder="请选择版本" clearable>
                        <el-option v-for="item in versionOptions" :label="item" :value="item" :key="item"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div class="search-operation">
                <el-button type="primary" @click="dialogVisible = true">新建</el-button>
                <el-button @click="handleSearch">刷新</el-button>
                <el-button type="warning" @click="handleReset">查看所有</el-button>
            </div>
        </div>
        <div class="tableBox card table">
            <el-table :data="tableData" style="width: 100%" :border="true">
                <el-table-column label="序号" width="80" fixed="left">
                    <template #default="scope">
                        {{ (pageable.pageSize * (pageable.pageNum - 1)) + scope.$index + 1 }}
                    </template>
                </el-table-column>
                <el-table-column prop="version" label="版本" width="100">
                </el-table-column>
                <el-table-column prop="business" label="项目" width="150">
                    <template #default="scope">
                        {{ getBusiness(scope.row.business) }}
                    </template>
                </el-table-column>
                <el-table-column prop="detection_describe" label="更新内容" width="100">
                    <template #default="scope">
                        <el-button v-if="is_detection_manifest_create" :icon="Edit" circle @click="ShowDesDialog(scope.row)" />
                        <el-button v-else :icon="View" circle @click="ShowDesDialog(scope.row)" />
                    </template>
                </el-table-column>
                <el-table-column prop="create_person" label="创建人" width="100">
                </el-table-column>
                <el-table-column prop="update_person" label="修改人" width="100">
                </el-table-column>
                <el-table-column prop="create_time" label="创建时间" >
                </el-table-column>
                <el-table-column prop="update_time" label="修改时间" >
                </el-table-column>
                <el-table-column prop="status" label="状态" width="60">
                    <template #default="scope">
                        {{ statusMap[scope.row.status] }}
                    </template>
                </el-table-column>
                <el-table-column prop="operate" label="操作" fixed="right" width="260">
                    <template #default="scope">
                        <div style="text-align: left;" >

                        <el-button size="small" type="primary" @click="handlePreview(scope.row)"
                            v-show="getStatus(scope.row.status, 'preview')">查看</el-button>
                        <el-button size="small" type="primary" @click="handleEdit(scope.row)"
                            v-show="getStatus(scope.row.status, 'edit')">编辑</el-button>
                        <el-button size="small" type="danger" @click="handleOperation('open', scope.row)"
                            v-show="getStatus(scope.row.status, 'open')">打开</el-button>
                        <el-button size="small" type="danger" @click="handleOperation('close', scope.row)"
                            v-show="getStatus(scope.row.status, 'close')">关闭</el-button>
                        <el-button size="small" type="danger" @click="handleOperation('lock', scope.row)"
                            v-show="getStatus(scope.row.status, 'lock')">锁定</el-button>
                        <el-button size="small" type="success" @click="handleOperation('unlock', scope.row)"
                            v-show="getStatus(scope.row.status, 'unlock')">解锁</el-button>
                        <el-button size="small" type="success" @click="handleOperation('archive', scope.row)"
                            v-show="getStatus(scope.row.status, 'archive')">归档</el-button>
                        <el-button size="small" type="success" @click="handleOperation('unarchive', scope.row)"
                            v-show="getStatus(scope.row.status, 'unarchive')">拆档</el-button>
                        <el-button size="small" type="primary" @click="handleShare(scope.row)">分享</el-button>
                    </div>

                    </template>
                </el-table-column>
            </el-table>
            <Pagination :pageable="pageable" :handleSizeChange="handleSizeChange"
                :handleCurrentChange="handleCurrentChange" />
        </div>
    </div>
    <el-dialog title="新建提测单" v-model="dialogVisible" width="40%">
        <SurveyAdd @closeDialog="closeDialog" />
    </el-dialog>

    <el-dialog v-model="isShowDesDialog" title="描述" width="50%" destroy-on-close center top="5vh" :close-on-click-modal="false" :close-on-press-escape="false">
        <div v-if="is_detection_manifest_create">
            <v-md-editor v-model="desContent" height="400px" @save="handleDesEdit"></v-md-editor>
            <el-button type="primary" @click="handleDesEdit">保存</el-button>
        </div>
        <div v-else>
            <v-md-editor v-model="desContent" mode="preview" height="400px"></v-md-editor>
        </div>
    </el-dialog>

</template>

<script setup>
import { useGlobalStore } from '@/store';
import { ref, reactive, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import SurveyAdd from './SurveyAdd.vue';
import * as server from '@/api/modules/releaseCenter';
import Pagination from "../../../../components/ProTable/components/Pagination.vue";
import useClipboard from 'vue-clipboard3';
import { checkpermApi } from '@/api/modules/midCenter';

import { Edit, View, Select } from '@element-plus/icons-vue'

import VMdEditor from '@kangc/v-md-editor';
import '@kangc/v-md-editor/lib/style/base-editor.css';
import vuepressTheme from '@kangc/v-md-editor/lib/theme/vuepress.js';
import '@kangc/v-md-editor/lib/theme/style/vuepress.css';
import createCopyCodePlugin from '@kangc/v-md-editor/lib/plugins/copy-code/index';
import '@kangc/v-md-editor/lib/plugins/copy-code/copy-code.css';

import Prism from 'prismjs';

VMdEditor.use(vuepressTheme, {
  Prism,
});

VMdEditor.use(createCopyCodePlugin());

const props = defineProps({
    operateId: {
        type: String,
        default: ''
    },
    business: {
        type: Number,
        default: ''
    },
    version: {
        type: String,
        default: ''
    },
    businessName: {
        type: String,
        default: ''
    },
});

const dialogVisible = ref(false)

const searchForm = reactive({
    version: props.version,
    business: props.business
});

const pageable = reactive({
    // 当前页数
    pageNum: 1,
    // 每页显示条数
    pageSize: 25,
    // 总条数
    total: 0
});
// 状态列表
const statusMap = ref({
    0: '打开',
    1: '关闭',
    2: '锁定',
    3: '解锁',
    4: '归档',
    5: '拆档'
});
// 版本列表
const versionOptions = ref([]);
// 业务列表
const businessOptions = ref([]);
// 表格数据
const tableData = ref([]);

const emit = defineEmits(['changeType']);

onMounted(() => {
    // 获取版本列表
    getVersionOptions();
    // 获取业务列表
    getBusinessOptions();
    // 获取提测单列表
    getSurveyList();
    has_detection_manifest_create();
});

// 获取业务名称
const getBusiness = (val) => {
    const target = businessOptions.value.find(item => item.value === val);

    if (target) return target.label;

    return '--';
};

// 搜索
const handleSearch = () => {
    getVersionOptions();
    getSurveyList();
};

// 获取操作状态
const getStatus = (status, type) => {
    // 'open', 'close', 'lock', 'unlock', 'archive', 'unarchive', 'preview', 'edit'
    const statusMap = {
        0: ['preview', 'close', 'edit'],
        1: ['preview', 'open', 'lock'],
        2: ['preview', 'unlock', 'archive'],
        3: ['preview', 'open', 'lock'],
        4: ['preview', 'unarchive'],
        5: ['preview', 'open', 'archive']
    };
    return statusMap[status].includes(type);
};

// 获取版本列表
const getVersionOptions = async () => {
    try {
        const params = { business: searchForm.business };
        const res = await server.getVersionList(params);
        const { code, data } = res;
        if (code === 200) {
            versionOptions.value = data;
        } else {
            versionOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取业务列表 
const getBusinessOptions = async () => {
    try {
        const res = await server.getBusinessList({});
        const { code, data } = res;
        if (code === 200) {
            businessOptions.value = data;
        } else {
            businessOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取提测单列表 
const getSurveyList = async () => {
    const { version, business } = searchForm;
    const { pageNum, pageSize } = pageable;
    const params = {
        version: version || null,
        business: business === 0 ?  business : (business || null),
        pageNum,
        pageSize
    };

    try {
        const res = await server.getSurveyList(params);
        const { code, data, total } = res;
        if (code === 200) {
            tableData.value = data;
            pageable.total = total;
        } else {
            tableData.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 重置
const handleReset = () => {
    searchForm.version = '';
    searchForm.business = '';
    
    pageable.pageNum = 1;
    pageable.pageSize = 25;

    getSurveyList();
};

// 操作
const handleOperation = async (type, rowData) => {
    const apiFnMap = {
        'open': server.openSurvey,
        'close': server.closeSurvey,
        'lock': server.clockSurvey,
        'unlock': server.unlockSurvey,
        'archive': server.archivistSurvy,
        'unarchive': server.shiftGearSurvey,
    };

    const params = { id: rowData.id };

    try {
        const res = await apiFnMap[type](params);
        const { code, msg } = res;
        if (code === 200) {
            getSurveyList();
            ElMessage({
                type: 'success',
                message: type,
            });
        } else {
            ElMessage({
                type: 'error',
                message: type,
            });
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 分享
const handleShare = (row) => {
    const { toClipboard } = useClipboard()
    toClipboard("https://ops.eacon.com/#/releaseCenter/surveyManage/list/" + row.business + "/" + row.version + "/" + row.id);
    ElMessage.success('链接复制成功！');
};

// 查看
const handlePreview = (row) => {
    emit('changeType', 'preview', row.id, row.business, row.version, row.status, getBusiness(row.business));
};

// 编辑
const handleEdit = (row) => {
    emit('changeType', 'edit', row.id, row.business, row.version, '', getBusiness(row.business));
};

// 每页条数改变
const handleSizeChange = (val) => {
    pageable.pageNum = 1;
    pageable.pageSize = val;
    getSurveyList();
};

// 当前页改变
const handleCurrentChange = (val) => {
    pageable.pageNum = val;
    getSurveyList();
};

// 关闭对话框
const closeDialog = (type) => {
    dialogVisible.value = false;
    type === 'confirm' && getSurveyList();
};

// 提测描述编辑
const desContent = ref('');
const isShowDesDialog = ref(false);
const editRow = ref();
const ShowDesDialog = (row) => {
    editRow.value = row
    desContent.value = row.detection_describe;
    isShowDesDialog.value = true;
};

const handleDesEdit = async () => {
    const { version, business } = editRow.value;
    const params = { version, business, "detection_describe": desContent.value};
    
    try {
        const res = await server.editSurveyDes(params);
        const { code } = res;
        if(code === 200){
            ElMessage({
                type: 'success',
                message: '提测单描述保存成功!',
            })
        }else{
            ElMessage({
                type: 'serror',
                message: '提测单描述保存失败!',
            })
        }
    } catch (error) {
        throw new Error(error);
    }

    isShowDesDialog.value = false;
    getSurveyList();
};

// 是否有提测单创建权限
const is_detection_manifest_create = ref(false);
const has_detection_manifest_create = async () => {
    const globalStore = useGlobalStore();
    const { token } = globalStore;
    const params = {"token": token, "env": "ops", "permission": "detection_manifest_create"}

    try {
        const res = await checkpermApi(params);
        const { code, data } = res;
        if (code === 200) {
            if (data) {
                is_detection_manifest_create.value = true;
            }
        }
    } catch (error) {
        throw new Error(error);
    }

};

</script>

<style lang="scss" scoped>
.surveyList {
    width: 100%;
    height: 100%;

    .searchBox {
        display: flex;
        padding: 18px 20px;
        margin-bottom: 10px;
        display: flex;
        justify-content: space-between;

        .el-form {
            display: flex;

            .el-form-item {
                margin-right: 15px;
                margin-bottom: 0px;
            }
        }
    }

}</style>