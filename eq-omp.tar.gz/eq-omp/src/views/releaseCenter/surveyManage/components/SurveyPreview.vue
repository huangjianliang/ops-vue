<template>
    <div class="preview">
        <div class="header">
            <div class="left">
                <span class="label">{{props.businessName}}</span>
                <el-divider direction="vertical" />
                <span class="label">{{props.version}}</span>
                <el-divider direction="vertical" />
                <span class="label">对比版本</span>
                <el-select v-model="diffVersion" placeholder="请选择" @change="getViewList()">
                    <el-option v-for="item in options" :key="item" :label="item" :value="item"/>
                </el-select>
                <el-divider direction="vertical" />
                <span class="label">当前版本</span>
                <el-select v-model="historyVersion" placeholder="请选择" @change="diffVersion = null; getViewList()">
                    <el-option v-for="item in options" :key="item" :label="item" :value="item"/>
                </el-select>
                <el-divider direction="vertical" />
                <el-button v-if="isShowSelf" type="primary" @click="isShowSelf = false; getViewList()">查看全部</el-button>
                <el-button v-else="isShowSelf" type="primary" @click="showSelf">只看自己</el-button>
                <el-divider v-if="props.status == 0" direction="vertical" />
                <el-text v-if="props.status == 0" class="mx-1" type="warning" size="large">有还在编辑状态的内容，请联系提测单所有者关闭提测单！</el-text>
            </div>
            <div class="right">
                <el-button type="primary" @click="handleDeploy">一键部署</el-button>
                <el-button type="primary" @click="handleBack">返回</el-button>
            </div>
        </div>
        <div class="tableBox card table">
            <el-table :data="tableData" style="width: 100%" :border="true">
                <el-table-column label="序号" width="60">
                    <template #default="scope">
                        {{ scope.$index + 1 }}
                    </template>
                </el-table-column>
                <el-table-column prop="app_name" label="应用名称">
                    <template #default="scope">
                        <div :style="diffSurvyApi(scope.row.diff.app_name)">
                            <span v-if="scope.row.diff.app_name" class="clipSpan" @click="clip(scope.row.app_name)" >+ {{scope.row.app_name}}</span>
                            <span v-else class="clipSpan" @click="clip(scope.row.app_name)" >{{scope.row.app_name}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="app_version" label="版本号">
                    <template #default="scope">
                        <div :style="diffSurvyApi(scope.row.diff.app_version)">
                            <span class="clipSpan" @click="clip(scope.row.app_version)" >{{scope.row.app_version}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="app_description" label="提测说明" width="300">
                    <template #default="scope">
                        <div style="text-align: left;" :style="diffSurvyApi(scope.row.diff.app_description)">
                            <span style=" white-space: pre-wrap;">{{scope.row.app_description}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="app_db_script" label="中间件变更" width="100">
                    <template #default="scope">
                        <span v-if="scope.row.app_db_script == ''">无</span>
                        <el-button v-else @click="showContent('中间件变更 | ' + scope.row.app_name + ' | ' + scope.row.app_version, scope.row.app_db_script)" icon="View" size="small" :type="(scope.row.diff.app_db_script ? 'danger' : 'primary')"></el-button>
                    </template>
                </el-table-column>
                <el-table-column prop="app_config_cript" label="配置变更" width="100">
                    <template #default="scope">
                        <span v-if="scope.row.app_config_script == ''">无</span>
                        <el-button v-else @click="showContent('配置变更 | ' + scope.row.app_name + ' | ' + scope.row.app_version, scope.row.app_config_script)" icon="View" size="small" :type="(scope.row.diff.app_config_script ? 'danger' : 'primary')"></el-button>
                    </template>
                </el-table-column>
                <el-table-column prop="app_config_cript" label="部署">
                    <template #default="scope">
                        <el-button type="normal" @click="handleReleaseSingle(scope.row)">部署</el-button>
                    </template>
                </el-table-column>
                <el-table-column prop="create_person" label="创建人">
                </el-table-column>
                <el-table-column prop="update_time" label="修改时间">
                </el-table-column>
            </el-table>
        </div>
    </div>

    <div>
        <el-dialog title="一键部署（只同步版本，中间件变更和配置变更请手动同步！）" align-center v-model="showReleaseDialog" width="45%" show-close>
            <el-form label-width="100px">
                <el-form-item label="选择环境">
                    <el-space :size="size" spacer="">
                        <el-select v-model="releaseEnv" filterable placeholder="环境" @change="BatchDeployDiffList" style="width: 150px;">
                            <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label" :value="item.env_name"/>
                        </el-select>

                        <el-popconfirm title="确认一键部署？" @confirm="release">
                            <template #reference>
                                <el-button type="primary">一键部署</el-button>
                            </template>
                        </el-popconfirm>
                        <el-button icon="Refresh" @click="BatchDeployDiffList(); ElMessage.success('已刷新！')"></el-button>
                    </el-space>
                </el-form-item>

                <el-form-item label="部署预览">
                <el-table  :data="batchDiffData" style="width: 100%" :border="true">
                <el-table-column label="序号" width="60">
                    <template #default="scope">
                        {{ scope.$index + 1 }}
                    </template>
                </el-table-column>
                <el-table-column prop="app_name" label="应用名称">
                    <template #default="scope">
                        <span>{{scope.row.app_name}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="app_version_old" label="当前运行版本">
                    <template #default="scope">
                        <div style="color: green">
                            <span>{{scope.row.app_version_old}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="app_version_new" label="发布版本">
                    <template #default="scope">
                        <div style="color: red">
                            <span>{{scope.row.app_version_new}}</span>
                        </div>
                    </template>
                </el-table-column>
                </el-table>
                </el-form-item>  

            </el-form>
        </el-dialog>
    </div>


    <div>
        <el-dialog align-center v-model="showReleaseSingleDialog" width="30%" show-close>
            <el-form label-width="100px">
                <el-form-item label="应用">
                        <span>{{ release_app }}</span>
                    </el-form-item>
                    <el-form-item label="版本">
                        <span>{{ release_version }}</span>
                    </el-form-item>
                <el-form-item label="选择环境">
                        <el-select v-model="releaseEnv" filterable placeholder="环境" style="width: 100px;">
                            <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label" :value="item.env_name"/>
                        </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="releaseSingle">部署</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>

    <el-dialog v-model="isShowContent" center :title="titleContent">
        <div style="text-align: left;">
            <v-md-editor v-model="Content" mode="preview" @copy-code-success="clip" height="100%"></v-md-editor>
        </div>
    </el-dialog>

</template>

<script setup>
import { ref, onMounted } from 'vue';
import useClipboard from 'vue-clipboard3';
import { ElMessage } from 'element-plus';
import { useGlobalStore } from '@/store';
import { getEnvByPermListApi, BatchDeploy, applyReleaseExecute, BatchDeployDiff } from '@/api/modules/releaseCenter';

import * as server from '@/api/modules/releaseCenter';

import { useRouter } from "vue-router"

import { Refresh } from '@element-plus/icons-vue'

import VMdEditor from '@kangc/v-md-editor';
import '@kangc/v-md-editor/lib/style/base-editor.css';
import vuepressTheme from '@kangc/v-md-editor/lib/theme/vuepress.js';
import '@kangc/v-md-editor/lib/theme/style/vuepress.css';
import createCopyCodePlugin from '@kangc/v-md-editor/lib/plugins/copy-code/index';
import '@kangc/v-md-editor/lib/plugins/copy-code/copy-code.css';

import Prism from 'prismjs';

VMdEditor.use(vuepressTheme, {
  Prism,
});

VMdEditor.use(createCopyCodePlugin());


const clip = (msg) => {
    const { toClipboard } = useClipboard()
    toClipboard(msg);
    ElMessage.success('复制成功！');
};

const props = defineProps({
    operateId: {
        type: String,
        default: ''
    },
    business: {
        type: Number,
        default: ''
    },
    version: {
        type: String,
        default: ''
    },
    status: {
        type: Number,
        default: ''
    },
    businessName: {
        type: String,
        default: ''
    },
});

const diffVersion = ref(null);
const historyVersion = ref(null);
const tableData = ref();
const options = ref([]);

const emit = defineEmits(['changeType']);

onMounted(() => {
    // 获取历史版本
    getHistoryIds();
});

// 获取历史版本
const getHistoryIds = async () => {
    const params = {"id": props.operateId};
    
    try {
        const res = await server.getSurveyHistoryIds(params);
        const { code, data } = res;
        if (code === 200) {
            options.value = data;
            historyVersion.value = data[0];
            if (data.length > 1){
                diffVersion.value = data[1];
            }
            getViewList()
        } else {
            options.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取查看列表
const getViewList = async () => {
    const id = props.operateId;
    const params = {"id": id, "current_id": historyVersion.value, "contrast_id": diffVersion.value};
    
    try {
        const res = await server.surveyView(params);
        const { code, data } = res;
        if (code === 200) {
            tableData.value = data;
        } else {
            tableData.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 返回
const handleBack = () => {
    emit('changeType', 'list', props.operateId, props.business, props.version);
};

// 一键部署
const envOptions = ref([]);
const releaseItem = ref(null);
const releaseEnv = ref('');
const showReleaseDialog = ref(false);

const getReleaseEnvList = async () => {
    const params ={ "permission": "deploy"};
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
        }
    } catch (error) {
        throw new Error(error);
    }
};

const handleDeploy = () => {
    showReleaseDialog.value = true;
    getReleaseEnvList();
};

const router = useRouter();
const release = async () => {

    const params ={ id: props.operateId, env_name: releaseEnv.value};

    try {
        const res = await BatchDeploy(params);
        const { code } = res;
        if (code === 200) {
            ElMessage.success("已提交批量部署任务!跳转至应用发布页面！");
        }
    } catch (error) {
        throw new Error(error);
    }

    showReleaseDialog.value = false;
    router.push({path: "/releaseCenter/applyPublish"})
};

const showReleaseSingleDialog = ref(false);
const release_app = ref('');
const release_version = ref('');
const handleReleaseSingle = (row) => {
    release_app.value = row.app_name;
    release_version.value = row.app_version;
    showReleaseSingleDialog.value = true;
    getReleaseEnvList();
};

const releaseSingle = async () => {
    const globalStore = useGlobalStore();
    const { userInfo } = globalStore;
    try {
        await applyReleaseExecute({ app_name: release_app.value, product_name: release_version.value , env_name: releaseEnv.value, username: userInfo.cn_name });
        ElMessage.success('发布任务提交成功！请去应用发布页面查看状态！')
    } catch (error) {
        throw new Error(error);
    }
    showReleaseSingleDialog.value = false;
};

// 获取批量部署 diff 清单
const batchDiffData = ref('');
const BatchDeployDiffList = async () => {
    const id = historyVersion.value;
    const params = {"id": id, "env_name": releaseEnv.value};
    
    try {
        const res = await server.BatchDeployDiff(params);
        const { code, data } = res;
        if (code === 200) {
            if (data.length == 0) {
                batchDiffData.value = [{
                    "app_name": "已是最新版本",
                    "app_version_old": "已是最新版本",
                    "app_version_new": "已是最新版本"}]
            } else {
                batchDiffData.value = data;
            }
        } else {
            batchDiffData.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 只看自己
const isShowSelf = ref(false);
const showSelf = async () => {
    isShowSelf.value = true;
    const globalStore = useGlobalStore();
    const userName = globalStore.userInfo.cn_name;
    const data = tableData.value.filter((item) => item['create_person'] == userName);
    tableData.value = data;
};

// 内容预览
const isShowContent = ref(false);
const Content = ref('');
const titleContent  = ref('');
const showContent = (title, content) => {
    isShowContent.value = true;
    titleContent.value = title;
    Content.value = content;
};

// 版本比对
const diffSurvyApi = (diff) => {
    if (diff){
        return "color: red"
    }
};

</script>

<style lang="scss" scoped>
.preview {
    width: 100%;
    height: 100%;

    .header {
        display: flex;
        padding: 18px 20px;
        margin-bottom: 10px;
        display: flex;
        background-color: #fff;
        justify-content: space-between;

        .left {
            .label {
                display: inline-flex;
                justify-content: flex-end;
                align-items: flex-start;
                flex: 0 0 auto;
                font-size: var(--el-form-label-font-size);
                color: var(--el-text-color-regular);
                height: 32px;
                line-height: 32px;
                padding: 0 12px 0 0;
                box-sizing: border-box;
            }
        }

        .el-form {
            display: flex;

            .el-form-item {
                margin-right: 15px;
                margin-bottom: 0px;
            }
        }
    }

    .tableBox {
        height: calc(100%);
        background-color: #fff;
    }

}
</style>