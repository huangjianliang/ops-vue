<template>
    <div class="preview">
        <div class="header">
            <div class="left">
                <span class="label">{{props.businessName}}</span>
                <el-divider direction="vertical" />
                <span class="label">{{props.version}}</span>
                <el-divider direction="vertical" />
                <el-button type="primary" @click="showAdd">添加</el-button>
                <el-button v-if="isShowSelf" @click="isShowSelf = false; getTableList()">查看全部</el-button>
                <el-button v-else="isShowSelf" @click="showSelf">只看自己</el-button>
            </div>
            <div class="right">
                <el-button type="primary" @click="handleBack">返回</el-button>
            </div>
        </div>
        <div class="tableBox card table">
            <el-table :data="tableData" style="width: 100%;" :border="true">
                <el-table-column label="序号" width="60">
                    <template #default="scope">
                        {{ scope.$index + 1 }}
                    </template>
                </el-table-column>
                <el-table-column prop="app_name" label="应用名称">
                    <template #default="scope">
                        <div :style="diffSurvyApi(scope.row.diff.app_name)">
                            <span v-if="scope.row.diff.app_name" class="clipSpan" @click="clip(scope.row.app_name)" >+ {{scope.row.app_name}}</span>
                            <span v-else class="clipSpan" @click="clip(scope.row.app_name)" >{{scope.row.app_name}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="app_version" label="版本号">
                    <template #default="scope">
                        <div :style="diffSurvyApi(scope.row.diff.app_version)">
                            <span class="clipSpan" @click="clip(scope.row.app_version)" >{{scope.row.app_version}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="app_description" label="提测说明" width="300">
                    <template #default="scope">
                        <div style="text-align: left;" :style="diffSurvyApi(scope.row.diff.app_description)">
                            <span v-if="scope.row.app_description == ''">无</span>
                            <span v-else style="white-space: pre-wrap;">{{scope.row.app_description}}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column label="中间件变更" width="100">
                    <template #default="scope">
                        <span v-if="scope.row.app_db_script == ''">无</span>
                        <el-button v-else @click="showContent('中间件变更', scope.row.app_db_script)" icon="View" size="small" :type="(scope.row.diff.app_db_script ? 'danger' : 'primary')"></el-button>
                    </template>
                </el-table-column>
                <el-table-column label="配置变更" width="100">
                    <template #default="scope">
                        <span v-if="scope.row.app_config_script == ''">无</span>
                        <el-button v-else @click="showContent('配置变更', scope.row.app_config_script)" icon="View" size="small" :type="(scope.row.diff.app_config_script ? 'danger' : 'primary')"></el-button>
                    </template>
                </el-table-column>

                <el-table-column prop="update_time" label="修改时间">
                </el-table-column>

                <el-table-column prop="create_person" label="创建人">
                    <template #default="scope">
                        <span>{{ scope.row.create_person }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="update_person" label="修改人">
                    <template #default="scope">
                        <span>{{ scope.row.update_person }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="operate" label="操作" fixed="right">
                    <template #default="scope">
                        <el-button size="small" type="primary" @click="showEdit(scope.row)" :disabled="!hasEdit(scope.row.create_person)">编辑</el-button>
                        <el-popconfirm title="确认删除？" @confirm="showDelete(scope.row)">
                            <template #reference>
                                <el-button size="small" type="danger" :disabled="!hasEdit(scope.row.create_person)">删除</el-button>
                            </template>
                        </el-popconfirm>
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <el-dialog v-model="isShowAdd" :title="titleEdit" width="50%" destroy-on-close center top="5vh" :close-on-click-modal="false" :close-on-press-escape="false">
            <el-form label-width="100px">
                <el-form-item label="应用">
                    <el-select v-model="appAdd" filterable placeholder="应用" :disabled="titleEdit == '编辑'" @change="getVersionOptions(appAdd)" style="width: 250px;">
                            <el-option v-for="item in applyOptions" :key="item.app_name" :label="item.label" :value="item.app_name"/>
                    </el-select>
                    <el-select v-model="versionAdd" filterable placeholder="版本" style="width: 250px;">
                            <el-option v-for="item in versionOptions" :key="item.product_name" :label="item.label" :value="item.product_name"/>
                    </el-select>
                </el-form-item>

                <el-form-item label="提测说明">
                    <v-md-editor v-model="add_app_description" @save="handleEdit" @copy-code-success="clip" height="100%"></v-md-editor>
                </el-form-item>
                <el-form-item label="中间件变更">
                    <v-md-editor v-model="add_app_db_script" @save="handleEdit" @copy-code-success="clip" height="100%"></v-md-editor>
                </el-form-item>
                <el-form-item label="配置变更">
                    <v-md-editor v-model="add_app_config_script" @save="handleEdit" @copy-code-success="clip" height="100%"></v-md-editor>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="handleEdit">保存</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <el-dialog v-model="isShowContent" :title="titleContent">
            <div style="text-align: left;">
                <v-md-editor v-model="Content" mode="preview" @copy-code-success="clip" height="100%"></v-md-editor>
            </div>
        </el-dialog>

    </div>
</template>

<script setup>
import { ref, onMounted, reactive } from 'vue';

import { ElMessage } from 'element-plus';
import { useGlobalStore } from '@/store';
import { applyReleaseListApi, applyReleaseVersionListApi } from '@/api/modules/releaseCenter';
import SurveyEditDialog from './SurveyEditDialog.vue';
import * as server from '@/api/modules/releaseCenter';
import { checkpermApi } from '@/api/modules/midCenter';

import useClipboard from 'vue-clipboard3';
import { Edit, View, Select } from '@element-plus/icons-vue'

import VMdEditor from '@kangc/v-md-editor';
import '@kangc/v-md-editor/lib/style/base-editor.css';
import vuepressTheme from '@kangc/v-md-editor/lib/theme/vuepress.js';
import '@kangc/v-md-editor/lib/theme/style/vuepress.css';
import createCopyCodePlugin from '@kangc/v-md-editor/lib/plugins/copy-code/index';
import '@kangc/v-md-editor/lib/plugins/copy-code/copy-code.css';

import Prism from 'prismjs';

VMdEditor.use(vuepressTheme, {
  Prism,
});

VMdEditor.use(createCopyCodePlugin());

const props = defineProps({
    operateId: {
        type: String,
        default: ''
    },
    business: {
        type: Number,
        default: ''
    },
    version: {
        type: String,
        default: ''
    },
    status: {
        type: Number,
        default: ''
    },
    businessName: {
        type: String,
        default: ''
    },
});

const globalStore = useGlobalStore();

const tableData = ref([]);
const applyOptions = ref([]);
const versionOptions = ref([]);
const versionLoading = ref(false);

let editData = reactive({
    index: 0,
    key: '',
    title: '',
    content: ''
});

const emit = defineEmits(['changeType']);

onMounted(() => {
    getTableList();
    getApplyOptions();
    has_detection_manifest_create();
});

// clip
const clip = (msg) => {
    const { toClipboard } = useClipboard()
    toClipboard(msg);
    ElMessage.success('复制成功！');
};

// 获取提测单编辑列表
const getTableList = async () => {
    const params = {id: props.operateId};
    try {
        const res = await server.editSurvey(params);
        const { code, data=[] } = res;
        if (code === 200) {
            const newData = data.map(item => {
                return {
                    ...item,
                    item_state: 1
                }
            });
            tableData.value = newData;
        } else {
            tableData.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取应用options
const getApplyOptions = async () => {
    try {
        const res = await applyReleaseListApi();
        const { code, data } = res;
        if(code === 200){
            applyOptions.value = data;
        }else{
            applyOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }    
};

// 获取版本号options
const getVersionOptions = async (app_name) => {
    versionAdd.value = '';
    if(!app_name) {
        versionOptions.value = [];
    }
    
    versionLoading.value = true;
    try {
        const res = await applyReleaseVersionListApi({app_name});
        const { code, data } = res;
        if(code === 200){
            versionOptions.value = data;
        }else{
            versionOptions.value = [];
        }
        versionLoading.value = false;
    } catch (error) {
        throw new Error(error);
    }    
};

// 添加编辑应用
const isShowAdd = ref(false);
const appAdd = ref('');
const versionAdd = ref('');
const add_app_description = ref('');
const add_app_db_script = ref('');
const add_app_config_script = ref('');
const add_state = ref(0);
const titleEdit = ref('');
const showAdd = () => {
    cleanEdit();
    titleEdit.value = '添加';
    add_state.value = 0;
    isShowAdd.value = true;
};
const showEdit = (rows) => {
    titleEdit.value = '编辑';
    getVersionOptions(rows.app_name);

    appAdd.value = rows.app_name;
    versionAdd.value = rows.app_version;
    add_app_description.value = rows.app_description;
    add_app_db_script.value = rows.app_db_script;
    add_app_config_script.value = rows.app_config_script;
    add_state.value = 1;

    isShowAdd.value = true;
};
const showDelete = (rows) => {
    appAdd.value = rows.app_name;
    versionAdd.value = rows.app_version;
    add_app_description.value = rows.app_description;
    add_app_db_script.value = rows.app_db_script;
    add_app_config_script.value = rows.app_config_script;
    add_state.value = 2;
    handleEdit();
};
const handleEdit = () => {
    const userName = globalStore.userInfo.cn_name;
    const data = {
        item_state: add_state.value,
        app_name: appAdd.value,
        app_version: versionAdd.value,
        app_description: add_app_description.value,
        app_db_script: add_app_db_script.value,
        app_config_script: add_app_config_script.value,
        create_person: userName,
        update_person: userName
    };

    const params = {
        parent_id: props.operateId,
        manifest_item: [data]
    };

    handleSave(params);
};
const cleanEdit = () => {
    appAdd.value = '';
    versionAdd.value = '';
    add_app_description.value = '';
    add_app_db_script.value = '';
    add_app_config_script.value = '';
    add_state.value = 0;
};

// 返回
const handleBack = () => {
    emit('changeType', 'list', props.operateId, props.business, props.version);
};

// 保存
const handleSave = async (params) => {    
    try {
        const res = await server.saveSurvey(params);
        const { code } = res;
        if (code === 200) {
            ElMessage({
                type: 'success',
                message: '保存成功!',
            });
        } else {
            ElMessage({
                type: 'error',
                message: '保存失败!',
            });
        }
    } catch (error) {
        throw new Error(error);
    }
    getTableList();
    isShowAdd.value = false;
    isShowSelf.value = false;
    cleanEdit();
};

// 只看自己
const isShowSelf = ref(false);
const showSelf = async () => {
    isShowSelf.value = true;
    const globalStore = useGlobalStore();
    const userName = globalStore.userInfo.cn_name;
    const data = tableData.value.filter((item) => item['create_person'] == userName);
    tableData.value = data;
};

// 是否有提测单创建权限
const is_detection_manifest_create = ref(false);
const has_detection_manifest_create = async () => {
    const { token } = globalStore;
    const params = {"token": token, "env": "ops", "permission": "detection_manifest_create"}

    try {
        const res = await checkpermApi(params);
        const { code, data } = res;
        if (code === 200) {
            if (data) {
                is_detection_manifest_create.value = true;
            }
        }
    } catch (error) {
        throw new Error(error);
    }

};

// 判断是否有编辑权限
const hasEdit = (user) => {
    // 提测单创建权限不受限制

    if (is_detection_manifest_create.value){
        return true;
    }

    // 创建人为自己才让编辑
    if (user == globalStore.userInfo.cn_name){
        return true;
    } else {
        return false;
    }

    return false;
};

// 内容预览
const isShowContent = ref(false);
const Content = ref('');
const titleContent = ref('');
const showContent = (title, content) => {
    isShowContent.value = true;
    titleContent.value = title;
    Content.value = content;
};

// 版本比对
const diffSurvyApi = (diff) => {
    if (diff){
        return "color: red"
    }
};

</script>

<style lang="scss" scoped>
.preview {
    width: 100%;
    height: 100%;

    .header {
        display: flex;
        padding: 18px 20px;
        margin-bottom: 10px;
        display: flex;
        background-color: #fff;
        justify-content: space-between;

        .el-form {
            display: flex;

            .el-form-item {
                margin-right: 15px;
                margin-bottom: 0px;
            }
        }
    }

    .tableBox {
        height: calc(100%);
        background-color: #fff;
    }
}
</style>