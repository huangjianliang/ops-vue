<template>
    <el-form :model="form" label-width="60px" :rules="rules" ref="formRef">
        <el-form-item label="版本" prop="version">
            <el-input v-model="form.version" placeholder="请输入版本"/>
        </el-form-item>
        <el-form-item label="项目" prop="business">
            <el-select v-model="form.business" class="m-2" placeholder="请选择项目" size="middle" style="width: 100%;">
                <el-option v-for="item in businessOptions" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
        </el-form-item>

        <el-form-item label="描述">
            <v-md-editor v-model="desContent" @copy-code-success="clip" height="400px"></v-md-editor>
        </el-form-item>

        <el-form-item>
            <div class="btns">
                <el-button type="primary" @click="onSubmit(formRef)">确定</el-button>
                <el-button @click="handleCancel">取消</el-button>
            </div>
        </el-form-item>
    </el-form>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';

import * as server from '@/api/modules/releaseCenter';

import VMdEditor from '@kangc/v-md-editor';
import '@kangc/v-md-editor/lib/style/base-editor.css';
import vuepressTheme from '@kangc/v-md-editor/lib/theme/vuepress.js';
import '@kangc/v-md-editor/lib/theme/style/vuepress.css';
import createCopyCodePlugin from '@kangc/v-md-editor/lib/plugins/copy-code/index';
import '@kangc/v-md-editor/lib/plugins/copy-code/copy-code.css';

import Prism from 'prismjs';

VMdEditor.use(vuepressTheme, {
  Prism,
});

VMdEditor.use(createCopyCodePlugin());

const formRef = ref(null);

const form = reactive({
    version: '',
    business: ''
});

const businessOptions = ref([
    {
        label: '蜂群',
        value: 0
    },
    {
        label: '数据管理平台',
        value: 1
    }
]);

const rules = reactive({
    version: [
        { required: true, message: '请输入版本', trigger: 'blur' },
    ],
    business: [
        { required: true, message: '请选择业务', trigger: 'change' },
    ],
});

const desContent = ref('');

const emit = defineEmits(['closeDialog'])

onMounted(() => {
    // 获取业务列表
    getBusinessOptions();
});

// 获取业务列表 
const getBusinessOptions = async () => {
    try {
        const res = await server.getBusinessList({});
        const { code, data } = res;
        if (code === 200) {
            businessOptions.value = data;
        } else {
            businessOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 提交
const onSubmit = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid, fields) => {
        if (valid) {
            createSurvey();
        } else {
            console.log('error submit!', fields)
        }
    })
};

// 创建提测单
const createSurvey = async () => {
    const { version, business } = form;
    const params = { version, business, "detection_describe": desContent.value};
    
    try {
        const res = await server.createSurvey(params);
        const { code } = res;
        if(code === 200){
            emit('closeDialog', 'confirm');
            ElMessage({
                type: 'success',
                message: '提测单创建成功!',
            })
        }else{
            ElMessage({
                type: 'serror',
                message: '提测单创建失败!',
            })
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 取消
const handleCancel = () => {
    emit('closeDialog', 'cancel');
};

</script>

<style lang="scss" scoped>
.btns{
    margin-top: 10px;
    width: 100%;
    display: flex;
    justify-content: flex-end;
}
</style>