<!--  提测单管理  -->

<template>
    <div class="surveyContainer">
        <component :is="curComponent" @changeType="changeType" :operateId="operateId" :businessName="operateBusinessName" :business="operateBusiness" :version="operateVersion" :status="operateStatus"></component>
    </div>
</template>

<script setup>
import { ref, reactive, onBeforeMount } from 'vue';
import SurveyList from './components/SurveyList.vue';
import SurveyEdit from './components/SurveyEdit.vue';
import SurveyPreview from './components/SurveyPreview.vue';
import { useRoute, useRouter } from "vue-router";
import { useGlobalStore } from '@/store';

let componets = reactive({
    'list': SurveyList,
    'edit': SurveyEdit,
    'preview': SurveyPreview,
});

const operateBusiness = ref('');
const operateBusinessName = ref('');
const operateVersion = ref('');
const operateId = ref('');
const operateStatus = ref('');

const curComponent = ref(componets['list']);

const changeType = (type, id='', business='', version='', status='', businessName='') => {
  curComponent.value = componets[type];
  operateId.value = id;
  operateBusiness.value = business;
  operateVersion.value = version;
  operateStatus.value = status;
  operateBusinessName.value = businessName;
};

// 接入传参
function getParams(){
  var route = useRoute();
  if (route.params.type) {
    operateBusiness.value = Number(route.params.business);
    operateVersion.value = route.params.version;
    operateId.value = route.params.id;
    curComponent.value = componets[route.params.type];
  }
}

onBeforeMount(() => {
  const globalStore = useGlobalStore();
  const { token } = globalStore;
  if (token == "") {
    const router = useRouter();
    router.push({"name": "login"})
  }
  getParams();
})

</script>

<style lang="scss" scoped>
.surveyContainer {
    width: 100%;
    height: calc(100vh - 225px);
}
</style>