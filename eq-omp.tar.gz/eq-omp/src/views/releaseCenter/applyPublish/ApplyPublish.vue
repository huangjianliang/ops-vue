<!-- 应用发布 -->

<template>
    <div class="main-box">
        <div class="table-box">
			<ProTable ref="proTable"  :columns="columns" :requestApi="confirm" :initParam="initParam" searchLabel="发布" resetLabel="刷新"></ProTable>
		</div>
        <div>
            <el-dialog :title="logInfo" center v-model="dialogVisible" width="80%" :before-close="clearLog" show-close>
                <div id="log" style="overflow-y: auto; height: 600px; font-size: 16px; font-family: Ubuntu Mono, Droid Sans Mono, monospace; background-color: #300a24; color: white;">
                <span v-html="logContent"></span>
                </div>>
            </el-dialog>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { useGlobalStore } from '@/store';
import { applyReleaseListApi, applyReleaseVersionListApi, getEnvByPermListApi, applyReleaseExecute, getApplyReleaseLog, getDeployHistory } from '@/api/modules/releaseCenter';
import { ElMessage } from "element-plus";

const proTable = ref();

const initParam = reactive({
    "app_name": "",
    "product_name": "",
    "env_name": "",
	"pageNum": 1,
	"pageSize": 20,
});

const logInfo = ref('');
const logContent = ref('');
const dialogVisible = ref(false);

const globalStore = useGlobalStore();

// 获取应用列表数据
const getApplyList = async () => {
    try {
        const res = await applyReleaseListApi();
        return res
    } catch (error) {
        throw new Error(error);
    }    
};

// 获取版本列表数据
const getVersionList = async (params) => {
    const {app_name} = params;
    
    try {
        const res = await applyReleaseVersionListApi({app_name});
        return res
    } catch (error) {
        throw new Error(error);
    }    
};

// 获取环境列表数据
const getEnvList = async() => {
    const params ={ "permission": "deploy"};
    try {
        const res = await getEnvByPermListApi(params);
        return res
    } catch (error) {
        throw new Error(error);
    }    
};

// 发布
const release = async (params) => {
    const { app_name, product_name, env_name } = params;
    const { userInfo } = globalStore;
    logContent.value = '';
    try {
        await applyReleaseExecute({ app_name, product_name, env_name, username: userInfo.cn_name });
        ElMessage.success('发布任务提交成功！请稍后刷新页面！')
    } catch (error) {
        throw new Error(error);
    }  
};

// 获取日志
const stopLog = ref(false)

const getLog = async (item, num) => {
    if (! num > 0) {
        logContent.value = '';
        dialogVisible.value = true;
        logInfo.value = '应用名称：' + item['app_name'] + '，' + '版本：' + item['product_name'] + '环境：' + item['env_name'];
    }
    const build_id = item['id'];
    const res = await getApplyReleaseLog({build_id, offset: num});
    const {code, data} = res;
    if(code === 200 && data) {
        const { is_running, text, offset, version, result } = data;
        logContent.value = logContent.value + text;
        if (is_running) {
            await sleep(1000);
            const scrollBox = document.getElementById('log');
            scrollBox.scrollTop = scrollBox.scrollHeight;
            if (stopLog.value) {
                stopLog.value = false
                return
            }
            getLog(item, offset);
        }
    }
};

//sleep
async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 获取任务列表
const confirm = async (params) => {
    try {
        if (params['app_name'].length > 0  && params['product_name'].length > 0 && params['env_name'].length > 0) {
            console.log('参数不为空，执行编译')
            console.log(params)
            release(params)
            await sleep(3000)
            const res = await getDeployHistory(params);
            return res
        } else {
            const res = await getDeployHistory(params);
            return res
        }
    } catch (error) {
        throw new Error(error);
    }
};

const clearLog = () => {
    dialogVisible.value = false
    logContent.value = ''
    logInfo.value = ''
    stopLog.value = true
}

const columns = [
    {
		prop: "id",
		label: "ID",
	},
    {
		prop: "app_name",
		label: "应用",
		search: true,
        clip: true,
		searchType: "select",
        width: 200,
		enum: getApplyList,
		searchProps: { label: "label", value: "app_name" },
        changeProps: { childProp: "product_name", api: getVersionList}
	},
    { 
	    prop: "product_name", 
	    label: "版本",
		search: true,
        clip: true,
		searchType: "select",
        width: 200,
		enum: getVersionList,
		searchProps: { label: "label", value: "product_name" },
	},
    {
		prop: "env_name",
		label: "环境",
		search: true,
		searchType: "select",
		enum: getEnvList,
		searchProps: { label: "label", value: "env_name" },
	},
    { 
	    prop: "timestamp", 
	    label: "执行时间",
	},
    { 
        type: "jenkins_status",
	    prop: "building", 
	    label: "执行状态",
	},
    { 
	    prop: "operate_personnel", 
	    label: "执行人员",
	},
    { 
        type: "button",
	    prop: "env_name", 
	    label: "查看日志",
        action: getLog
	},
    { 
        type: "color",
	    prop: "result", 
	    label: "执行结果",
	},
    
];

</script>
<style lang="scss" scoped>
</style>

