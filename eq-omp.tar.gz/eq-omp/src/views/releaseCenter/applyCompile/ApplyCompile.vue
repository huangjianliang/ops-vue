<!-- 应用编译 -->

<template>
    <div class="main-box">
        <div class="table-box">
			<ProTable ref="proTable"  :columns="columns" :requestApi="confirm" :initParam="initParam" searchLabel="编译" resetLabel="刷新"></ProTable>
		</div>
        <div>
            <el-dialog :title="logInfo" center v-model="dialogVisible" width="80%" :before-close="clearLog" show-close>
                <div id="log" style="overflow-y: auto; height: 600px; font-size: 16px; font-family: Ubuntu Mono, Droid Sans Mono, monospace; background-color: #300a24; color: white;">
                <span v-html="logContent"></span>
                </div>>
            </el-dialog>
        </div>

        <div>
            <el-dialog align-center v-model="showReleasDialog" width="30%" show-close>
                <el-form label-width="100px">
                    <el-form-item label="应用">
                        <span>{{ releaseItem["app_name"] }}</span>
                    </el-form-item>
                    <el-form-item label="版本">
                        <span>{{ releaseItem["product_name"] }}</span>
                    </el-form-item>
                    <el-form-item label="选择环境">
                        <el-select v-model="releaseEnv" filterable placeholder="环境" style="width: 100px;">
                            <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label" :value="item.env_name"/>
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="release">发布</el-button>
                    </el-form-item>
                </el-form>
            </el-dialog>
        </div>

    </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { useGlobalStore } from '@/store';
import { applyCompileListApi, applyCompileBranchListApi, applyReleaseExecute, applyCompileExecuteApi, getApplyCompileLogApi, getBuildHistory, getEnvByPermListApi } from '@/api/modules/releaseCenter';
import { ElMessage } from "element-plus";
import { useRouter } from "vue-router"

const proTable = ref();

const initParam = reactive({
    "app_name": "",
    "branch_name": "",
	"pageNum": 1,
	"pageSize": 20,
});

const dialogVisible = ref(false);
const logContent = ref("");
const logInfo = ref("");
const showReleasDialog = ref(false);

const globalStore = useGlobalStore();

// 获取分支列表数据
const getBranchList = async (item) => {
    const app_name = item["app_name"];
    const res = await applyCompileBranchListApi({app_name});
    return res;
};

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 获取任务列表
const confirm = async (params) => {
    console.log(params)
    try {
        if (params['app_name'].length > 0  && params['branch_name'].length > 0) {
            console.log('参数不为空，执行编译')
            console.log(params)
            compile(params)
            await sleep(3000)
            const res = await getBuildHistory(params);
            return res
        } else {
            const res = await getBuildHistory(params);
            return res
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 编译
const compile = async (params) => {
    const {app_name, branch_name} = params;
    const { userInfo } = globalStore;
    logContent.value = '';
    await applyCompileExecuteApi({app_name, branch_name, arch_unit: "cpu", username: userInfo.cn_name });
    ElMessage.success('编译任务提交成功！请稍后刷新页面！')
};
 
// 获取日志
const stopLog = ref(false)

const getLog = async (item, num) => {
    // 第一次请求
    if (! num > 0) {
        logContent.value = '';
        dialogVisible.value = true;
        logInfo.value = '应用名称：' + item['app_name'] + '，' + '分支：' + item['branch_name'] + '，' + '版本：' + item['product_name'];
    }
    const build_id = item['id'];
    const res = await getApplyCompileLogApi({build_id, offset: num});
    const {code, data} = res;
    if(code === 200 && data) {
        const { is_running, text, offset, version, result } = data;
        logContent.value = logContent.value + text;
        console.log(is_running)
        if (is_running) {
            await sleep(1000);
            const scrollBox = document.getElementById('log');
            scrollBox.scrollTop = scrollBox.scrollHeight;
            if (stopLog.value) {
                stopLog.value = false
                return
            }
            getLog(item, offset);
        }
    }
};

const clearLog = () => {
    dialogVisible.value = false
    logContent.value = ''
    logInfo.value = ''
    stopLog.value = true
}

// 发布
const envOptions = ref([]);
const releaseItem = ref(null);
const releaseEnv = ref('');

const getReleaseEnvList = async () => {
    const params ={ "permission": "deploy"};
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
        }
    } catch (error) {
        throw new Error(error);
    }
};

const releaseDialog = async (item) => {
    releaseItem.value = item;
    getReleaseEnvList();
    showReleasDialog.value = true;
};

const router = useRouter();
const release = async () => {
  
    const { app_name, product_name } = releaseItem.value;
    const { userInfo } = globalStore;
    try {
        await applyReleaseExecute({ app_name, product_name, env_name: releaseEnv.value, username: userInfo.cn_name });
        ElMessage.success('发布任务提交成功！跳转至应用发布页面！')
    } catch (error) {
        throw new Error(error);
    }

    showReleasDialog.value = false;
    router.push({path: "/releaseCenter/applyPublish"})
};

const columns = [
    {
		prop: "id",
		label: "ID",
        width: 100,
	},
	{
		prop: "app_name",
		label: "应用",
		search: true,
        clip: true,
		searchType: "select",
        width: 200,
		enum: applyCompileListApi,
		searchProps: { label: "label", value: "app_name" },
        changeProps: { childProp: "branch_name", api: getBranchList}
	},
    { 
	    prop: "branch_name", 
	    label: "分支",
        search: true,
		searchType: "select",
	    enum: getBranchList,
		searchProps: { label: "label", value: "branch_name" },
	},
    { 
	    prop: "commit_id", 
	    label: "提交",
        width: 150,
        clip: true,
	},
    { 
	    prop: "product_name", 
	    label: "版本",
        width: 200,
        clip: true,
	},
    { 
	    prop: "timestamp", 
	    label: "时间",
        width: 200,
	},
    { 
        type: "jenkins_status",
	    prop: "building", 
	    label: "状态",
	},
    { 
        type: "button",
	    prop: "app_name", 
	    label: "发布",
        action: releaseDialog
	},
    { 
	    prop: "operate_personnel", 
	    label: "执行者",
	},
    { 
        type: "button",
	    prop: "app_name", 
	    label: "日志",
        action: getLog
	},
    { 
        type: "color",
	    prop: "result", 
	    label: "结果",
	},
    
];

</script>

<style lang="scss" scoped>
</style>



