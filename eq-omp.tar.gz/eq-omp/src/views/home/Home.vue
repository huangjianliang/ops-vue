<template>
	<div class="home card">
		<header>
			<div v-for="(item, index) in safeOperateDatas" :style="{ 'background': colors[index] }" class="item">
				<span>{{ item.Env }}连续</span>
				<span class="num">{{ item.Days }}天</span>
				<span>无故障</span>
			</div>
		</header>
		<main>
			<div class="main-left">
				<div class="header">
					<div class="header-left">
						<div class="title">SLA趋势</div>
					</div>
					<div class="header-right">
						<div class="divide"></div>
						<el-select v-model="envName" class="m-2" placeholder="Select" @change="envNameChange">
							<el-option v-for="item in envOptions" :key="item.env_name" :label="item.env_describe" :value="item.env_name" />
						</el-select>
					</div>
				</div>
				<div class="echartBox">
					<div ref="echartsRef" class="card content-box"></div>
				</div>
			</div>
			<div class="main-right">
				<div class="title">SLA实时</div>
				<div class="content">
					<div v-for="(item, index) in slaRealTimeDatas" :style="{ 'background': colors[index] }" class="item">
						<span class="num">{{ item.sla }}%</span>
						<span>{{ item.env }}</span>
					</div>
				</div>
			</div>
		</main>
	</div>
</template>

<script setup name="home">
import { onMounted, ref } from 'vue';
import { getOperateDaysApi, getRealTimeSlaApi, getTrendSlaApi } from '../../api/modules/home';
import { getEnvListApi } from '../../api/modules/release';
import * as echarts from "echarts";
import { useEcharts } from "@/hooks/useEcharts";

let myChart = null;
const echartsRef = ref(null);

const envOptions = ref([]);

const colors = ['#009DFF', '#44D7B6', '#F95555'];

// 环境名称
const envName = ref('qas');

// 安全运营数据
const safeOperateDatas = ref();

// sla实时数据
const slaRealTimeDatas = ref([]);

onMounted(() => {
	getOperateDays();   
	getRealTimeSla();
	getTrendSla();
	getEnvList();

	initEchart();
});

// 环境切换时间
const envNameChange = () => {
	getTrendSla();
};

const initEchart = () => {
	myChart = echarts.init(echartsRef.value);
	
	const xdata = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
	const ydata = [820, 932, 901, 934, 1290, 1330, 1320];
	
	const options = getOptions(xdata, ydata);

	useEcharts(myChart, options);
};

// 获取表格配置项
const getOptions = (xdata, ydata) => {
	return {
		tooltip: {
            trigger: 'axis'
        },
		grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
		xAxis: {
			type: 'category',
			data: xdata
		},
		yAxis: {
			min: 99.90,
			max: 100,
			interval: 0.01,
			type: 'value',
			axisLabel: {
		        formatter: '{value}%'
		    },
			data: ydata
		},
		series: [
			{
				data: ydata,
				type: 'line',
				smooth: true
			}
		]
	};
};

// 获取运营天数
const getOperateDays = async () => {
	try {
		const res = await getOperateDaysApi({});
		const {code, data} = res;
		if(code === 200 && data) {
			safeOperateDatas.value = data;
		}
	} catch (error) {
		console.log(error)
	}
};

// 获取实时sla数据
const getRealTimeSla = async () => {
	try {
		const res = await getRealTimeSlaApi({});
		const {code, data} = res;
		if(code === 200 && data) {  
			slaRealTimeDatas.value = data;
		}
	} catch (error) {
		console.log(error)
	}
};

// 获取趋势sla数据
const getTrendSla = async () => {
	try {
		const params = { env: envName.value};
		const res = await getTrendSlaApi(params);
		const {code, data} = res;
		if(code === 200 && data) {
			const {time, value} = data;
			const options = getOptions(time, value);
			myChart && myChart.setOption(options);
		}
	} catch (error) {
		console.log(error)
	}
};

// 获取环境列表
const getEnvList = async () => {
	try {
		const res = await getEnvListApi({});
		const {code, data} = res;
		if(code === 200 && data) {
			envOptions.value = data.filter(item => {
				return (item.env_type === "生产环境" && item.env_describe !== '南露天私有化');
			});
		}
	} catch (error) {
		console.log(error);
	}
};

</script>

<style scoped lang="scss">
@import "./Home.scss";
</style>
