<template>
	<div class="card content-box">
		<iframe src="http://portal.eacon.com/" frameborder="0" class="full-iframe"></iframe>
	</div>
</template>

<script setup ></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
