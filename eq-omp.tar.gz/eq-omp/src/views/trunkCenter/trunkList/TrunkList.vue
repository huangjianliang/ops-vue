<template>
    <div class="surveyList">
        <div class="searchBox card table-search">
            <el-form ref="form" :model="form" label-width="45px">
                <el-form-item label="环境">
                    <el-select v-model="searchForm.env" placeholder="请选择环境" clearable @change="envChange" style="width: 120px">
                        <el-option v-for="item in envOptions" :label="item.label" :value="item.env_name" :key="item.env_name"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="编号">
                    <el-select v-model="searchForm.vehicleNo" placeholder="请选择编号" clearable multiple collapse-tags filterable @change="vehicleNoChange">
                        <el-option v-for="item in vehicleNoOptions" :label="item" :value="item"
                            :key="item"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div class="search-operation">
                <el-button type="primary" @click="handleSearch">搜索</el-button>
                <el-button type="warning" @click="handleReset">重置</el-button>
            </div>
        </div>
        <div class="tableBox card table">
            <el-table :data="tableData" style="width: 100%" :border="true" v-loading="loading">
                <!-- <el-table-column label="序号" width="80" fixed="left">
                    <template #default="scope">
                        {{ (pageable.pageSize * (pageable.pageNum - 1)) + scope.$index + 1 }}
                    </template>
                </el-table-column> -->
                <el-table-column prop="env_name" label="环境"></el-table-column>
                <el-table-column prop="trunk_number" label="编号" >
                </el-table-column>
                <el-table-column prop="status" label="FRP状态" >
                    <template #default="scope">
                        <slot :row="scope.row">
                            <span :class="[scope.row.status === 'online'? 'greenFrp' : 'redFrp']">{{ scope.row.status}}</span>
                        </slot>
                    </template>
                </el-table-column>
                <el-table-column prop="mdc_url" label="MDC终端" >
                    <template #default="scope">
                        <slot :row="scope.row">
                            <span class="linkSpan" @click="openSSH(scope.row, 'trunk', 'mdc')">MDC终端</span>
                        </slot>
                    </template>
                </el-table-column>

                <el-table-column prop="mdc_url" label="MDC老终端" >
                     <template #default="scope">
                         <slot :row="scope.row">
                            <span class="linkSpan" @click="handleClick(scope.row, 'mdc')">MDC老终端</span>
                        </slot>
                    </template>
                </el-table-column>


                <el-table-column prop="v2x_url" label="V2X终端" >
                    <template #default="scope">
                        <slot :row="scope.row">
                            <span class="linkSpan" @click="openSSH(scope.row, 'trunk', 'v2x')">V2X终端</span>
                        </slot>
                    </template>
                </el-table-column>

                <el-table-column prop="dtu_url" label="DTU控制台" >
                    <template #default="scope">
                        <slot :row="scope.row">
                            <span class="linkSpan" @click="handleClick(scope.row, 'dtu')">DTU控制台</span>
                        </slot>
                    </template>
                </el-table-column>
                <el-table-column prop="hc_url" label="华测控制台" >
                    <template #default="scope">
                        <slot :row="scope.row">
                            <span class="linkSpan" @click="handleClick(scope.row, 'hc')">华测控制台</span>
                        </slot>
                    </template>
                </el-table-column>
                <el-table-column prop="cpe_url" label="CPE控制台" >
                    <template #default="scope">
                        <slot :row="scope.row">
                            <span class="linkSpan" @click="handleClick(scope.row, 'cpe')">CPE控制台</span>
                        </slot>
                    </template>
                </el-table-column>
            </el-table>
            <Pagination :pageable="pageable" :handleSizeChange="handleSizeChange"
                :handleCurrentChange="handleCurrentChange" />
        </div>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import * as server from '@/api/modules/trunkCenter.js';
import Pagination from "../../../components/ProTable/components/Pagination.vue";
import { useRouter } from "vue-router"

const dialogVisible = ref(false)

// 搜索信息
const searchForm = reactive({
    env: '',
    vehicleNo: []
});

// 分页信息
const pageable = reactive({
    // 当前页数
    pageNum: 1,
    // 每页显示条数
    pageSize: 25,
    // 总条数
    total: 0
});

// loading 状态
const loading = ref(false);
// 缓存操作之前环境名称
const previousEnv = ref('');
// 环境列表
const envOptions = ref([]);
// 车辆编号options
const vehicleNoOptions = ref([]);
// 表格数据
const tableData = ref([]);

onMounted(() => {
    // 获取环境列表
    getEnvList();
});

// 搜索
const handleSearch = () => {
    getVehicleList()
};

// 环境变化事件
const envChange = (val) => {
    getVehicleList();
};

// 车辆编号变化事件
const vehicleNoChange = () => {
    getVehicleList();
};

// 获取环境options
const getEnvList = async () => {
    try {
        const res = await server.getEnvTrunkTerminalListApi({});
        const { code, data } = res;
        if (code === 200) {
            envOptions.value = data;
        } else {
            envOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取车辆列表 
const getVehicleList = async () => {
    const { env, vehicleNo } = searchForm;
    const { pageNum, pageSize } = pageable;
    const params = {
        env_name: env,
        trunk_number: vehicleNo.join(','),
        pageNum,
        pageSize
    };
    
    loading.value = true;
    try {
        const res = await server.getTrunkCenterListApi(params);
        const { code, data } = res;
        loading.value = false;
        
        if (code === 200) {
            const { total, dataList, trunk_num_list=[] } = data;
            tableData.value = dataList;
            pageable.total = total;
            
            if(previousEnv.value !== env){
                previousEnv.value = env;
                searchForm.vehicleNo = [];
                vehicleNoOptions.value = trunk_num_list;
            }
        } else {
            tableData.value = [];
            vehicleNoOptions.value = [];
        }
        
    } catch (error) {
        throw new Error(error);
    }
};

// 重置
const handleReset = () => {
    searchForm.env = '';
    searchForm.vehicleNo = [];
    
    pageable.pageNum = 1;
    pageable.pageSize = 25;

    getVehicleList();
};

// 每页条数改变
const handleSizeChange = (val) => {
    pageable.pageNum = 1;
    pageable.pageSize = val;
    getVehicleList();
};

// 当前页改变
const handleCurrentChange = (val) => {
    pageable.pageNum = val;
    getVehicleList();
};

// 获取地址
const handleClick = async(rowData, type) => {
    const { trunk_number } = rowData;
    
    const params = {
        env_name: searchForm.env,
        trunk_number,
        device_type: type
    };
    
    try {
        const res = await server.getDeviceUrl(params);
        const { code, data } = res;
        if (code === 200) {
            window.open(data, "_blank");   
        } 
    } catch (error) {
        throw new Error(error);
    }
};

// 打开终端
const router = useRouter();
const openSSH = async(rowData, type, device) => {
    //console.log(rowData, type)
    router.push({name: "TrunkTerm", params: {type: type, env_name: rowData.env_name, device: device, trunk_number: rowData.trunk_number}})
};

</script>

<style lang="scss" scoped>
.surveyList {
    width: 100%;
    height: 100%;

    .searchBox {
        display: flex;
        padding: 18px 20px;
        margin-bottom: 10px;
        display: flex;
        justify-content: space-between;

        .el-form {
            display: flex;

            .el-form-item {
                margin-right: 15px;
                margin-bottom: 0px;
            }
        }
    }
    .table{
        height: calc(100% - 78px);
    }
    .linkSpan{
        color: #409EFF;
        cursor: pointer;
        &:hover{
            font-weight: bold;
        }
    }
    .greenFrp{
        color: green;
    }
    .redFrp{
        color: red;
    }
}
</style>