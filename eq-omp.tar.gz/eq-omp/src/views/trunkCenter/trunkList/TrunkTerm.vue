<template>
  <div class="main-box">
    <div style="height: 100%; width: 100%">
      <div>
      <el-space :size="size" spacer="">
        <el-text class="mx-1">环境</el-text>
        <el-select v-model="data.host.env_name" placeholder="环境" clearable style="width: 100px" @change="data.host.trunk_number = ''; data.host.device = ''; getVehicleList()">
          <el-option v-for="item in envOptions" :label="item.label" :value="item.env_name" :key="item.env_name"></el-option>
        </el-select>
        <el-text class="mx-1">车辆</el-text>
        <el-select v-model="data.host.trunk_number" style="width: 100px" placeholder="编号" clearable collapse-tags filterable>
          <el-option v-for="item in vehicleNoOptions" :label="item" :value="item"
            :key="item"></el-option>
        </el-select>
        <el-text class="mx-1">类型</el-text>
        <el-select style="width: 100px" v-model="data.host.device" placeholder="请选择">
          <el-option label="mdc" value="mdc" />
          <el-option label="v2x" value="v2x" />
        </el-select>
        <el-button @click="connectHost(data.host)">打开</el-button>
        <el-button @click="showDrawer">任务列表</el-button>
      </el-space>
    </div>

    <div v-if="!isShowBlank">
      <el-tabs
        v-model="data.current_host.session_id"
        type="border-card"
        closable
        @tab-remove="removeTab"
        @tab-click="selectTab"
      >

        <el-tab-pane
          v-for="item in data.host_tabs"
          :key="item.session_id"
          :label="item.name"
          :name="item.session_id"
        >
          <template #label>
            <el-button-group>
              <el-button
              small
              :type="
              item.session_id === data.current_host.session_id
              ? 'primary'
              : 'default'
              "
              >{{item.env_name}}/{{item.trunk_number}}/{{item.device}}</el-button>

              <el-button
                small
                :type="
                item.session_id === data.current_host.session_id
                ? 'primary'
                : 'default'
                "
                :disabled="data.current_host.device === 'v2x'"
                @click="listDir('/', item)"
                :icon="Sort"
                >文件传输
              </el-button>
            </el-button-group>
          </template>

          <template #default>
            <div style="margin: 1px">
              <div :id="item.session_id"></div> 
            </div>
          </template>
        </el-tab-pane>
      </el-tabs>
    </div>

    <div v-else style="height: 80%; width: 87%;position: absolute; background-color: #300a24;display: flex;align-items: center;justify-content: center;">
              <label style="text-align: center; font-size: 50px;color: white;">请选择环境、车辆、类型，然后点击打开</label>
    </div>

  </div>

    <div>
      <el-dialog v-model="data.file_dialog_visible" width="50%" class="file-dialog">
        <!--
        <el-progress v-if="showUploadProgress" :text-inside="true" :stroke-width="26" :percentage="percentComplete" />
        -->

        <el-text class="mx-1">环境：{{data.current_host.env_name}}</el-text>
        <el-divider direction="vertical" />
        <el-text class="mx-1">车辆：{{data.current_host.trunk_number}}</el-text>
        <el-divider direction="vertical" />
        <el-text class="mx-1">设备：{{data.current_host.device}}</el-text>
        <el-divider direction="vertical" />
        <el-text class="mx-1">路径：</el-text>
        <el-button-group>
          <el-button
            v-for="(item, index) in data.dir_info.paths"
            :key="index"
            @click="listDir(item.dir, data.current_host)"
            >
            {{ item.name }}
          </el-button>
        </el-button-group>

        <el-autocomplete
          v-model="searchstate"
          :fetch-suggestions="querySearch"
          clearable
          class="inline-input w-50"
          placeholder="搜索"
          @change="handleSearchChange"
          @select="handleSearchSelect"/>

        <el-button @click="showDrawer">任务列表</el-button>
      
        <el-table :data="fileList" height="400">
          <el-table-column prop="name" label="文件名" fixed="left" sortable>
            <template #default="scope">
              <el-button
                v-if="scope.row.type === 'f'"
                @click="downloadFile(scope.row)"
                type="text"
                size="small"
                :icon="Files"
                style="color: green"
              >{{ scope.row.name }}
              </el-button>

              <el-button
                v-if="scope.row.type === 'd'"
                @click="listDir(scope.row.path, data.current_host)"
                type="text"
                size="small"
                :icon="FolderOpened">{{ scope.row.name }}
              </el-button>

            </template>

            </el-table-column>
              <el-table-column prop="size" label="大小" width="100" sortable></el-table-column>
              <el-table-column prop="mode" label="权限" width="100" sortable></el-table-column>
              <el-table-column prop="mod_time" label="修改日期" width="180" sortable></el-table-column>
              <el-table-column label="操作" width="100" fixed="right">
              <template #default="scope">
                <el-button
                  v-if="scope.row.type == 'f'"
                  @click="downloadFileNew(scope.row)"
                  type="success"
                  :icon="Bottom"
                >下载</el-button>
                
                <el-button
                  v-else
                  type="primary"
                  :icon="Upload"
                  :disabled="! data.current_host.writeable"
                  @click="uploadFile(scope.row)"
                >上传</el-button>

              </template>
              
          </el-table-column>
        </el-table>
      </el-dialog>
    </div>

    <el-drawer
    v-model="isShowDrawer"
    title="任务列表"
    :direction="direction"
    :before-close="handleClose"
    >
      <el-table :data="uploadList" height="400">
        <el-table-column prop="type" label="类型"></el-table-column>
        <el-table-column prop="env_name" label="环境"></el-table-column>
        <el-table-column prop="trunk_number" label="车辆"></el-table-column>
        <el-table-column prop="path" label="目录"></el-table-column>
        <el-table-column prop="file" label="文件" width="250"></el-table-column>
        <el-table-column label="进度" width="150" fixed="right">
          <template #default="scope">
            <el-progress :percentage="scope.row.progress" />
          </template>
        </el-table-column>
      </el-table>
    </el-drawer>

  </div>
</template>
  
<script setup lang="ts">
import "xterm/css/xterm.css";
  
import { computed, nextTick, onMounted, reactive, ref } from "vue";
import xhttp, { Xhttp } from "./xhttp";
import { Terminal } from "xterm";
import { AttachAddon } from "xterm-addon-attach";
import { FitAddon } from "xterm-addon-fit";
import { ElMessage, ElPopover } from "element-plus";
import { useRoute } from "vue-router";

import { FolderOpened, Files, Bottom, Upload, Menu, CirclePlus, Coin, Sort } from '@element-plus/icons-vue';
import { getTrunkCenterListApi, getEnvTrunkTerminalListApi, syncTrunkApi } from '@/api/modules/trunkCenter.js';

import { useGlobalStore } from "@/store";
  
enum Mode {
  "create" = 0,
  "update" = 1,
}
  
interface Host {
  id: number;
  name: string;
  address: string;
  user: string;
  pwd: string;
  port: number;
  font_size: number;
  background: string;
  foreground: string;
  cursor_color: string;
  font_family: string;
  cursor_style: "block" | "underline" | "bar";
  shell: string;
  session_id: string;
  term: Terminal;
  fit: FitAddon;
  env_name: string;
  trunk_number: string;
  device: string;
}

interface Path {
  dir: string;
  name: string;
}

interface File {
  name: string;
  mod_time: string;
  mode: string;
  path: string;
  type: "d" | "f";
  size: number;
}

interface DirInfo {
  current_dir: string;
  dir_count: number;
  file_count: number;
  files: Array<File>;
  paths: Array<Path>;
}

let data = reactive({
  mode: Mode.create,
  id: 0,
  name: "",
  address: "",
  user: "",
  pwd: "",
  port: 22,
  h: 20,
  w: 80,
  session_id: "",
  background: "#300a24",
  foreground: "#FFFFFF",
  cursor_color: "#FFFFFF",
  font_family: "Ubuntu Mono, Droid Sans Mono, monospace",
  font_size: 16,
  cursor_style: "block",
  shell: "bash",

  upload_path: "",
  download_path: "",
  host_list: [] as Array<Host>,
  host_tabs: [] as Array<Host>,

  current_host: { session_id: "" } as Host,
  host: {} as Host,
  file_dialog_visible: false,
  dir_info: {} as DirInfo,
});

/**
 * 清空表单数据
 */

function cleanFrom() {
  data.id = 0;
  data.name = "";
  data.address = "";
  data.user = "";
  data.pwd = "";
  data.port = 22;
  data.session_id = "";
  data.background = "#300a24";
  data.foreground = "#FFFFFF";
  data.cursor_color = "#FFFFFF";
  data.font_family = "Ubuntu Mono, Droid Sans Mono, monospace";
  data.font_size = 16;
  data.cursor_style = "block";
  data.shell = "bash";
}

/**
 * 打开文件列表
 */
const fileList = ref([]);
function listDir(dir: string, h: Host) {
  searchstate.value = '';
  data.dir_info = [];
  data.file_dialog_visible = true;

  if (h) {
    setCurrentAcitveHost(h.session_id);
  }
  let host = { ...data.current_host };

  if (!host.hasOwnProperty("session_id")) {
    // 没有连接主机
    return;
  }

  let xhttp = new Xhttp();
  let url = `https://ops.eacon.com/api/file?session_id=${host.session_id}&path=${dir}`;
  xhttp
    .get(url)
    .then((res) => res.json())
    .then((json) => {
      if (json.code === 0) {
        data.dir_info = json.data;
        fileList.value = data.dir_info.files;
      }
    });
}

/**
 * 上传文件
 */
function uploadFile(file: File) {
  function upload(fileobject) {
    let formData = new FormData();
    formData.append("session_id", data.current_host.session_id);
    formData.append("path", file.path);
    formData.append("file", fileobject);

    const uuid = crypto.randomUUID();
    let percentComplete = 0;
    ElMessage("提交上传任务成功：" + fileobject.name);
    uploadList.push({...data.current_host, uuid: uuid, path: file.path, file: fileobject.name, progress: percentComplete, type: "上传"})

    var xhr = new XMLHttpRequest();
    xhr.open('PUT', 'https://ops.eacon.com/api/file', true);

    xhr.upload.onprogress = function(e) {
      if (e.lengthComputable) {
        percentComplete = (e.loaded / e.total / 2).toFixed(1) * 100;
        updateUploadProgress(uuid, percentComplete);
      }
    };

    xhr.onload = function() {
      var obj = JSON.parse(xhr.responseText)
      if (obj.code == 0) {
        ElMessage.success("文件上传完成：" + fileobject.name);
        updateUploadProgress(uuid, 100);
      }
    };

    xhr.send(formData);
  }

  let fileInput = document.createElement("input");
  fileInput.type = "file";
  fileInput.multiple = true;

  fileInput.onchange = function (f: any) {
    let fileList = fileInput.files as FileList;
    for (let i = 0; i < fileList.length; i++) {
      upload(fileList[i])
    }
    isShowDrawer.value = true;
  };
  fileInput.click();
}

/**
 * 下载文件(只能是文件,不能是目录)
 */
function downloadFile(file: File) {
  let formData = new FormData();
  formData.append("session_id", data.current_host.session_id);
  formData.append("path", file.path);
  let xhttp = new Xhttp();
  xhttp.post("https://ops.eacon.com/api/file", { body: formData }).then((res) =>
    res.blob().then((blob) => {
      var a = document.createElement("a");
      var url = window.URL.createObjectURL(blob);
      a.href = url;
      a.download = file.name;
      a.click();
      window.URL.revokeObjectURL(url);
    })
  );
}

async function downloadFileNew(file: File) {
  isShowDrawer.value = true;
  let blob = await getBlob(file);
  saveFile(blob, file);
}
function getBlob(file: File) {
  return new Promise(resolve => {
    let formData = new FormData();
    formData.append("session_id", data.current_host.session_id);
    formData.append("path", file.path);

    const uuid = crypto.randomUUID();
    let percentComplete = 0;
    ElMessage("提交下载任务成功：" + file.name);
    uploadList.push({...data.current_host, uuid: uuid, path: file.path, file: file.name, progress: percentComplete, type: "下载"})

    const xhr = new XMLHttpRequest();
    xhr.open('POST', "https://ops.eacon.com/api/file", true);
    //监听进度事件
    xhr.addEventListener(
      'progress',
      function (evt) {
        let percentComplete = evt.loaded / file.size;
        let percentage = (percentComplete * 100).toFixed(0);
        updateUploadProgress(uuid, percentage);
      },
      false
    );
    xhr.responseType = 'blob';
    xhr.onload = () => {
      if (xhr.status === 200) {
        ElMessage.success("文件下载完成：" + file.name);
        resolve(xhr.response);
      }
    };
    xhr.send(formData);
  });
}
function saveFile(blob, file: File) {
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = file.name;
    link.click();
    window.URL.revokeObjectURL(link.href);
}

/**
 * 获取会话session_id
 */
function getSessionId(host: Host): Promise<Object> {
  let fm = new FormData();

  const globalStore = useGlobalStore();
  const { token } = globalStore;

  fm.append("name", host.trunk_number);
  fm.append("env_name", host.env_name);
  fm.append("trunk_number", host.trunk_number);
  fm.append("device", host.device);
  fm.append("token", token);

  let xhttp = new Xhttp();
  return xhttp
    .patch("https://ops.eacon.com/api/host", { body: fm })
    .then((response) => response.json())
    .then((json) => {
      if (json.code === 0) {
        return json;
      } else if (json.code === 410) {
        ElMessage.info('车辆信息同步中，请重新连接！');
        syncTrunk(host.env_name, host.trunk_number, host.device);
      } else {
        ElMessage.error('连接异常！')
      }
    });
}

// 车辆信息同步
const syncTrunk = async (env_name='', trunk_number='', device_type='') => {
  const params = {
    env_name: env_name,
    trunk_number: trunk_number,
    device_type: device_type,
  };
  
  try {
    await syncTrunkApi(params);
  } catch (error) {
    throw new Error(error);
  }
};

/**
 * 连接已经保存过的主机
 */
function connectHost(host: Host) {
  isShowBlank.value = false;
  getSessionId(host).then((ret) => {
    // 必须要解开,否则出现 Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead
    let connHost = { ...host };
    connHost.session_id = ret.data;
    connHost.writeable = ret.writeable;

    // 窗口大小适应插件
    //connHost.fit = new FitAddon();

    connHost.term = new Terminal({
      cursorBlink: true,
      theme: {
        background: data.background,
        foreground: data.foreground,
        cursor: data.cursor_color,
      },
      fontSize: data.font_size,
      fontFamily: data.font_family,
      cursorStyle: data.cursor_style,
    });

    var cols = Math.floor((window.innerWidth - 60) / 9);
    var rows = Math.floor(window.innerHeight/17) - 12;
    connHost.term.resize(cols, rows);

    // 加载窗口大小自适应插件
    //connHost.term.loadAddon(connHost.fit);

    // 添加tab 页面
    data.host_tabs.push(connHost);

    // 设置当前激活的host
    data.current_host = { ...connHost };

    nextTick(() => {
      let connectTabElement = document.getElementById(connHost.session_id);

      if (connectTabElement === null) {
        return;
      }

      connHost.term.open(connectTabElement);
      //connHost.fit.fit();

      let param = `h=${rows}&w=${cols}&session_id=${connHost.session_id}`;
      let sock_url = `wss://ops.eacon.com/api/ssh?${param}`;

      let socket = new WebSocket(sock_url)

      connHost.term.loadAddon(new AttachAddon(socket))

      socket.addEventListener("open", (event) => {
        connHost.term.focus();
      });

      socket.addEventListener("close", (event) => {
        connHost.term.write('连接关闭');
      });

      // 清空 from 表单数据
      cleanFrom();
    });

      //connHost.term.write('hello');
      //connHost.term.focus();
  });
}


/**
 * 删除tab
 */
function removeTab(tabId: string | number) {
  let removeIndex = 0;
  data.host_tabs.forEach((host, index) => {
    if (host.session_id === String(tabId)) {
      removeIndex = index;
    }
  });

  // 销毁term 对象
  //data.host_tabs[removeIndex].fit.dispose();
  data.host_tabs[removeIndex].term.dispose();

  // 从tab页签中删除
  data.host_tabs.splice(removeIndex, 1);

  // 如果没有打开的tab页签,就直接返回
  if (data.host_tabs.length === 0) {
    return;
  }

  // 如果打开的tab页签只有一个,就把这个tab页签设置成激活状态
  if (data.host_tabs.length === 1) {
    let activeHost = { ...data.host_tabs[0] };
    setCurrentAcitveHost(activeHost.session_id);
    return;
  }

  // 如果打开的tab页签只有一个以上,删除以后把下一个tab页签设置成激活
  if (data.host_tabs.length > 1) {
    let activeHost = { ...data.host_tabs[removeIndex] };
    setCurrentAcitveHost(activeHost.session_id);
  }
}

/***
 * 点击切换tab
 */
function selectTab(tab: any) {
  let sessionId = tab.props.name;
  setCurrentAcitveHost(sessionId);
}

/**
 * 设置当前正在使用的主机
 */
function setCurrentAcitveHost(sessionId: string) {
  data.host_tabs.forEach((host: Host) => {
    if (host.session_id === sessionId) {
      data.current_host = { ...host };
      return;
    }
  });
  windowResize();
}

/**
 * 更改窗口大小
 */
function windowResize() {
  let currentHost = data.current_host;

  if (currentHost.session_id === "") {
    // console.log("还没有连接主机");
    return;
  }

  // 没有在主机连接路由页面
  //if (route.currentRoute.value.name !== "Home") {
  //  return;
  //}

  nextTick(() => {
    let connectTabElement = document.getElementById(currentHost.session_id);

    if (connectTabElement === null) {
      return;
    }

    (connectTabElement as HTMLElement).style.height = Math.floor(window.innerHeight - 250) + "px";

    //currentHost.fit.fit();
    if (data.h !== currentHost.term.rows || data.w !== currentHost.term.cols) {
      let url = `https://ops.eacon.com/api/ssh?w=${currentHost.term.cols}&h=${currentHost.term.rows}&session_id=${currentHost.session_id}`;
      let xhttp = new Xhttp();
      xhttp.patch(url);
    }
    /* else {
      console.log(`窗口大小没有变化`);
    } */
    data.h = Math.floor(currentHost.term.rows);
    data.w = Math.floor(currentHost.term.cols);
  });
}

/**
 * 报告连接状态
 */
function reportConnectStatus() {
  setInterval(function () {
    let fm = new FormData();
    data.host_tabs.forEach((hont) => {
      fm.append("ids", hont.session_id);
    });

    let xhttp = new Xhttp();
    xhttp
      .post("https://ops.eacon.com/api/status", { body: fm })
      .then((response) => response.json())
      .then((json) => {
        if (json.code === 0) {
          // console.log(json);
        }
      });
  }, 10000);
}

// 接入传参
function getParams(){
  var route = useRoute();
  data.host.env_name = route.params.env_name;
  data.host.device = route.params.device;
  data.host.trunk_number = route.params.trunk_number;
}

// 获取车辆列表
const vehicleNoOptions = ref([]);
const getVehicleList = async () => {
  const params = {
      env_name: data.host.env_name,
      trunk_number: data.host.trunk_number,
      pageNum: 1,
      pageSize: 100
  };
  
  try {
      const res = await getTrunkCenterListApi(params);
      const { code, data } = res;
      
      if (code === 200) {
          const { trunk_num_list=[] } = data;
          vehicleNoOptions.value = trunk_num_list;
      } else {
          vehicleNoOptions.value = [];
      }
  } catch (error) {
      throw new Error(error);
  }
};

// 获取环境options
const envOptions = ref([]);
const getEnvList = async () => {
    try {
        const res = await getEnvTrunkTerminalListApi({});
        const { code, data } = res;
        if (code === 200) {
            envOptions.value = data;
        } else {
            envOptions.value = [];
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 显示上传任务
const isShowDrawer = ref(false);
const uploadList = reactive([]);
const showDrawer = async () => {
  isShowDrawer.value = true;
  console.log(uploadList);
};
const updateUploadProgress = async (uuid, progress) => {
  for(var i = 0; i < uploadList.length; i++) {
    if (uploadList[i].uuid  === uuid){
      uploadList[i].progress = progress;
    }
  }
};

// 显示空白页
const isShowBlank = ref(true);
const showBlank = () => {
  isShowBlank.value = true;
};

// 文件搜索
const searchstate = ref('');
const querySearch = (queryString: string, cb: any) => {
  var searchList = [];
  searchList = data.dir_info.files.map( function(item) {
    return {value: item.name};
  })

  const results = queryString
    ? searchList.filter((item) => item.value.match(queryString))
    : searchList

  cb(results)
};

const handleSearchSelect = (item) => {
  fileList.value = data.dir_info.files.filter((s) => s.name.match(item.value))
};

const handleSearchChange = (item) => {
  fileList.value = data.dir_info.files
};

onMounted(() => {
  getParams();
  getEnvList();
  if (data.host.env_name != ''){
    getVehicleList();
    connectHost(data.host);
  }
  reportConnectStatus();
  window.onbeforeunload = function () {
    return "关闭吗";
  };
});
  
</script>
  
<style scoped>
  .file-dialog {
    margin-top: 0px;
  }
</style>
