<template>
    <div class="card table-search log-search">
        <el-form ref="formRef" :model="searchForm" :inline="true">
            <el-form-item label="车辆">
                <el-select v-model="searchForm.env" @change="changeEnv" filterable clearable placeholder="环境"
                    style="width: 100px;">
                    <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label" :value="item.env_name" />
                </el-select>
                <el-select v-model="searchForm.trunk" filterable clearable allow-create placeholder="车辆"
                    style="width: 100px;">
                    <el-option v-for="item in trunkOptions" :key="item.trunk_number" :label="item.trunk_number"
                        :value="item.trunk_number" />
                </el-select>
                <el-select v-model="searchForm.datatype" filterable placeholder="指标" style="width: 100px;" @change="changeTarget">
                    <el-option v-for="item in datatypeOptions" :key="item.name" :label="item.label" :value="item.index" />
                </el-select>
                <el-switch v-model="showAll" size="large" inline-prompt active-text="全部区域" inactive-text="掉线区域"/>
            </el-form-item>

            <el-form-item label="时间">
                <el-date-picker v-model="searchForm.time" format="YYYY-MM-DD HH:mm:ss" value-format="YYYY-MM-DD HH:mm:ss"
                    type="datetimerange" start-placeholder="开始" end-placeholder="结束" :shortcuts="shortcuts"
                    range-separator="至" editable style="width: 350px;" />
            </el-form-item>

            <el-form-item>
                <el-button v-if="(tracking && showAll)" type="danger" @click="stopTrack">停止跟车</el-button>
                <el-button v-if="(!tracking && showAll)" type="primary" @click="startTrack">跟车测速</el-button>
                <el-button type="success" @click="getTrunkNet">历史查询</el-button>
            </el-form-item>

        </el-form>
    </div>
</template>

<script setup>
import { reactive, onMounted, ref, onUnmounted } from 'vue';
import { getNowDate } from '@/utils/util';
import { useTrunkCenterStore } from '@/store/modules/trunkCenter';
import { useGlobalStore } from '@/store';
import { getTrunkListApi, getEnvTrunkTerminalListApi, getTrunkNetApi, offlineApi } from '@/api/modules/trunkCenter.js';

const { datatypeOptions } = window.config;

const showAll = ref(true);

let socket = null, realTimeDatas = [];

const shortcuts = [
    {
        text: '最近 5 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 5 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 30 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 30 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 1 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 4 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 4 * 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '今天',
        value: () => {
            const end = new Date()
            const start = new Date(end.getFullYear(), end.getMonth(), end.getDate()); // 将时分秒设置为0，获取今天零点的时间
            return [start, end]
        },
    },
    {
        text: '昨天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate())
            return [start, end]
        },
    },
    {
        text: '前天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            return [start, end]
        },
    },
];

const envOptions = ref([]);     // 环境列表options
const trunkOptions = ref([]);   // 车辆列表options

const props = defineProps({
    echartShow: {
        type: Boolean,
        default: false
    }
});

const emits = defineEmits(['updateHistoryData', 'updateOfflineData', 'updateEnv', 'toggleEchartShow']);

const trunkCenterStore = useTrunkCenterStore();
const globalStore = useGlobalStore();

const searchForm = reactive({
    env: '',
    trunk: '',
    datatype: 0,
    time: [new Date('2023-03-22 12:00:00'), new Date('2023-03-22 12:00:00')],
});

onMounted(() => {
    initDate();
    getEnvTrunkTerminalList();
});

onUnmounted(() => {
    socket && socket.close();
});

// 初始化时间
const initDate = () => {
    const { year, month, day, hour, minute, second } = getNowDate();
    const startHour = hour - 1 > 0 ? hour - 1 : hour;
    const startDate = `${year}-${month}-${day} ${startHour}:${hour === startHour ? "00" : minute}:${hour === startHour ? "00" : second}`;
    const endDate = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    searchForm.time = [startDate, endDate];
};

// 切换环境
const changeEnv = async (val) => {
    searchForm.trunk = "";
    getTrunkCenterList();
    emits('updateEnv', val);
};

// 指标切换
const changeTarget = (val) => {
    trunkCenterStore.setMonitorType(val);
};

// 获取车辆选项
const getTrunkCenterList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env_name": searchForm.env };
        const res = await getTrunkListApi(params);
        const { code, data } = res
        if (code === 200) {
            trunkOptions.value = data['dataList']
        } else {
            ElMessage.error('获取车辆列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取环境选项
const getEnvTrunkTerminalList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 25 };
        const res = await getEnvTrunkTerminalListApi(params);
        const { code, data } = res
        if (code === 200) {
            envOptions.value = data
        } else {
            ElMessage.error('获取环境列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 
const getTrunkNet = async () => {
    if (!searchForm.env) {
        ElMessage.warning('请先选择环境！')
        return
    }

    if (!searchForm.trunk) {
        ElMessage.warning('请先选择车辆！')
        return
    }
    
    socket && socket.close();

    const params = { "env": searchForm.env, "trunk": searchForm.trunk, "time": searchForm.time, "datatype": datatypeOptions[searchForm.datatype]['name'] };

    if (showAll.value) {
        getHistory(params);
    } else {
        getOffline(params);
    }
};

// 获取历史数据
const getHistory = async (params) => {
    try {
        const res = await getTrunkNetApi(params);
        const { code, data, msg } = res;
        if (code === 200) {
            emits('updateHistoryData', data.list);
            if(!props.echartShow){
                    emits('toggleEchartShow');
            }
        } else {
            ElMessage.error('获取历史数据失败！' + msg)
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 获取离线区域数据
const getOffline = async (params) => {
    try {
        const res = await offlineApi(params);
        const { code, data, msg } = res;
        if (code === 200) {
            emits('updateOfflineData', data.list);
        } else {
            ElMessage.error('获取掉线数据失败！' + msg)
        }
    } catch (error) {
        throw new Error(error);
    }
};

// 跟车测速
const tracking = ref(false);

const stopTrack = () => {
    socket && socket.close();
    tracking.value = false;
}

const startTrack = () => {
    tracking.value = true;

    if (searchForm.env == '' || searchForm.trunk == '') {
        ElMessage.warning('请选择环境和车辆！')
        return;
    }
    
    if(!props.echartShow){
        emits('toggleEchartShow');
    }

    const { WS_TRUNK_URL } = window.config;
   
    const { token } = globalStore;
    const { trunk, env, datatype } = searchForm;
    const { name } = datatypeOptions[datatype]
    const url = `${WS_TRUNK_URL}?trunk=${trunk}&env=${env}&datatype=${name}&token=${token}`;

    socket && socket.close();
    socket = new WebSocket(url);

    socket.onopen = () => {
        console.log("连接状态：已连接");
        realTimeDatas = [];
    }

    socket.onmessage = (event) => {
        const target = JSON.parse(event.data);

        var markerData = [target[0], target[1], target[2]]
        let trunkStats = '';

        if (name === 'signal') {
            trunkStats = `环境: ${env}, 车辆: ${trunk}, 位置: ${markerData[0]} ${markerData[1]}, 信号: ${markerData[2]} dBm`;
        }

        if (name === 'ping') {
            trunkStats = `环境: ${env}, 车辆: ${trunk}, 位置: ${markerData[0]} ${markerData[1]}, ping延时: ${markerData[2]} ms`;
        }
        
        // map.attributionControl.setPrefix(trunkStats);
        realTimeDatas.push(target);
        
        trunkCenterStore.setRealTimeDatas([...realTimeDatas]);
        
        // if (realTimeDatas.length === 1) {
        //     trackMarker = L.marker(markerData).addTo(map);
        // }
        // if (trackCount > 10000) {
        //     hotlineLayer.setLatLngs([]);
        //     trackCount = 0;
        // }

        // map.setView(markerData);
        // trackMarker.setLatLng(markerData);
        // hotlineLayer.addLatLng(markerData);
        // trackCount = trackCount + 1;

        // var chartData = {"list": [obj]};
        // initEcharts(chartData);
    }

    socket.onclose = function () {
        console.log('关闭');
    }
}
</script>

<style lang="scss" scoped>
:deep .el-form-item{
    margin-bottom: 0px;
}
</style>