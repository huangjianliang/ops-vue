<template>
    <div class="echartContainer">
        <div class="echart-item" ref="mainChartRef"></div>
        <span class="divide"></span>
        <div class="echart-item" ref="dtuTrafficChartRef"></div>
    </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { ref, watch, onMounted } from 'vue';
import * as echarts from "echarts";
import { useTrunkCenterStore } from '@/store/modules/trunkCenter';

const { datatypeOptions } = window.config;

let mainChart = null, dtuTrafficChart = null, catchDataMap = {};

const mainChartRef = ref(null);
const dtuTrafficChartRef = ref(null);

const emits = defineEmits('setCurPointData');
const trunkCenterStore = useTrunkCenterStore();
const { realTimeDatas } = storeToRefs(trunkCenterStore);

const props = defineProps({
    historyData: {
        type: Array,
        default: () => []
    },
    isTranstionEnd: {
        type: Boolean,
        default: false
    }
});

onMounted(() => {
    initChart(props.historyData);
});

const initChart = (list) => {
    if (!list.length) return;
    catchDataMap = {};
    let mainxData = [], mainyData = [], dtuxData = [], dtuyData1 = [], dtuyData2 = [];
    list.forEach(item => {
        mainxData.push(item[5]);
        mainyData.push(item[2]);
        dtuxData.push(item[5]);
        dtuyData1.push((item[3] / 1024 / 1024 * 8).toFixed(2));
        dtuyData2.push((item[4] / 1024 / 1024 * 8).toFixed(2));
        catchDataMap[item[5]] = item;
    });
    
    const { monitorType } = trunkCenterStore;
    const { label='', unit='' } = datatypeOptions[monitorType];
    !mainChart && (mainChart = echarts.init(mainChartRef.value));
    const mainChartOptions = getMainChartsOptions(mainxData, mainyData, label, unit);
    mainChart.setOption(mainChartOptions);

    !dtuTrafficChart && (dtuTrafficChart = echarts.init(dtuTrafficChartRef.value));
    const dtuTrafficChartOptions = getdtuTrafficChartOptions(dtuxData, dtuyData1, dtuyData2, 'DTU带宽', 'Mbps');
    dtuTrafficChart.setOption(dtuTrafficChartOptions);
    
    addChartEvent([mainChart, dtuTrafficChart]);
};

// 图表添加事件
const addChartEvent = (charts) => {
    charts.forEach(chart => {
        chart.getZr().on('click', (params) => {
            let pointInPixel = [params.offsetX, params.offsetY];
            if (chart.containPixel('grid', pointInPixel)) {
                let pointInGrid = chart.convertFromPixel({
                    seriesIndex: 0
                }, pointInPixel);
                let xIndex = pointInGrid[0]; 
                let handleIndex = Number(xIndex);
                let seriesObj = chart.getOption();
                let op = chart.getOption();
                //获得图表中点击的列
                let month = op.xAxis[0].data[handleIndex]; 
                // console.log(month);
                emits('setCurPointData', catchDataMap[month]);
                // console.log(handleIndex, seriesObj);
            };
        });
    });
};

const getMainChartsOptions = (xdata, ydata, title, unit) => {
    return {
        color: ['#80FFA5'],
        title: {
            show: true,
            text: title,
            textStyle: {
                color: '#fff',
                fontStyle: 'normal',
                fontWeight: 'normal',
                fontFamily: 'sans-serif',
                fontSize: 18,
                lineHeight: 18,
            },
            left: 'center',
            top: 'top'
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        legend: {
            data: [title],
            right: 10,
            textStyle: {
                color: "#fff"
            },
            itemWidth: 14,
            itemHeight: 10,
            itemGap: 13
        },
        xAxis: {
            type: 'category',
            data: xdata,
            boundaryGap: false,
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                },
                formatter: function (value) {
                    if (value.includes(' ')) {
                        return value.split(' ')[1];
                    }
                    return value;
                },
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        yAxis: {
            name: unit,
            type: 'value',
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                }
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        series: [
            {
                name: title,
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(128, 255, 165)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(1, 191, 236)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: ydata
            },
        ]
    };
};

const getdtuTrafficChartOptions = (xdata, y1data, y2data, title, unit) => {
    return {
        color: ['#37A2FF', '#FF0087'],
        title: {
            show: true,
            text: title,
            textStyle: {
                color: '#fff',
                fontStyle: 'normal',
                fontWeight: 'normal',
                fontFamily: 'sans-serif',
                fontSize: 18,
                lineHeight: 18,
            },
            left: 'center',
            top: 'top'
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        legend: {
            data: ['接收', '发送'],
            right: 10,
            textStyle: {
                color: "#fff"
            },
            itemWidth: 14,
            itemHeight: 10,
            itemGap: 13
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: xdata,
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                },
                formatter: function (value) {
                    if (value.includes(' ')) {
                        return value.split(' ')[1];
                    }
                    return value;
                },
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        yAxis: {
            name: unit,
            type: 'value',
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {//x轴文字的配置
                show: true,
                textStyle: {
                    color: "#fff",
                }
            },
            splitLine: {//分割线配置
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        series: [
            {
                name: '接收',
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(0, 221, 255)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(77, 119, 255)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: y1data
            },
            {
                name: '发送',
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(55, 162, 255)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(116, 21, 219)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: y2data
            },
        ]
    };
};

watch(() => props.historyData, (val = []) => {
    initChart(val);
});

watch(() => props.isTranstionEnd, () => {
    mainChart && mainChart.resize();
    dtuTrafficChart && dtuTrafficChart.resize();
});

// 实时数据监听
watch(() => realTimeDatas, (val) => {
    initChart(val.value);
}, {
    deep: true
});

</script>

<style lang="scss" scoped>
.echartContainer {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.8);
    box-sizing: border-box;

    .echart-item {
        width: 100%;
        height: 50%;
        padding: 2%;
        box-sizing: border-box;
    }

    .divide {
        display: inline-block;
        height: 1px;
        width: 100%;
        background-color: rgba(0, 0, 0, 0.3);
    }
}
</style>