<template>
    <div class="container">
        <div class="unit">
            单位: {{ legendUnit }}
        </div>
        <div class="legendBox">

            <div class="colorBox">
                <div class="colorTop"></div>
                <div class="colorBottom"></div>
            </div>
            <div class="numBox">
                <span class="min">{{ minVal }}</span>
                <span class="middle">{{ middleVal }}</span>
                <span class="max">{{ maxVal }}</span>
            </div>
        </div>
    </div>
</template>

<script setup>
import { useTrunkCenterStore } from '@/store/modules/trunkCenter';
import { watch, ref } from 'vue';
import { storeToRefs } from 'pinia';

const { datatypeOptions } = window.config;
const trunkCenterStore = useTrunkCenterStore();
const { monitorType } = storeToRefs(trunkCenterStore);

const minVal = ref(0);
const middleVal = ref(50);
const maxVal = ref(100);

const legendUnit = ref('ms');

watch(() => monitorType, (val) => {
    const index = val.value;
    const data = datatypeOptions[Number(index)];
    
    if(!data) return;
    
    const { min, max, unit } = data;
    
    if(Number(index) === 1){
        minVal.value = min;
        maxVal.value = max;
    }else{
        minVal.value = max;
        maxVal.value = min;
    }
    
    middleVal.value = (min + max) / 2;
    
    legendUnit.value = unit;
},{
    immediate: true,
    deep: true
});
</script>

<style lang="scss" scoped>
.container {
    position: absolute;
    bottom: 20px;
    left: 15px;
    display: flex;
    z-index: 1000;
    flex-direction: column;
    justify-content: flex-start;

    .unit {
        color: #fff;
        margin-bottom: 5px;
    }

    .legendBox {
        display: flex;

        .colorBox {
            height: 200px;
            width: 25px;
            display: flex;
            flex-direction: column;
            border-radius: 3px;

            .colorTop,
            .colorBottom {
                height: 100px;
                width: 100%;

            }

            .colorTop {
                border-top-left-radius: 3px;
                border-top-right-radius: 3px;
                background-image: linear-gradient(to bottom, green, yellow);
            }

            .colorBottom {
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px;
                background-image: linear-gradient(to bottom, yellow, red);
            }
        }

        .numBox {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            margin-left: 5px;
            color: #333;
            font-size: 12px;
            color: #fff;

            span {
                text-align: left;
            }
        }
    }

}</style>