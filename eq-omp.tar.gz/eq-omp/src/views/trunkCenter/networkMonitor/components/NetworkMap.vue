<template>
    <div class="mapContainer">
        <div id="map">
            <div class="zoom control-item">{{ curZoom }}</div>
            <div class="chartIcon control-item" @click="showEchart" :class="{ 'active': echartShow }">
                <i class="iconfont icon-chart"></i>
            </div>
        </div>
        <LegendC />
    </div>
</template>

<script setup>
import { onMounted, ref, watch } from 'vue';
import { storeToRefs } from 'pinia';
import { ElMessage } from 'element-plus'
import { useTrunkCenterStore } from '@/store/modules/trunkCenter';
import '@/plugin/Leaflet.canvasmarker.js';

import LegendC from './Legend.vue';
import pointPng from '@/assets/images/map/point.png';
import redmk from '@/assets/images/map/red-marker.png';

let map = null, envLayer = null, popup = null, vehicleMarker = null, hotlineLayer = null, turfFeatureCollect = null, catchTrackDataMap = {};

const { datatypeOptions } = window.config;

const trunkCenterStore = useTrunkCenterStore();
const { monitorType } = storeToRefs(trunkCenterStore);

const { realTimeDatas } = storeToRefs(trunkCenterStore);

const props = defineProps({
    curEnv: {
        type: String,
        default: ''
    },
    echartShow: {
        type: Boolean,
        default: false
    },
    historyData: {
        type: Array,
        default: () => []
    },
    offlineData: {
        type: Array,
        default: () => []
    },
    isTranstionEnd: {
        type: Boolean,
        default: false
    },
    curPointData: {
        type: Array,
        default: () => []
    }
});

const curZoom = ref(4);

const emits = defineEmits('toggleEchartShow');

onMounted(() => {
    initMap();
});

// 首屏地图
const initMap = () => {
    map = window.netMap = L.map('map', {
        crs: L.CRS.EPSG3857,
        zoomControl: false,
        editable: true,
        maxZoom: 22,
        minZoom: 2
    }).setView([33.39995, 105.017879], 4);

    L.tileLayer(
        `https://{s}.tianditu.gov.cn/img_w/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=img&STYLE=default&TILEMATRIXSET=w&FORMAT=tiles&TILECOL={x}&TILEROW={y}&TILEMATRIX={z}&tk=b6dd45b324d49519dfb843688f589bf5`,
        {
            id: "tdtImg",
            minZoom: 3,
            maxZoom: 25,
            subdomains: ["t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7"],
            attribution: false,
        }
    ).addTo(map);

    map.attributionControl.setPrefix('&copy; <a href="https://www.eacon.com">易控智驾</a>');

    popup = L.popup({ closeButton: false, className: 'leaflet-popup' });

    map.on('zoom', () => {
        curZoom.value = map.getZoom();
    });
};

// 环境地图
const initEnvMap = (env) => {
    const { ENV_LAT_LNGS } = window.config;

    // map.off('zoomend');

    let layer = '';
    if (env == "zdk") {
        layer = 'zd';
    } else {
        layer = env;
    }

    // 无人机底图
    envLayer && map.removeLayer(envLayer);

    const url = `https://map-${env}.eqfleetcmder.com/gwc/service/wmts?service=WMTS&request=GetTile&version=1.0.0&layer=eq-map:map_${layer}&style=&tilematrixset=EPSG:3857&format=image/png&width=256&height=256&tilematrix=EPSG:3857:{z}&tilerow={y}&tilecol={x}`;

    envLayer = L.tileLayer(url, {
        id: "eqImg",
        minZoom: 2,
        maxZoom: 24,
        maxNativeZoom: 26
    })

    map.addLayer(envLayer);
    map.setView(ENV_LAT_LNGS[env][0], ENV_LAT_LNGS[env][1]);

    // 基于缩放级别切换图层
    map.on('zoomend', function (e) {
        let currentZoom = map.getZoom();
        if (currentZoom < ENV_LAT_LNGS[env][1]) {
            map.removeLayer(envLayer)
        } else {
            map.addLayer(envLayer)
        }
    });

};

// 处理历史数据
const resolveHistoryData = (datas) => {
    map.attributionControl.setPrefix('&copy; <a href="https://www.eacon.com">易控智驾</a>');
    
    let hotlineData = [];
    datas.forEach(data => {
        if(data[0] != 0 && data[1] != 0){
            hotlineData.push([data[0], data[1], data[2]]);
        }
    });
    
    // const hotlineData = datas.map(data => [data[0], data[1], data[2]]);
    hotlineLayer && hotlineLayer.remove();
    if(hotlineData.length < 2) return;

    getCatchTrackDataMap(datas);

    addHotLineLayer(hotlineData);
};

// 处理实时数据
const resolveRealTimeData = (datas) => {
    if (!datas.length) return;
    const lastPoint = datas.at(-1);

    let hotlineData = [];
    datas.forEach(data => {
        if(data[0] != 0 && data[1] != 0){
            hotlineData.push([data[0], data[1], data[2]]);
        }
    });
    // const hotlineData = datas.map(data => [data[0], data[1], data[2]]);
    
    if(!hotlineData.length) return;

    getCatchTrackDataMap(datas);

    if (!hotlineLayer) {
        addHotLineLayer(hotlineData);
    } else {
        hotlineLayer.setLatLngs(hotlineData);
    }

    map.setView(L.latLng(lastPoint[0], lastPoint[1]));
    if (datas.length === 1) map.setZoom(18);

    addVehicleMarker([lastPoint[0], lastPoint[1]])
};

// 添加车辆图标
const addVehicleMarker = (latLng) => {
    const myIcon = L.icon({
        iconUrl: pointPng,
        iconSize: [30, 30]
    });

    if (!vehicleMarker) {
        vehicleMarker = L.marker(latLng, { icon: myIcon }).addTo(map);
    } else {
        vehicleMarker.setLatLng(latLng);
    }
};

// 添加热力图图层
const addHotLineLayer = (hotlineData) => {
    offlineLayer && offlineLayer.remove();
    hotlineLayer && hotlineLayer.remove();
    
    let { min, max, label } = datatypeOptions[monitorType.value];

    if (label === '基站信号') {
        [min, max] = [max, min];
    }

    hotlineLayer = L.hotline(
        hotlineData,
        {
            min, max,
            // min: -80,
            // max: -95,
            smoothFactor: 0,
            weight: 6,
            outlineColor: '#000000',
            outlineWidth: 0,
            palette: {
                0.0: '#008800',
                0.5: '#ffff00',
                1.0: '#ff0000'
            },
        }).addTo(map);

    console.log('hotlineLayer', hotlineLayer);

    // 注册鼠标移入事件
    hotlineLayer.on('mousemove', (e) => {
        const { latlng: { lat, lng } } = e;
        const targetPoint = turf.point([lng, lat], { "marker-color": "#F00" });
        const nearest = turf.nearestPoint(targetPoint, turfFeatureCollect);
        const { geometry: { coordinates = [] } } = nearest;
        const value = catchTrackDataMap[`${coordinates[1]}_${coordinates[0]}`][2];
        const time = catchTrackDataMap[`${coordinates[1]}_${coordinates[0]}`][5];
        const receive = catchTrackDataMap[`${coordinates[1]}_${coordinates[0]}`][3];
        const send = catchTrackDataMap[`${coordinates[1]}_${coordinates[0]}`][4];
        const pci = catchTrackDataMap[`${coordinates[1]}_${coordinates[0]}`][6];
        const { monitorType } = trunkCenterStore;
        const { label, unit } = datatypeOptions[monitorType];

        const content = getPopupContent({name: label, value, receive, send, time, unit, pci});

        popup.setLatLng([lat, lng]).setContent(content).openOn(map);
    });




    // 注册鼠标移出事件
    hotlineLayer.on('mouseout', () => {
        popup.close();
    });

    map.fitBounds(hotlineLayer.getBounds());
};

// 添加掉线区域图层
let offlineLayer = null;
const addOfflineLayer = (data) => {

    hotlineLayer && hotlineLayer.remove();
    offlineLayer && offlineLayer.remove();

    if (data.length == 0) {
        ElMessage.warning("未发现掉线区域")
        return
    }

    offlineLayer = L.canvasMarkerLayer({collisionFlg: true}).addTo(window.netMap);

    var myIcon = L.icon({
        iconUrl: redmk,
        iconSize: [15, 15],
        iconAnchor: [10, 9],
    });

    const { monitorType } = trunkCenterStore;
    const { label, unit } = datatypeOptions[monitorType];

    window.netMap.setView(L.latLng(data[0][0], data[0][1]));
    

    let markers = []
    for (let i = 0; i < data.length; i++) {
        const value = data[i]
        const content = `<div class='popupBox'>
            <span>${label}: ${value[2]} <span class="unit">(${unit})</span></span>
            <span>DTU接收: ${(value[3] / 1024 / 1024 * 8).toFixed(2)} <span class="unit">(Mbps)</span></span>
            <span>DTU发送: ${(value[4] / 1024 / 1024 * 8).toFixed(2)} <span class="unit">(Mbps)</span></span>
            <span>PCI：${value[6]}</span>
            <span>时间: ${value[5]}</span>
        </div>`;
        console.log(value[0], value[1]);
        const marker = L.marker([value[0], value[1]], {
           icon: myIcon
        }).bindPopup(content);
        markers.push(marker);
    }
    // console.log('markers', markers);
    offlineLayer.addLayers(markers);
};


// 获取popup内容
const getPopupContent = ({name, value, receive, send, time, unit, pci}) => {
    const content = `<div class='popupBox'>
            <span>${name}: ${value} <span class="unit">(${unit})</span></span>
            <span>DTU接收: ${(receive / 1024 / 1024 * 8).toFixed(2)} <span class="unit">(Mbps)</span></span>
            <span>DTU发送: ${(send / 1024 / 1024 * 8).toFixed(2)} <span class="unit">(Mbps)</span></span>
            <span>PCI：${pci}</span>
            <span>时间: ${time}</span>
        </div>`;

    return content;
};

// 获取历史缓存数据
const getCatchTrackDataMap = (datas) => {
    catchTrackDataMap = {};
    let turfPoints = [];

    datas.forEach(data => {
        catchTrackDataMap[`${data[0]}_${data[1]}`] = data;
        turfPoints.push(turf.point([data[1], data[0]]));
    });

    turfFeatureCollect = turf.featureCollection(turfPoints);
};

// 展示图表
const showEchart = () => {
    emits('toggleEchartShow');
};

watch(() => props.curEnv, (val = '') => {
    if (!val) return;
    initEnvMap(val)
});

// 历史数据监听
watch(() => props.historyData, (val = []) => {
    vehicleMarker && vehicleMarker.remove();
    popup && popup.close();
    if (!val.length) return;
    resolveHistoryData(val);
});

// 掉线数据监听
watch(() => props.offlineData, (val = []) => {
    addOfflineLayer(val);
});

// 实时数据监听
watch(() => realTimeDatas, (newValue) => {
    popup && popup.close();
    resolveRealTimeData(newValue.value);
}, {
    immediate: true,
    deep: true
});

watch(() => props.isTranstionEnd, (val = []) => {
    map && map.invalidateSize(true);
});

// 图表数据监听
watch(() => props.curPointData, (val = []) => {
    if (!val.length || !popup || !map) return;
    const { monitorType } = trunkCenterStore;
    const { label, unit } = datatypeOptions[monitorType];
    const [value, receive, send, time, pci] = [val[2], val[3],val[4], val[5], val[6]];
    
    popup.close();
    if(val[0] === 0 || val[1] === 0) {
        ElMessage({
            type: 'warning',
            message: '定位点无坐标信息！',
        })
        return;
    };
    
    const content = getPopupContent({name:label, value, receive, send, time, unit, pci});
    popup.setLatLng([val[0], val[1]]).setContent(content).openOn(map);

    map.setView(L.latLng(val[0], val[1]));
});
</script>

<style lang="scss" scoped>
.mapContainer {
    position: relative;
    width: 100%;
    height: 100%;

    #map {
        width: 100%;
        height: 100%;

        .control-item {
            position: absolute;
            width: 30px;
            height: 30px;
            color: #fff;
            z-index: 1000;
            top: 10px;
            border-radius: 3px;
            background-color: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.3s;
            font-size: 14px;
            right: 10px;
        }

        .zoom {
            right: 10px;
        }

        .chartIcon {
            top: 45px;
            cursor: pointer;

            &:hover {
                background-color: rgba(0, 0, 0, 0.8);
                color: #5CD2EB;
            }
        }

        .active {
            background-color: rgba(0, 0, 0, 0.8);
            color: #5CD2EB;
        }
    }
}
</style>

<style lang="scss">
.leaflet-popup {
    .leaflet-popup-content-wrapper {
        background-color: rgba(0, 0, 0, 0.6);
        color: #fff;

        .leaflet-popup-content {
            margin: 10px 20px 10px 20px
        }

    }

    .leaflet-popup-tip-container {
        .leaflet-popup-tip {
            background-color: rgba(0, 0, 0, 0.6);
        }
    }

    .popupBox {
        display: flex;
        flex-direction: column;

        span:not(:last-child){
            display: inline-block;
            margin-bottom: 6px;
        }
        .unit{
            font-size: 12px;
        }
    }
}
</style>