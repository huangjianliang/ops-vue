<template>
    <div class="networkContainer">
        <div class="top">
            <NetworkSearch 
                :echartShow="echartShow"
                @updateEnv="updateEnv"
                @updateHistoryData="updateHistoryData" 
                @updateOfflineData="updateOfflineData" 
                @toggleEchartShow="toggleEchartShow" />
        </div>
        <main>
            <div class="left">
                <NetworkMap 
                    :curEnv="curEnv"
                    :curPointData="curPointData"
                    :historyData="historyData" 
                    :offlineData="offlineData"
                    :echartShow="echartShow"
                    :isTranstionEnd="isTranstionEnd"
                    @toggleEchartShow="toggleEchartShow"/>
            </div>
            <div class="right" :class="{ 'hidden': !echartShow }" ref="rightWrap">
                <NetworkEchart 
                    :historyData="historyData" 
                    :isTranstionEnd="isTranstionEnd"
                    @setCurPointData="setCurPointData"/>
            </div>
        </main>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

import NetworkSearch from './components/NetworkSearch.vue';
import NetworkMap from './components/NetworkMap.vue';
import NetworkEchart from './components/NetworkEchart.vue';

const echartShow = ref(false);          // 图表组件显示、隐藏状态
const historyData = ref([]);            // 历史数据
const offlineData = ref([]);            // 掉线区域数据
const rightWrap = ref(null);
const isTranstionEnd = ref(false);      // 动画状态
const curPointData = ref(null);         // 当前点位数据
const curEnv = ref('');                 // 当前环境

onMounted(() => {
    addTranstionEndEvent();
});

// 添加动画结束事件
const addTranstionEndEvent = () => {
    rightWrap.value.addEventListener("transitionend", function () {
        isTranstionEnd.value = !isTranstionEnd.value;
    });
};

const toggleEchartShow = () => {
    echartShow.value = !echartShow.value;
};

// 历史数据更新
const updateHistoryData = (data) => {
    historyData.value = data;
    // echartShow.value = true;
};

// 掉线区域数据更新
const updateOfflineData = (data) => {
    offlineData.value = data;
};

// echarts 当前悬浮点
const setCurPointData = (data) => {
    curPointData.value = data;
};

// 更新环境名称
const updateEnv = (val) => {
    curEnv.value = val;
};

</script>

<style lang="scss" scoped>
.networkContainer {
    display: flex;
    flex-direction: column;
    height: 100%;

    main {
        display: flex;
        flex: 1;
        box-shadow: 0 0 12px rgba(0, 0, 0, 0.25);
        .left {
            // width: 60%;
            flex: 1;
        }

        .right {
            width: 40%;
            transition: all 0.3s;
        }

        .hidden {
            width: 0%;
        }
    }
}
</style>