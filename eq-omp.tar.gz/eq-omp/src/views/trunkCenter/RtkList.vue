<!-- 应用列表 -->

<template>
	<div class="main-box">
		<div class="table-box">
			<ProTable ref="proTable" :selectId="selectId" :columns="columns" :requestApi="rtkListApi" resetLabel="刷新" :initParam="initParam"></ProTable>
		</div>
        <div>
        </div>

	</div>
</template>
<script setup name="MediaList">
import { ref, reactive  } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { rtkListApi, getEnvTrunkTerminalListApi, rtkSwitchApi} from '@/api/modules/trunkCenter.js';
import { ElMessage } from 'element-plus';


// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认值为不存在的环境
	//"env_name": 'test06',  
	//"pageNum": 1,
	//"pageSize": 20
});


const selectEnv = (item) => {
    initParam.env_name = item.env_name
    return {"code": 200, "data": ""}
}

const switchRtk = async (item) => {
    const rtkId = item['rtkId'];
	const env_name = item["env_name"]; 

    const params = {env_name, rtkId}
    const res = await rtkSwitchApi(params);
    const { code, message } = res
    if(code == 200 && message == "OK") {
        ElMessage.success('RTK 基站切换指令下发成功，请稍后刷新！')
    }else{
        ElMessage.error('RTK 基站切换失败：' + message)
    }                                        
}

// 表格配置项
const columns = [
	{
		prop: "env_name",
		label: "运行环境",
		search: true,
		searchType: "select",
		enum: getEnvTrunkTerminalListApi,
		searchProps: { label: "label", value: "env_name" },
        changeProps: { api: selectEnv}
	},
	{ 
	    prop: "rtkId", 
	    label: "基站编号",
        sortable: true
	},
	{ 
	    prop: "status", 
	    label: "链路状态",
		type: "status",
		truelabel: "正常",
		falselabel: "异常"
	},
    { 
	    prop: "enableStatus", 
	    label: "当前活跃",
		type: "status",
		truelabel: "是",
		falselabel: "否"
	},
	{ 
	    prop: "dataTime", 
	    label: "数据上报时间"
	},
	{ 
	    prop: "statusTime", 
	    label: "基站上线时间"
	},
	{
        type: "rtkbutton",
		prop: "status",
		label: "切换",
        action: switchRtk
	}
];

</script>

