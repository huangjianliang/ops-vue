<template>
    <div class="echartContainer">
        <div class="card table-search log-search">
            <el-form ref="formRef" :model="searchForm" :inline="true">
                <el-form-item label="扇区">
                    <el-select v-model="searchForm.env" @change="changeEnv" filterable clearable placeholder="环境"
                        style="width: 100px;">
                        <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label"
                            :value="item.env_name" />
                    </el-select>
                    <el-select v-model="searchForm.pci" filterable clearable allow-create placeholder="PCI" style="width: 100px;">
                        <el-option v-for="item in pciOptions" :key="item.pci_number" :label="item.pci_number"
                            :value="item.pci_number" />
                    </el-select>
                </el-form-item>

                <el-form-item label="时间">
                    <el-date-picker v-model="searchForm.time" format="YYYY-MM-DD HH:mm:ss"
                        value-format="YYYY-MM-DD HH:mm:ss" type="datetimerange" start-placeholder="开始" end-placeholder="结束"
                        :shortcuts="shortcuts" range-separator="至" editable style="width: 350px;" />
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="initEcharts">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        
        <div class="echart-item" style="float: left;" ref="pingChartRef"></div>
        <div class="echart-item" style="float: right;" ref="signalChartRef"></div>
        <span class="divide"></span>
        <div class="echart-item" style="float: left;" ref="activeChartRef"></div>
        <div class="echart-item" style="float: right;" ref="bandwidthChartRef"></div>

    </div>
</template>


<script setup name="BaseMonitor">

import { onMounted, onUnmounted, reactive, ref } from 'vue';
import { getNowDate } from '@/utils/util';
import { getEnvTrunkTerminalListApi, pciListApi, pingApi, signalApi, activeApi, bandwidthApi } from '@/api/modules/trunkCenter.js';
import { ElMessage } from 'element-plus';
import * as echarts from "echarts";
import { useGlobalStore } from '@/store';

const searchForm = reactive({
    env: '',
    pci: '',
	datatype: 0,
    time: [new Date('2023-03-22 12:00:00'), new Date('2023-03-22 12:00:00')],
});

const datatypeOptions = [
		{ index: 0, name: "bindwidth",label: "带宽", unit: "Mbps"},
		{ index: 1, name: "signal", label: "信号", unit: "dBm" },
		{ index: 2, name: "ping", label: "ping延时", unit: "ms" },
		{ index: 3, name: "active", label: "在线终端", unit: "ms" },
	]

const shortcuts = [
    {
        text: '最近 5 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 5 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 30 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 30 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 1 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 4 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 4 * 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '今天',
        value: () => {
            const end = new Date()
            const start = new Date(end.getFullYear(), end.getMonth(), end.getDate()); // 将时分秒设置为0，获取今天零点的时间
            return [start, end]
        },
    },
    {
        text: '昨天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate())
            return [start, end]
        },
    },
    {
        text: '前天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            return [start, end]
        },
    },
]

// 初始化时间
const initDate = () => {
    const { year, month, day, hour, minute, second } = getNowDate();
    const startHour = hour - 1 > 0 ? hour - 1 : hour;
    const startDate = `${year}-${month}-${day} ${startHour}:${hour === startHour ? "00" : minute}:${hour === startHour ? "00" : second}`;
    const endDate = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    searchForm.time = [startDate, endDate];
};

// 获取环境选项
const envOptions = ref([]);
const getEnvTrunkTerminalList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 25 };
        const res = await getEnvTrunkTerminalListApi(params);
        const { code, data } = res
        if (code === 200) {
            envOptions.value = data
        } else {
            ElMessage.error('获取环境列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 获取 PCI 选项
const pciOptions = ref([]);
const pciList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env_name": searchForm.env };
        const res = await pciListApi(params);
        const { code, data } = res
        if (code === 200) {
            pciOptions.value = data['dataList']
        } else {
            ElMessage.error('获取车辆列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 切换环境
const changeEnv = async () => {
    pciList();
    searchForm.pci = '';
}

const singleYdata = (xdata, ydata, title, unit) => {
    return {
        color: ['#80FFA5'],
        title: {
            show: true,
            text: title,
            textStyle: {
                color: '#fff',
                fontStyle: 'normal',
                fontWeight: 'normal',
                fontFamily: 'sans-serif',
                fontSize: 18,
                lineHeight: 18,
            },
            left: 'center',
            top: 'top'
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        legend: {
            show: false,
            data: [title],
            right: 10,
            textStyle: {
                color: "#fff"
            },
            itemWidth: 14,
            itemHeight: 10,
            itemGap: 13
        },
        xAxis: {
            type: 'category',
            data: xdata,
            boundaryGap: false,
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                },
                formatter: function (value) {
                    if (value.includes(' ')) {
                        return value.split(' ')[1];
                    }
                    return value;
                },
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        yAxis: {
            name: unit,
            type: 'value',
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                }
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        series: [
            {
                name: title,
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(128, 255, 165)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(1, 191, 236)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: ydata
            },
        ]
    };
};

const doubleYdata = (xdata, y1data, y2data, y1name, y2name, title, unit, legend) => {
    return {
        color: ['#37A2FF', '#FF0087'],
        title: {
            show: true,
            text: title,
            textStyle: {
                color: '#fff',
                fontStyle: 'normal',
                fontWeight: 'normal',
                fontFamily: 'sans-serif',
                fontSize: 18,
                lineHeight: 18,
            },
            left: 'center',
            top: 'top'
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        legend: {
            data: legend,
            right: 10,
            textStyle: {
                color: "#fff"
            },
            itemWidth: 14,
            itemHeight: 10,
            itemGap: 13
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: xdata,
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {
                show: true,
                textStyle: {
                    color: "#fff",
                },
                formatter: function (value) {
                    if (value.includes(' ')) {
                        return value.split(' ')[1];
                    }
                    return value;
                },
            },
            splitLine: {
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        yAxis: {
            name: unit,
            type: 'value',
            axisLine: {
                show: true,
                lineStyle: {
                    color: "#fff",
                    width: 0,
                    type: "solid"
                }
            },
            axisTick: {
                show: false,
            },
            axisLabel: {//x轴文字的配置
                show: true,
                textStyle: {
                    color: "#fff",
                }
            },
            splitLine: {//分割线配置
                show: false,
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        series: [
            {
                name: y1name,
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(0, 221, 255)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(77, 119, 255)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: y1data
            },
            {
                name: y2name,
                type: 'line',
                stack: 'Total',
                smooth: true,
                lineStyle: {
                    width: 0
                },
                showSymbol: false,
                areaStyle: {
                    opacity: 0.8,
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                            offset: 0,
                            color: 'rgb(55, 162, 255)'
                        },
                        {
                            offset: 1,
                            color: 'rgb(116, 21, 219)'
                        }
                    ])
                },
                emphasis: {
                    focus: 'series'
                },
                data: y2data
            },
        ]
    };
};

// 获取 ping 图表内容
const pingx = ref([]);
const pingy = ref([]);
const pingApiList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env": searchForm.env, "pci": searchForm.pci, "time": searchForm.time };
        const res = await pingApi(params);
        const { code, data } = res
        if (code === 200) {
            pingx.value = data["xdata"]
            pingy.value = data["ydata"]
        } else {
            ElMessage.error('获取列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 获取信号图表内容
const signalx = ref([]);
const signaly = ref([]);
const signalApiList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env": searchForm.env, "pci": searchForm.pci, "time": searchForm.time };
        const res = await signalApi(params);
        const { code, data } = res
        if (code === 200) {
            signalx.value = data["xdata"]
            signaly.value = data["ydata"]
        } else {
            ElMessage.error('获取列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 在线终端图表内容
const activex = ref([]);
const activey = ref([]);
const activeApiList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env": searchForm.env, "pci": searchForm.pci, "time": searchForm.time };
        const res = await activeApi(params);
        const { code, data } = res
        if (code === 200) {
            activex.value = data["xdata"]
            activey.value = data["ydata"]
        } else {
            ElMessage.error('获取列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 带宽图表内容
const bandwidthx = ref([]);
const bandwidthy1 = ref([]);
const bandwidthy2 = ref([]);
const bandwidthApiList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env": searchForm.env, "pci": searchForm.pci, "time": searchForm.time };
        const res = await bandwidthApi(params);
        const { code, data } = res
        if (code === 200) {
            bandwidthx.value = data["down"]["xdata"]
            bandwidthy1.value = data["up"]["ydata"]
            bandwidthy2.value = data["down"]["ydata"]
        } else {
            ElMessage.error('获取列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 图表
const pingChartRef = ref(null); // ping
const signalChartRef = ref(null); // 信号
const activeChartRef = ref(null); // 在线终端
const bandwidthChartRef = ref(null); // 带宽

// 初始化图表
let pingChart = null;
let signalChart = null;
let activeChart = null;
let bandwidthChart = null;

const initEcharts = async () => {
    !pingChart && (pingChart = echarts.init(pingChartRef.value))
    await pingApiList()
    pingChart.setOption(singleYdata(pingx.value, pingy.value, "ping 延时", "ms"))

    !signalChart && (signalChart = echarts.init(signalChartRef.value))
    await signalApiList()
    signalChart.setOption(singleYdata(signalx.value, signaly.value, "信号", "dBm"))

    !activeChart && (activeChart = echarts.init(activeChartRef.value))
    await activeApiList()
    activeChart.setOption(singleYdata(activex.value, activey.value, "在线终端", "个"))

    !bandwidthChart && (bandwidthChart = echarts.init(bandwidthChartRef.value))
    await bandwidthApiList()
    bandwidthChart.setOption(doubleYdata(bandwidthx.value, bandwidthy1.value, bandwidthy2.value, "发送", "接收", "带宽", "Mbps", ["发送", "接收"]))
};

onMounted(() => {
    initDate();
    getEnvTrunkTerminalList();
});
</script>

<style>
.echartContainer {
    width: 100%;
    height: 100%;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.8);
    box-sizing: border-box;

    .echart-item {
        width: 50%;
        height: 300px;
        padding: 2%;
        box-sizing: border-box;
    }

    .divide {
        display: inline-block;
        height: 1px;
        width: 100%;
        background-color: rgba(0, 0, 0, 0.3);
    }
}
</style>