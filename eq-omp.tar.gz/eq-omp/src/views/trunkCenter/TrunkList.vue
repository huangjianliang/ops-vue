<!-- 应用列表 -->

<template>
	<div class="main-box">
		<div class="table-box">
			<ProTable ref="proTable" :selectId="selectId" :columns="columns" :requestApi="getTrunkCenterListApi" :initParam="initParam"></ProTable>
		</div>
        <div>
        </div>

	</div>
</template>
<script setup name="TrunkList">
import { ref, reactive  } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { getTrunkCenterListApi, getEnvTrunkTerminalListApi } from '@/api/modules/trunkCenter.js';
import { ElMessage } from 'element-plus';

// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认值为不存在的环境
	//"env_name": 'aaa',
	"pageNum": 1,
	"pageSize": 20
});

const selectEnv = (item) => {
    initParam.env_name = item.env_name
    return {"code": 200, "data": ""}
}

// 表格配置项
const columns = [
	{
		prop: "env_name",
		label: "环境",
		search: true,
		searchType: "select",
		enum: getEnvTrunkTerminalListApi,
		searchProps: { label: "label", value: "env_name" },
        changeProps: { api: selectEnv}
	},
	{ 
	    prop: "trunk_number", 
	    label: "编号",
        sortable: true
	},
	{
        type: "color",
		prop: "status",
		label: "FRP 状态",
        sortable: true
	},
	{ 
		type: "link", 
	    prop: "mdc_url", 
	    label: "MDC 终端"
	},
    { 
		type: "link", 
	    prop: "v2x_url", 
	    label: "V2X 终端"
	},
    { 
		type: "link", 
	    prop: "dtu_url", 
	    label: "DTU 控制台"
	},
    { 
		type: "link", 
	    prop: "hc_url", 
	    label: "华测控制台"
	},
	{ 
		type: "link", 
	    prop: "cpe_url", 
	    label: "CPE 控制台"
	}
];

</script>

