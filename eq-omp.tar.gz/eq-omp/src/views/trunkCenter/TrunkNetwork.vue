<template>
    <div class="networkContainer">
        <div class="card table-search log-search">
            <el-form ref="formRef" :model="searchForm" :inline="true">
                <el-form-item label="车辆">
                    <el-select v-model="searchForm.env" @change="changeEnv" filterable clearable placeholder="环境"
                        style="width: 100px;">
                        <el-option v-for="item in envOptions" :key="item.env_name" :label="item.label"
                            :value="item.env_name" />
                    </el-select>
                    <el-select v-model="searchForm.trunk" filterable clearable allow-create placeholder="车辆" style="width: 100px;">
                        <el-option v-for="item in trunkOptions" :key="item.trunk_number" :label="item.trunk_number"
                            :value="item.trunk_number" />
                    </el-select>
                    <el-select v-model="searchForm.datatype" filterable placeholder="指标" style="width: 100px;">
                        <el-option v-for="item in datatypeOptions" :key="item.name" :label="item.label"
                            :value="item.index" />
                    </el-select>
                </el-form-item>

                <el-form-item label="时间">
                    <el-date-picker v-model="searchForm.time" format="YYYY-MM-DD HH:mm:ss"
                        value-format="YYYY-MM-DD HH:mm:ss" type="datetimerange" start-placeholder="开始" end-placeholder="结束"
                        :shortcuts="shortcuts" range-separator="至" editable style="width: 350px;" />
                </el-form-item>

                <el-form-item>
                    <el-button v-if="tracking" type="danger" @click="stopTrack">停止跟车</el-button>
                    <el-button v-else="tracking" type="primary" @click="startTrack">跟车测速</el-button>
                    <el-button type="success" @click="getTrunkNet">历史查询</el-button>
                    <el-button v-if="showCharts" @click="hideCharts">隐藏图表</el-button>
                    <el-button v-else="showCharts" @click="unHideCharts">显示图表</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div id="map">
            <div class="echart-item" v-show="showCharts">
                <div class="content">
                    <div style="width: 100%; height: 200px;" ref="mainChartRef"></div>
                    <el-divider />
                    <div style="width: 100%; height: 200px;" ref="dtuTrafficChartRef"></div>
                </div>
            </div>
            <LegendC :datatype="searchForm.datatype" />
        </div>
    </div>
</template>


<script setup name="TrunkNetwork">

import { onMounted, onUnmounted, reactive, ref } from 'vue';
import { getNowDate } from '@/utils/util';
import { getTrunkListApi, getEnvTrunkTerminalListApi, getTrunkNetApi } from '@/api/modules/trunkCenter.js';
import { ElMessage } from 'element-plus';
import LegendC from './Legend.vue';
import * as echarts from "echarts";
import { useGlobalStore } from '@/store';
import { remove } from '@vue/shared';

const searchForm = reactive({
    env: '',
    trunk: '',
    datatype: 0,
    time: [new Date('2023-03-22 12:00:00'), new Date('2023-03-22 12:00:00')],
});

const { datatypeOptions } = window.config

const shortcuts = [
    {
        text: '最近 5 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 5 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 30 分钟',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 30 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 1 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '最近 4 个小时',
        value: () => {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 4 * 60 * 60 * 1000)
            return [start, end]
        },
    },
    {
        text: '今天',
        value: () => {
            const end = new Date()
            const start = new Date(end.getFullYear(), end.getMonth(), end.getDate()); // 将时分秒设置为0，获取今天零点的时间
            return [start, end]
        },
    },
    {
        text: '昨天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate())
            return [start, end]
        },
    },
    {
        text: '前天',
        value: () => {
            const now = new Date()
            const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2)
            const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
            return [start, end]
        },
    },
]

// 初始化时间
const initDate = () => {
    const { year, month, day, hour, minute, second } = getNowDate();
    const startHour = hour - 1 > 0 ? hour - 1 : hour;
    const startDate = `${year}-${month}-${day} ${startHour}:${hour === startHour ? "00" : minute}:${hour === startHour ? "00" : second}`;
    const endDate = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    searchForm.time = [startDate, endDate];
};

// 获取环境选项
const envOptions = ref([]);
const getEnvTrunkTerminalList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 25 };
        const res = await getEnvTrunkTerminalListApi(params);
        const { code, data } = res
        if (code === 200) {
            envOptions.value = data
        } else {
            ElMessage.error('获取环境列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// 获取车辆选项
const trunkOptions = ref([]);
const getTrunkCenterList = async () => {
    try {
        const params = { "pageNum": 1, "pageSize": 100, "env_name": searchForm.env };
        const res = await getTrunkListApi(params);
        const { code, data } = res
        if (code === 200) {
            trunkOptions.value = data['dataList']
        } else {
            ElMessage.error('获取车辆列表失败！')
        }
    } catch (error) {
        throw new Error(error);
    }
}

// map
let map = null;
let tdtLayer = null;
let envLayer = null;
let popup = null;
let catchTrackDataMap = {};

// 首屏地图
const initMap = () => {
    map = L.map('map', {
        crs: L.CRS.EPSG3857,
        zoomControl: true,
        editable: true
    }).setView([33.39995, 105.017879], 4);

    //将图层加载到地图上，并设置最大的聚焦还有map样式
    tdtLayer && tdtLayer.remove();
    tdtLayer = L.tileLayer(
        `https://{s}.tianditu.gov.cn/img_w/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=img&STYLE=default&TILEMATRIXSET=w&FORMAT=tiles&TILECOL={x}&TILEROW={y}&TILEMATRIX={z}&tk=b6dd45b324d49519dfb843688f589bf5`,
        {
            id: "tdtImg",
            minZoom: 3,
            maxZoom: 25,
            subdomains: ["t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7"],
            attribution: false,
        }
    ).addTo(map);

    //添加注记
    //var vector_note=L.tileLayer("https://t1.tianditu.gov.cn/cva_c/wmts?layer=cva&style=default&tilematrixset=c&Service=WMTS&Request=GetTile&Version=1.0.0&Format=tiles&TileMatrix={z}&TileCol={x}&TileRow={y}&tk=b6dd45b324d49519dfb843688f589bf5", {
    //  maxZoom: 5,
    //  tileSize: 256,
    //  zoomOffset: 1,
    //  zIndex:5,
    //  minZoom: 3,
    //  attribution: false,
    //}).addTo(map);

    map.attributionControl.setPrefix('&copy; <a href="https://www.eacon.com">易控智驾</a>');

    //const azcMarker = L.marker([35.258727389, 116.977681012]).addTo(map).bindPopup('邹城：azc').openPopup();
    //const nltMarker = L.marker([44.836811227, 89.264543422]).addTo(map).bindPopup('南露天：nlt').openPopup();
    //const zdkMarker = L.marker([44.84393355, 89.136012086]).addTo(map).bindPopup('准东：zdk').openPopup();
    
    popup = L.popup({closeButton: false, className: 'leaflet-popup'});
};

// 环境地图
const initEnvMap = (env) => {

    const { ENV_LAT_LNGS } = window.config

    map.off('zoomend');

    let layer = '';
    if (env == "zdk") {
        layer = 'zd';
    } else {
        layer = env;
    }

    // 无人机底图
    envLayer && map.removeLayer(envLayer);
    envLayer = new L.TileLayer.WMTS('https://map-' + env + '.eqfleetcmder.com/gwc/service/wmts', {
        LAYER: "eq-map:map_" + layer,
        //STYLE: "default",
        TILEMATRIXSET: "EPSG:3857",
        //tilematrix: "EPSG:3857:20",
        FORMAT: "image/png",
        VERSION: "1.0.0",
        attribution: false,
    });

    map.addLayer(envLayer);
    map.setView(ENV_LAT_LNGS[env][0], ENV_LAT_LNGS[env][1]);

    // 基于缩放级别切换图层
    map.on('zoomend', function (e) {
        let currentZoom = map.getZoom();
        if (currentZoom < ENV_LAT_LNGS[env][1]) {
            map.removeLayer(envLayer)
        } else {
            map.addLayer(envLayer)
        }
    });

}

//轨迹追踪
const tracking = ref(false);
let socket = null;
let hotlineLayer = null;
let trackMarker = null;
let trackCount = 0;
let turfFeatureCollect = null;

const startTrack = () => {
    cleanCharts();
    showCharts.value = true;

    if (searchForm.env == '' || searchForm.trunk == '') {
        ElMessage.warning('请选择环境和车辆！')
        return
    }

    trackCount = 0;
    hotlineLayer && hotlineLayer.remove();
    trackMarker && trackMarker.remove();

    tracking.value = true;

    if (datatypeOptions[searchForm.datatype]['name'] == 'signal') {
        hotlineLayer = L.hotline(
            [], {
            min: datatypeOptions[searchForm.datatype]['min'],
            max: datatypeOptions[searchForm.datatype]['max'],
            smoothFactor: 0,
            weight: 3,
            palette: { 0.0: 'red', 0.5: 'yellow', 1.0: 'green' }
        }).addTo(map);
    } else {
        hotlineLayer = L.hotline(
            [], {
            min: datatypeOptions[searchForm.datatype]['min'],
            max: datatypeOptions[searchForm.datatype]['max'],
            smoothFactor: 0,
            weight: 3
        }).addTo(map);
    }

    const { WS_TRUNK_URL } = window.config;
    const globalStore = useGlobalStore();
    const { token } = globalStore;

    socket && socket.close();
    socket = new WebSocket(WS_TRUNK_URL + '?' + 'trunk=' + searchForm.trunk + '&' + 'env=' + searchForm.env + '&' + 'datatype=' + datatypeOptions[searchForm.datatype]['name'] + '&token=' + token);

    socket.onopen = function () {
        console.log("连接状态：已连接");
    }

    socket.onmessage = function (event) {
        var obj = JSON.parse(event.data);

        var markerData = [obj[0], obj[1], obj[2]]
        let trunkStats = '';

        if (datatypeOptions[searchForm.datatype]['name'] == 'signal') {
            trunkStats = '环境：' + searchForm.env + '，车辆：' + searchForm.trunk + '，位置：' + markerData[0] + ' ' + markerData[1] + '，信号：' + markerData[2] + 'dBm';
        }

        if (datatypeOptions[searchForm.datatype]['name'] == 'ping') {
            trunkStats = '环境：' + searchForm.env + '，车辆：' + searchForm.trunk + '，位置：' + markerData[0] + ' ' + markerData[1] + '，ping延时：' + markerData[2] + 'ms';
        }

        map.attributionControl.setPrefix(trunkStats)

        if (trackCount == 0) {
            trackMarker = L.marker(markerData).addTo(map);
        }
        if (trackCount > 10000) {
            hotlineLayer.setLatLngs([]);
            trackCount = 0;
        }

        map.setView(markerData);
        trackMarker.setLatLng(markerData);
        hotlineLayer.addLatLng(markerData);
        trackCount = trackCount + 1;

        var chartData = {"list": [obj]};
        initEcharts(chartData);
    }

    socket.onclose = function () {
        console.log('关闭');
    }
}

const stopTrack = async () => {
    if (socket) {
        await socket.close();
        socket = null;
    }
    hotlineLayer && hotlineLayer.remove();
    trackMarker && trackMarker.remove();
    tracking.value = false;
    trackCount = 0;
    map.attributionControl.setPrefix('&copy; <a href="https://www.eacon.com">易控智驾</a>');
}

// 切换环境
const changeEnv = async () => {
    getTrunkCenterList();
    initEnvMap(searchForm.env);
    searchForm.trunk = '';
}

// 获取历史数据
const getTrunkNet = async () => {
    showCharts.value = true;
    stopTrack();

    if (!searchForm.env) {
        ElMessage.warning('请先选择环境！')
        return
    }

    if (!searchForm.trunk) {
        ElMessage.warning('请先选择车辆！')
        return
    }

    try {
        map.attributionControl.setPrefix('&copy; <a href="https://www.eacon.com">易控智驾</a>');
        const params = { "env": searchForm.env, "trunk": searchForm.trunk, "time": searchForm.time, "datatype": datatypeOptions[searchForm.datatype]['name'] };
        const res = await getTrunkNetApi(params);
        const { code, data, msg } = res
        if (code === 200) {
            cleanCharts();
            initEcharts(data);
            // data['list'] = data['list'].slice(5);
            const list = data['list']

            var hotlineData = [];
            for (var i = 0; i < list.length; i ++){
                hotlineData.push([list[i][0], list[i][1], list[i][2]]);
            }
            
            hotlineLayer && hotlineLayer.remove();
            if (datatypeOptions[searchForm.datatype]['name'] == 'signal') {
                hotlineLayer = L.hotline(
                    hotlineData, {
                    min: datatypeOptions[searchForm.datatype]['min'],
                    max: datatypeOptions[searchForm.datatype]['max'],
                    smoothFactor: 0,
                    weight: 3,
                    palette: { 0.0: 'red', 0.5: 'yellow', 1.0: 'green' }
                }).addTo(map);
            } else {
                hotlineLayer = L.hotline(
                    hotlineData, {
                    min: datatypeOptions[searchForm.datatype]['min'],
                    max: datatypeOptions[searchForm.datatype]['max'],
                    smoothFactor: 0,
                    weight: 3
                }).addTo(map);
            }
            getCatchTrackDataMap(list);
            
            hotlineLayer.on('mousemove', (e) => {
                const {latlng: {lat, lng}} = e;
                const targetPoint = turf.point([lng, lat], {"marker-color": "#F00"});
                const nearest = turf.nearestPoint(targetPoint, turfFeatureCollect);
                const { geometry:{coordinates=[]} } = nearest;
                const value = catchTrackDataMap[`${coordinates[1]}_${coordinates[0]}`][2];
                popup.setLatLng([lat, lng]).setContent(`<p>基站信号值：${value}`).openOn(map);
                console.log('popup', popup);
            });

            hotlineLayer.on('mouseout', () => {
               popup.close();   
            });
            
            map.setView(hotlineLayer.getCenter());
        } else {
            ElMessage.error('获取历史数据失败！' + msg)
        }
    } catch (error) {
        throw new Error(error);
    }
}

const getCatchTrackDataMap = (datas) => {
    catchTrackDataMap = {};
    let turfPoints = [];
    
    datas.forEach(data => {
        catchTrackDataMap[`${data[0]}_${data[1]}`] = data;
        turfPoints.push(turf.point([data[1], data[0]]));
    });
    
    turfFeatureCollect = turf.featureCollection(turfPoints);
    
}
// 图表
const mainChartRef = ref(null);
const dtuTrafficChartRef = ref(null);
const showCharts = ref(false);

const getMainChartsOptions = (xdata, ydata, title, unit) => {
    return {
        title: {
            text: title
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: xdata
        },
        yAxis: {
            name: unit,
            type: 'value',
            data: ydata
        },
        series: [
            {
                data: ydata,
                type: 'line',
                smooth: false
            }
        ]
    };
};

const getdtuTrafficChartOptions = (xdata, y1data, y2data, title, unit) => {
    return {
        title: {
            text: title
        },
        tooltip: {
            trigger: 'axis'
        },
        grid: {
            left: '4%',
            right: '3%',
            bottom: '0%',
            containLabel: true
        },
        legend: {
            data: ['接收', '发送']
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: xdata
        },
        yAxis: {
            name: unit,
            type: 'value'
        },
        series: [
            {
                name: "接收",
                data: y1data,
                type: 'line',
            },
            {
                name: "发送",
                data: y2data,
                type: 'line',
            }
        ]
    };
};

// 实例化图标
const mainChartxdata = ref([]);
const mainChartydata = ref([]);
const dtuTrafficChartxdata = ref([]);
const dtuTrafficCharty1data = ref([]);
const dtuTrafficCharty2data = ref([]);

const cleanCharts = () => {
    mainChartxdata.value = [];
    mainChartydata.value = [];
    dtuTrafficChartxdata.value = [];
    dtuTrafficCharty1data.value = [];
    dtuTrafficCharty2data.value = [];
}

const hideCharts = () => {
    showCharts.value = false;
}

const unHideCharts = () => {
    showCharts.value = true;
}

const initEcharts = (data) => {
    if (data) {
        for (var i = 0; i < data['list'].length; i++) {
            mainChartxdata.value.push(data['list'][i][5]); // time
            mainChartydata.value.push(data['list'][i][2]); 

            dtuTrafficChartxdata.value.push(data['list'][i][5]); // time
            dtuTrafficCharty1data.value.push((data['list'][i][3]/1024/1024*8).toFixed(2)); // Mbps
            dtuTrafficCharty2data.value.push((data['list'][i][4]/1024/1024*8).toFixed(2)); // Mbps
        }
    }

    var mainChart = null;
    mainChart = echarts.init(mainChartRef.value);
    const mainChartOptions = getMainChartsOptions(mainChartxdata.value, mainChartydata.value, datatypeOptions[searchForm.datatype]['label'], datatypeOptions[searchForm.datatype]['unit']);
    mainChart.setOption(mainChartOptions);

    var dtuTrafficChart = null;
    dtuTrafficChart = echarts.init(dtuTrafficChartRef.value);
    const dtuTrafficChartOptions = getdtuTrafficChartOptions(dtuTrafficChartxdata.value, dtuTrafficCharty1data.value, dtuTrafficCharty2data.value, 'DTU带宽', 'Mbps');
    dtuTrafficChart.setOption(dtuTrafficChartOptions);
};

onMounted(() => {
    initDate();
    getEnvTrunkTerminalList();
    initMap();
});

onUnmounted(() => {
    stopTrack();
})

</script>

<style>
.networkContainer{
    width: 100%;
    height: 100%;
}
#map {
    width: 100%;
    height: 91%;
}

.content {
    position: absolute;
    top: 1px;
    right: 1px;
    display: flex;
    z-index: 1000;
    flex-direction: column;
    justify-content: flex-start;
    width: 450px;
    height: 400px;
    background-color: white;
}

.log-search {
    padding-bottom: 0px;

    :deep(.el-form-item) {
        margin-bottom: 20px !important;
    }
}
</style>

