<!-- 应用列表 -->

<template>
	<div class="main-box">
		<div class="table-box">
			<ProTable ref="proTable" :selectId="selectId" :columns="columns" :requestApi="getMediaListApi" resetLabel="刷新" :initParam="initParam"></ProTable>
		</div>
        <div>
        </div>

        <!-- 指令下发 -->
		<div>
			<el-dialog title="指令下发" center v-model="cmdVisible" width="50%" show-close>
                <!--
				<el-row :gutter="24">
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>环境：{{ env_name }}</span>
					</el-col>
    				<el-col :span="6"><div class="grid-content ep-bg-purple" />
						<span>应用：{{ app_name }}</span>
					</el-col>
					<el-col :span="5"><div class="grid-content ep-bg-purple" />
						<el-form-item label="选择实例：">
                        	<el-select v-model="pod" @change="getYaml(null)" placeholder="请选择" filterable clearable>
                            	<el-option v-for="item in podOptions" :key="item" :label="item" :value="item">
                            	</el-option>
                        	</el-select>
                		</el-form-item>
					</el-col>
  				</el-row>
                -->

                <div style="height: 300px; width: 100%">
                    <Codemirror 
                        class="code" 
                        v-model="cmdInput" 
                        :style="{ height: '100%'}" 
                        :extensions="extensions" 
                        :autofocus="true"
                        :disabled="false"/>
                </div>
            </el-dialog>
        </div>

	</div>
</template>
<script setup name="MediaList">
import { ref, reactive  } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { getMediaListApi, getEnvTrunkTerminalListApi, stopMediaApi} from '@/api/modules/trunkCenter.js';
import { ElMessage } from 'element-plus';

import { Codemirror } from "vue-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { oneDark } from "@codemirror/theme-one-dark";


// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认值为不存在的环境
	//"env_name": 'aaa',
	"pageNum": 1,
	"pageSize": 20
});


const selectEnv = (item) => {
    initParam.env_name = item.env_name
    return {"code": 200, "data": ""}
}

// 下发指令
const extensions = [javascript(), oneDark];
const cmdVisible = ref(false);
const cmdInput = ref('');
const cmdRun = async (item) => {
    cmdVisible.value = true;
    cmdInput.value = "请输入指令内容"

    return


    const trunk_numbers = [item['trunk_number']];
	const env_name = item["env_name"];
	const ssrc = item["ssrc"];

    const params = {env_name, trunk_numbers, ssrc}
    const res = await stopMediaApi(params);
    const { code, message } = res
    if(code == 200 && message == "OK") {
        ElMessage.success('停止推流成功！')
    }else{
		console.log(message)
        ElMessage.error('停止推流失败：' + message)
    }
}


// 表格配置项
const columns = [
	{
		prop: "env_name",
		label: "环境",
		search: true,
		searchType: "select",
		enum: getEnvTrunkTerminalListApi,
		searchProps: { label: "label", value: "env_name" },
        changeProps: { api: selectEnv}
	},
	{ 
	    prop: "trunk_number", 
	    label: "设备编号",
        sortable: true
	},
	{
        type: "button",
		prop: "ssrc",
		label: "下发指令",
        action: cmdRun
	}
];

</script>

