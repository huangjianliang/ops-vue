<!-- 应用列表 -->

<template>
	<div class="main-box">
		<div>
			<el-button type="primary" @click="showAddItem">新增</el-button>
		</div>

		<div>
			<el-dialog title="新增配置项" center v-model="isShowAddDialog" width="30%">
				<el-input v-model="item_key" placeholder="请输入配置项名称" />
				<el-input v-model="key_describe" placeholder="请输入配置项描述" />
				<el-button @click="isShowAddDialog = false">取消</el-button>
				<el-button type="primary" @click="itemAdd">确认</el-button>
			</el-dialog>
		</div>

		<div class="table-box">
			<ProTable ref="proTable" :columns="columns" :requestApi="itemListApi" resetLabel="刷新" :initParam="initParam"></ProTable>
		</div>
	</div>

</template>
<script setup name="Item">
import { ref, reactive } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { itemListApi, itemAddApi } from '@/api/modules/configCenter.js';
import { ElMessage } from 'element-plus';

// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认值为不存在的环境
	//"env_name": 'aaa',
	"pageNum": 1,
	"pageSize": 100
});

const isShowAddDialog = ref(false);
const item_key = ref('');
const key_describe = ref('');

// 新增配置项
const showAddItem = () => {
	isShowAddDialog.value = true;
};

const itemAdd = async () => {
	if (item_key.value === '') {
		ElMessage.warning("配置项不能为空！");
		return;
	}
	try {
		var params = { item_key: item_key.value, key_describe: key_describe.value }
		const res = await itemAddApi(params);
		const { code, data, message } = res;
		if (code === 200) {
			ElMessage.success("配置项添加成功！");
			isShowAddDialog.value = false;
		} else {
			ElMessage.error("配置项添加失败！" + message);
		}
	} catch (error) {
		throw new Error(error);
	}
};

// 表格配置项
const columns = [
	{
		prop: "item_key",
		label: "配置项",
		clip: true
	},
	{
		prop: "key_describe",
		label: "描述"
	},
	{
		prop: "UpdatedAt",
		label: "修改时间"
	}
];

</script>

