<template>
	<div class="main-box">
		<div class="table-box">
			<ProTable ref="proTable" :addShow="true" :add="tempAddShow" :columns="columns" :requestApi="tempListApi" resetLabel="重置" :initParam="initParam"></ProTable>
		</div>

		<div>
        	<el-dialog title="新增模板" center v-model="tempAddIsShow" width="30%">
				<el-select v-model="app_name" placeholder="应用" filterable clearable>
        		        <el-option v-for="item in apps" :key="item.label" :label="item.app_name" :value="item.app_name">
        		        </el-option>
        		</el-select>
				<el-select v-model="model_type" placeholder="model_type" filterable clearable>
        		        <el-option v-for="item in modelList" :key="item.label" :label="item.label" :value="item.model_type">
        		        </el-option>
        		</el-select>
				<el-select v-model="effactive_range" v-if="model_type == 2" multiple placeholder="环境" filterable clearable>
        		        <el-option v-for="item in envOptions" :key="item.label" :label="item.env_name" :value="item.env_name">
        		        </el-option>
        		</el-select>
				<el-input v-model="data_id" placeholder="data_id" />
				<el-input v-model="group_id" placeholder="group_id" />
				<div style="height: 400px; width: 100%">
						<Codemirror 
        		        	class="code" 
        		        	v-model="model_content" 
        		        	:style="{ height: '100%'}" 
        		        	:extensions="extensions" 
        		        	:autofocus="true"
        		        	:disabled="false"/>
				</div>
				<el-button @click="tempAddIsShow = false">取消</el-button>
        		<el-button type="primary" @click="tempAdd">确认</el-button>
        	</el-dialog>
    	</div>

		<div>
        	<el-dialog title="模板查看" center v-model="viewTempIsShow" width="50%">
				<div style="height: 600px; width: 100%">
        			<Codemirror 
        			    class="code" 
        			    v-model="TempContent" 
        				:style="{ height: '100%'}" 
        				:extensions="extensions" 
        				:autofocus="true"
        				:disabled="false"/>
            	</div>
				<el-button @click="viewTempIsShow = false">取消</el-button>
        		<el-button type="primary" @click="tempUpdate">确认</el-button>
        	</el-dialog>
    	</div>

		<div>
        	<el-dialog title="预览" center v-model="renderTempIsShow" width="50%">
				<el-select v-model="env_name" placeholder="环境" filterable clearable @change=renderTemp>
        		        	<el-option v-for="item in envOptions" :key="item.label" :label="item.env_name" :value="item.env_name">
        		        	</el-option>
        		</el-select>
				<el-button @click="renderTempIsShow = false">取消</el-button>
				<div style="height: 600px; width: 100%">
        		    <Codemirror 
        		        class="code" 
        		        v-model="renderTempContent" 
        		        :style="{ height: '100%'}" 
        		        :extensions="extensions" 
        		        :autofocus="true"
        		        :disabled="true"/>
        		</div>
        	</el-dialog>
    	</div>
	</div>
</template>

<script setup name="Temp">
import { ref, reactive, onMounted } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { tempListApi, tempAddApi, dataIdListApi, modelTypeListApi} from '@/api/modules/configCenter.js';
import { applyReleaseListApi, getEnvByPermListApi } from '@/api/modules/releaseCenter';

import { ElMessage } from 'element-plus';
import { Codemirror } from "vue-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { oneDark } from "@codemirror/theme-one-dark";


// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	"pageNum": 1,
	"pageSize": 20
});

onMounted(() => {
    getEnvList();
});

// 获取环境列表数据
const envOptions = ref([]);
const getEnvList = async () => {
    const params = { "permission": "log" };
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
			return res;
        }
    } catch (error) {
        throw new Error(error);
    }
};

const selectApp = (item) => {
    initParam.app_name = item.app_name
    return {"code": 200, "data": ""}
}

const selectDataId = (item) => {
    initParam.data_id = item.data_id
    return {"code": 200, "data": ""}
}

const selectModelType = (item) => {
    initParam.model_type = item.model_type
    return {"code": 200, "data": ""}
}

// 新增字典
const tempAddIsShow = ref(false);
const data_id = ref('');
const group_id = ref('');
const model_content = ref('');
const app_name = ref('');
const model_type = ref('');
const effactive_range = ref([]);

const tempAddShow = async () => {
	tempAddIsShow.value = true
};

const tempAdd = async () => {
    try {
		var params = {"app_name": app_name.value, "data_id": data_id.value, "group_id": group_id.value, "model_content": model_content.value, "model_type": model_type.value, "effactive_range": effactive_range.value.join()}
        const res = await tempAddApi(params);
        const { code } = res;
        if (code === 200) {
			ElMessage.success("添加模板成功！");
			initParam.app_name = app_name.value;
			initParam.data_id = data_id.value;
			tempAddIsShow.value = false;
        }else{
			ElMessage.error("添加模板失败！" + message);
		}
    } catch (error) {
        throw new Error(error);
    }
};

const tempUpdate = async () => {
    try {
		var params = {"app_name": TempItem.value['app_name'], "data_id": TempItem.value['data_id'], "group_id": TempItem.value['group_id'], "model_content": TempContent.value, "model_type": TempItem.value['model_type'], "effactive_range": TempItem.value['effactive_range']}
        const res = await tempAddApi(params);
        const { code } = res;
        if (code === 200) {
			ElMessage.success("更新模板成功！");
			initParam.app_name = TempItem.value['app_name'];
			initParam.data_id = TempItem.value['data_id'];
			viewTempIsShow.value = false;
        }else{
			ElMessage.error("添加模板失败！" + message);
		}
    } catch (error) {
        throw new Error(error);
    }
};

// 获取应用列表
const apps = ref({});
const getApplyList = async () => {
    try {
        const res = await applyReleaseListApi();
		apps.value = res['data'];
        return res
    } catch (error) {
        throw new Error(error);
    }    
};

// 获取 data_id 列表
const dataIdList = async () => {
    try {
		var params = {"pageNum": 1, "pageSize": 200, "app_name": initParam.app_name}
        const res = await dataIdListApi(params);
		return res;
    } catch (error) {
        throw new Error(error);
    }
};

// 获取 model_type 列表
const modelList = ref({})
const modelTypeList = async () => {
    try {
		var params = {"pageNum": 1, "pageSize": 200}
        const res = await modelTypeListApi(params);
		modelList.value = res['data'];
		return res;
    } catch (error) {
        throw new Error(error);
    }
};

// 查看 temp 内容
const extensions = [javascript(), oneDark];
const viewTempIsShow = ref(false);
const TempContent = ref('');
const TempItem = ref({});
const viewTemp = async (item) => {
	TempItem.value = item;
	viewTempIsShow.value = true;
	TempContent.value = item.content;
};

// 预览
const env_name = ref('');
const renderTempIsShow = ref(false);
const renderTempContent = ref('');
const renderItem = ref({});
const showrRenderTemp = async (item) => {
	renderTempIsShow.value = true;
	renderItem.value = item;
	renderTempContent.value = '';
	env_name.value = '';
};

const renderTemp = async () => {
	try {
		var params = renderItem.value;
		params["env_name"] = env_name.value;
		params["is_rander"] = true;
        const res = await tempListApi(params);
		renderTempContent.value = res['data']['dataList'][0]['content'];
    } catch (error) {
        throw new Error(error);
    }
};

// 表格配置项
const columns = [
	{
		prop: "app_name",
		label: "应用",
		search: true,
		searchType: "select",
		enum: getApplyList,
		searchProps: { label: "label", value: "app_name" },
        changeProps: { api: selectApp},
		clip: true
	},
	{ 
	    prop: "data_id", 
		label: "data_id",
		search: true,
		enum: dataIdList,
		searchProps: { label: "label", value: "data_id" },
		searchType: "select",
		changeProps: { api: selectDataId},
		linkValue: '',
		clip: true
	},
	{ 
	    prop: "group_id", 
		label: "group_id",
		clip: true
	},
	{ 
	    prop: "model_version", 
		label: "model_version",
		clip: true
	},
	{ 
	    prop: "model_type", 
		label: "model_type",
		search: true,
		enum: modelTypeList,
		searchProps: { label: "label", value: "model_type" },
		searchType: "select",
		changeProps: { api: selectModelType},
		clip: true
	},
	{
		prop: "model_type_show",
		label: "model_type_show"
	},
	{
		prop: "effactive_range",
		label: "生效范围"
	},
	{
		prop: "modifier",
		label: "修改者"
	},
	{
		prop: "CreatedAt",
		label: "创建时间"
	},
	{
		prop: "UpdatedAt",
		label: "修改时间"
	},
	{
		type: "button",
		prop: "content",
		label: "查看",
		action: viewTemp
	},
	{
		type: "button",
		prop: "content",
		label: "预览",
		action: showrRenderTemp
	}
];

</script>

