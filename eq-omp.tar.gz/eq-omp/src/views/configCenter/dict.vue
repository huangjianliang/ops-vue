<!-- 应用列表 -->

<template>
	<div class="main-box">
		<div class="table-box">
			<ProTable ref="proTable" :addShow="true" :add="dictAddShow" :columns="columns" :requestApi="dictListApi" resetLabel="重置" :initParam="initParam"></ProTable>
		</div>

		<div>
        	<el-dialog title="新增配置字典" center v-model="dictAddIsShow" width="30%">
				<el-select v-model="env_name" placeholder="环境" filterable clearable>
                	<el-option v-for="item in envOptions" :key="item.label" :label="item.label" :value="item.label">
                	</el-option>
            	</el-select>
				<el-select v-model="key" placeholder="配置项" filterable clearable>
                	<el-option v-for="item in keyList" :key="item.label" :label="item.label" :value="item.label">
                	</el-option>
            	</el-select>
				<el-input v-model="key_value" placeholder="VALUE" />
				<el-input v-model="key_describe" placeholder="描述" />
				<el-button @click="dictAddIsShow = false">取消</el-button>
        		<el-button type="primary" @click="dictAdd">确认</el-button>
        	</el-dialog>
		</div>
    </div>

</template>

<script setup name="Dict">
import { ref, reactive, onMounted } from "vue";
import ProTable from "@/components/ProTable/index.vue";
import { itemListApi, dictListApi, dictAddApi} from '@/api/modules/configCenter.js';
import { getEnvByPermListApi } from '@/api/modules/releaseCenter';
import { ElMessage } from 'element-plus';


// 获取 ProTable 元素，调用其获取刷新数据方法（还能获取到当前查询参数，方便导出携带参数）
const proTable = ref();

// 如果表格需要初始化请求参数，直接定义传给 ProTable(之后每次请求都会自动带上该参数，此参数更改之后也会一直带上，改变此参数会自动刷新表格数据)
const initParam = reactive({
	// 默认值为不存在的环境
	//"env_name": 'aaa',
	"env_name": "",
	"item_key": "",
	"pageNum": 1,
	"pageSize": 20
});

//onMounted(() => {
//    getEnvList();
//});

// 获取环境列表数据
const envOptions = ref([]);
const getEnvList = async () => {
    const params = { "permission": "log" };
    try {
        const res = await getEnvByPermListApi(params);
        const { code, data } = res;
        if (code === 200 && data) {
            envOptions.value = data;
			return res;
        }
    } catch (error) {
        throw new Error(error);
    }
};

const selectEnv = (item) => {
    initParam.env_name = item.env_name
    return {"code": 200, "data": ""}
}

const selectItem = (item) => {
    initParam.item_key = item.item_key
    return {"code": 200, "data": ""}
}

// 新增字典
const dictAddIsShow = ref(false);
const key_value = ref('');
const key_describe = ref('');

const dictAddShow = async () => {
	dictAddIsShow.value = true
};

// 获取配置项列表
const keyList = ref([]);
const itemList = async () => {
    try {
		var params = {"pageNum": 1, "pageSize": 200}
        const res = await itemListApi(params);
        const { code, data, message } = res;
        if (code === 200) {
			for(var i = 0; i < data['dataList'].length; i++) {
				keyList.value.push({label: data['dataList'][i]['item_key'], item_key: data['dataList'][i]['item_key']});
			}
			return {code: code, data: keyList.value}
        }else{
			ElMessage.error("获取配置项列表失败！" + message);
		}
    } catch (error) {
        throw new Error(error);
    }
};

// 配置项列表
const env_name = ref('');
const key = ref('');
const dictAdd = async () => {
    try {
		var params = {"env_name": env_name.value, "item_key": key.value, "key_value": key_value.value, "key_describe": key_describe.value}
        const res = await dictAddApi(params);
        const { code } = res;
        if (code === 200) {
			ElMessage.success("添加配置字典成功！");
			initParam.env_name = env_name.value;
			initParam.item_key = key.value;
			dictAddIsShow.value = false;
        }else{
			ElMessage.error("获取配置项列表失败！" + message);
		}
    } catch (error) {
        throw new Error(error);
    }
};

// 表格配置项
const columns = [
	{
		prop: "env_name",
		label: "运行环境",
		search: true,
		searchType: "select",
		enum: getEnvList,
		searchProps: { label: "label", value: "env_name" },
        changeProps: { api: selectEnv}
	},
	{ 
	    prop: "item_key", 
	    label: "配置项",
		search: true,
		enum: itemList,
		searchProps: { label: "label", value: "item_key" },
		searchType: "select",
		changeProps: { api: selectItem},
		clip: true
	},
	{ 
	    prop: "key_value", 
	    label: "内容",
		clip: true
	},
    { 
	    prop: "key_describe", 
	    label: "描述"
	},
	{
		prop: "modifier",
		label: "修改者"
	},
	{
		prop: "CreatedAt",
		label: "创建时间"
	},
	{
		prop: "UpdatedAt",
		label: "修改时间"
	}
];

</script>

