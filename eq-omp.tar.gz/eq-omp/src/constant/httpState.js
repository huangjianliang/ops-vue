/** 请求状态配置 **/

/**
 * 请求状态码配置
 */
export const resultStateMap = {
    SUCCESS: 200,
    ERROR: 500,
    OVERDUE: 400,
    TIMEOUT: 10000,
    TYPE: 'success'
};

/**
 * 请求方法
 */
export const requestMethodMap = {
    GET: "GET",
	POST: "POST",
	PATCH: "PATCH",
	PUT: "PUT",
	DELETE: "DELETE"
};

/**
 * 常用contentType类型
 */
export const contentTypeMap = {
    // json
    JSON: "application/json;charset=UTF-8",
    // text
    TEXT: "text/plain;charset=UTF-8",
    // form-data 一般配合qs
    FORM_URLENCODED: "application/x-www-form-urlencoded;charset=UTF-8",
    // form-data 上传
    FORM_DATA: "multipart/form-data;charset=UTF-8"
};


