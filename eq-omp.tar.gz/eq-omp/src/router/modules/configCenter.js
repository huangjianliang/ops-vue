
// 配置中心模块

const configCenterRouter = [
	{
		path: "/configCenter",
		component: () => import("@/layout/index.vue"),
		redirect: "/configCenter/item",
		meta: {
			title: "配置中心",
			icon: "cheliangzhongxin",
		},
		children: [
			{
				path: "/configCenter/item",
				name: "Item",
				component: () => import("@/views/configCenter/item.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "配置项",
					key: "Item",
					icon: "menu"
				}
			},
			{
				path: "/configCenter/dict",
				name: "Dict",
				component: () => import("@/views/configCenter/dict.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "配置字典",
					key: "Dict",
					icon: "menu"
				}
			},
			{
				path: "/configCenter/temp",
				name: "Temp",
				component: () => import("@/views/configCenter/temp.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "模板",
					key: "Temp",
					icon: "menu"
				}
			}
		]
	}
];

export default configCenterRouter;
