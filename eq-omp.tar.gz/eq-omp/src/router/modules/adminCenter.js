
// 发布中心模块

const adminCenterRouter = [
	{
		path: "/adminCenter",
		component: () => import("@/layout/index.vue"),
		redirect: "/adminCenter/audit",
		meta: {
			title: "系统管理",
			icon: "yingyongzhongxin",
		},
		children: [
			{
				path: "/adminCenter/audit",
				name: "audit",
				component: () => import("@/views/adminCenter/audit.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "审计",
					key: "audit",
					icon: "yingyongliebiao"
				}
			},
		]
	}
];

export default adminCenterRouter;
