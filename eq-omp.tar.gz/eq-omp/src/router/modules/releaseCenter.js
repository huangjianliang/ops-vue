
// 发布中心模块

const releaseCenterRouter = [
	{
		path: "/releaseCenter",
		component: () => import("@/layout/index.vue"),
		redirect: "/releaseCenter/releaseRecord",
		meta: {
			title: "发布中心",
			icon: "fabuzhongxin",
		},
		children: [
			{
				path: "/releaseCenter/releaseRecord",
				name: "ReleaseRecord",
				component: () => import("@/views/releaseCenter/releaseRecord/ReleaseRecord.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "发布记录",
					key: "ReleaseRecord",
					icon: "fabujilu"
				}
			},
			{
				path: "/releaseCenter/applyCompile",
				name: "ApplyCompile",
				component: () => import("@/views/releaseCenter/applyCompile/ApplyCompile.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "应用编译",
					icon: "yingyongbianyi",
					key: "yingyongbianyi"
				}
			},
			{
				path: "/releaseCenter/applyPublish",
				name: "ApplyPublish",
				component: () => import("@/views/releaseCenter/applyPublish/ApplyPublish.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "应用发布",
					key: "ApplyPublish",
					icon: "yingyongfabu"
				}
			},
			{
				path: "/releaseCenter/productManage",
				name: "ProductManage",
				component: () => import("@/views/releaseCenter/productManage/ProductManage.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "制品管理",
					key: "ProductManage",
					icon: "zhipinguanli"
				}
			},
			{
				path: "/releaseCenter/surveyManage/:type?/:business?/:version?/:id?",
				name: "SurveyManage",
				component: () => import("@/views/releaseCenter/surveyManage/SurveyManage.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "提测管理",
					key: "SurveyManage",
					icon: "zhipinguanli"
				}
			}
		]
	}
];

export default releaseCenterRouter;
