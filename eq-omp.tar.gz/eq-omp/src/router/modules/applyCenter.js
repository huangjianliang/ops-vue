
// 发布中心模块

const releaseCenterRouter = [
	{
		path: "/applyCenter",
		component: () => import("@/layout/index.vue"),
		redirect: "/applyCenter/applyList",
		meta: {
			title: "应用中心",
			icon: "yingyongzhongxin",
		},
		children: [
			{
				path: "/applyCenter/applyList",
				name: "ApplyList",
				component: () => import("@/views/applyCenter/applyList/ApplyList.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "应用列表",
					key: "ApplyList",
					icon: "yingyongliebiao"
				}
			},
			{
				path: "/applyCenter/applyOperate",
				name: "ApplyOperate",
				component: () => import("@/views/applyCenter/applyOperate/ApplyOperate.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "应用操作",
					icon: "menu",
					key: "ApplyOperate"
				}
			},
			{
				path: "/applyCenter/applyLog",
				name: "ApplyLog",
				component: () => import("@/views/applyCenter/applyLog/ApplyLog.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "应用日志",
					key: "ApplyLog",
					icon: "yingyongrizhi"
				}
			}
		]
	}
];

export default releaseCenterRouter;
