
// dashboard 模块
const dashboardRouter = [
	{
		path: "/dashboard",
		component: () => import("@/layout/index.vue"),
		redirect: "/dashboard/dataVisualize",
		meta: {
			title: "Dashboard"
		},
		children: [
			{
				path: "/dashboard/siteNavigate",
				name: "siteNavigate",
				component: () => import("@/views/dashboard/siteNavigate/index.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "站点导航",
					key: "siteNavigate"
				}
			}
		]
	}
];

export default dashboardRouter;
