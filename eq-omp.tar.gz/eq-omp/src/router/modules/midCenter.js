
// 车辆中心模块

const midCenterRouter = [
	{
		path: "/midCenter",
		component: () => import("@/layout/index.vue"),
		redirect: "/midCenter/kafka",
		meta: {
			title: "基础组件",
			icon: "jichuzujian",
		},
		children: [
			{
				path: "/midCenter/kafka",
				name: "Kafka",
				component: () => import("@/views/midCenter/kafka.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "Kafka",
					key: "Kafka",
					icon: "KAFKA"
				}
			},
			{
				path: "/midCenter/redis",
				name: "Redis",
				component: () => import("@/views/midCenter/redis.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "Redis",
					key: "Redis",
					icon: "REDIS"
				}
			},
			{
				path: "/midCenter/pg",
				name: "PGSQL",
				component: () => import("@/views/midCenter/pg.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "PGSQL",
					key: "PGSQL",
					icon: "PGSQL"
				}
			}
		]
	}
];

export default midCenterRouter;
