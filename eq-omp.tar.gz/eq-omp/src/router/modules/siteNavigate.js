
// 站点导航模块
const homeRouter = [
    {
		path: "/siteNavigate",
		component: () => import("@/layout/index.vue"),
		redirect: "/siteNavigate/index",
		children: [
			{
				path: "/home",
				name: "home",
				component: () => import("@/views/home/Home.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "首页",
					key: "shouye",
					icon: 'shouye'
				}
			}
		]
	}
];

export default homeRouter;