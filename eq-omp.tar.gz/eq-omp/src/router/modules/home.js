
// 首页模块
const homeRouter = [
    {
		path: "/home",
		component: () => import("@/layout/index.vue"),
		redirect: "/home",
		children: [
			{
				path: "/home",
				name: "Home",
				component: () => import("@/views/home/Home.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "首页",
					key: "Home"
				}
			}
		]
	}
];

export default homeRouter;