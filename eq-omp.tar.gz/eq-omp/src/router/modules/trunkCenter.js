
// 车辆中心模块

const trunkCenterRouter = [
	{
		path: "/trunkCenter",
		component: () => import("@/layout/index.vue"),
		redirect: "/trunkCenter/trunkList",
		meta: {
			title: "车辆中心",
			icon: "cheliangzhongxin",
		},
		children: [
			{
				path: "/trunkCenter/trunkList",
				name: "TrunkList",
				component: () => import("@/views/trunkCenter/trunkList/TrunkList.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "车辆列表",
					key: "TrunkList",
					icon: "cheliangliebiao"
				}
			},
			{
				path: "/trunkCenter/TrunkTerm/:type?/:env_name?/:device?/:trunk_number?",
				name: "TrunkTerm",
				component: () => import("@/views/trunkCenter/trunkList/TrunkTerm.vue"),
				meta: {
					keepAlive: true,
					requiresAuth: true,
					title: "车辆终端",
					key: "TrunkTerm",
					icon: "cheliangliebiao"
				}
			},
			{
				path: "/trunkCenter/networkMonitor",
				name: "NetworkMonitor",
				component: () => import("@/views/trunkCenter/networkMonitor/NetworkMonitor.vue"),
				meta: {
					keepAlive: false,
					requiresAuth: true,
					title: "网络监控",
					key: "NetworkMonitor",
					icon: "menu"
				}
			},
			//{
			//	path: "/trunkCenter/flow",
			//	name: "flow",
			//	component: () => import("@/views/trunkCenter/flow.vue"),
			//	meta: {
			//		keepAlive: false,
			//		requiresAuth: true,
			//		title: "流量统计",
			//		key: "flow",
			//		icon: "menu"
			//	}
			//},
			{
				path: "/trunkCenter/BaseMonitor",
				name: "BaseMonitor",
				component: () => import("@/views/trunkCenter/BaseMonitor.vue"),
				meta: {
					keepAlive: false,
					requiresAuth: true,
					title: "基站监控",
					key: "BaseMonitor",
					icon: "menu"
				}
			},
			//{
			//	path: "/trunkCenter/Android",
			//	name: "Android",
			//	component: () => import("@/views/trunkCenter/Android.vue"),
			//	meta: {
			//		keepAlive: true,
			//		requiresAuth: true,
			//		title: "辅助设备",
			//		key: "Android",
			//		icon: "cheliangliebiao"
			//	}
			//},
			{
				path: "/trunkCenter/RtkList",
				name: "RtkList",
				component: () => import("@/views/trunkCenter/RtkList.vue"),
				meta: {
					keepAlive: false,
					requiresAuth: true,
					title: "RTK 基站",
					key: "RtkList",
					icon: "menu"
				}
			},
			{
				path: "/trunkCenter/MediaList",
				name: "MediaList",
				component: () => import("@/views/trunkCenter/MediaList.vue"),
				meta: {
					keepAlive: false,
					requiresAuth: true,
					title: "流媒体",
					key: "MediaList",
					icon: "menu"
				}
			}
		]
	}
];

export default trunkCenterRouter;
