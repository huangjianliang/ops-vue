
L.AnimateMarker = L.Marker.extend({
    options: {
        isZooming: false,
        autoStart: false,
        isAnimate: false     // 是否正在运行
    },
    
    initialize: function (markerData, options) {
        const {lat, lng} = markerData;
        L.Marker.prototype.initialize.call(this, [lat, lng], options);
        
        Object.assign(this.options, options);
        this.isZooming = false;
        
        this.startData = markerData;
        this.resetIcon();
    },
    
    onAdd: function (map) {
        this.map = map;
        L.Marker.prototype.onAdd.call(this, map);
        
        map.addEventListener('zoomstart', () => {
            this.isZooming = true;
        });
        
        map.addEventListener('zoomend', () => {
            this.isZooming = false;
        });
    },
    
    resetIcon: function () {
        const v = this;
		let iconOption = v.options.icon.options;
		let Icon = L.DivIcon.extend({
			createIcon: function () {
				let outerDiv = document.createElement("div");
				outerDiv.style.width = iconOption.iconSize[0] + "px";
				outerDiv.style.height = iconOption.iconSize[1] + "px";
				outerDiv.style.position = "absolute";
				
				v.div = document.createElement("div");
				v.div.style.width = iconOption.iconSize[0] + "px";
				v.div.style.height = iconOption.iconSize[1] + "px";
				v.div.style.transition = "transform linear 100ms";
				v.div.style.transformOrigin = "center";
				// v.div.style.transform = "translate3d(-" + iconOption.iconAnchor[0] + "px, -" + iconOption.iconAnchor[0] + "px, 0) rotate(-" + v.startData.bearing + "deg)";
				v.div.style.transform = `rotate(${v.startData.bearing}deg)`;
				v.div.style.marginLeft = `-${iconOption.iconSize[0] / 2}px`;
				v.div.style.marginTop = `-${iconOption.iconSize[1] / 2}px`;
				
				const img = document.createElement("img");
				img.src = iconOption.iconUrl;
				img.width = iconOption.iconSize[0];
				img.height = iconOption.iconSize[1];
				
				v.div.appendChild(img);
				outerDiv.appendChild(v.div);
				return outerDiv;
			},
			rotate(deg, delta=0) {
				if (v.before && Math.abs(v.before - deg) >= 180) {
					v.div.style.transition = "none";
				} else {
					v.div.style.transition = `all linear ${delta}s`;
				}
				// v.div.style.transform = "translate3d(-19px, -13px, 0) rotate(-" + deg + "deg)";
				v.div.style.transform = `rotate(${deg}deg)`;
				v.before = deg;
			},
			iconSize: iconOption.iconSize,
		});
		this.icon = new Icon();
		this.setIcon(this.icon);
    },
    
    updateIcon: function (markerData, options) {
        Object.assign(this.options, options);
        this.startData = markerData;
        this.resetIcon();
    },
    
    /**
     * 更新marker状态
     * @param {*} endData 
     */
    updateState(endData){
        this.isAnimate && this.stopAnimate();
        // if(this.isAnimate) return;
        this.startTime =  Date.now();
        this.endData = endData;
        this.icon.rotate(endData.bearing);
        this.animate();
    },
    
    /**
     * 停止动画
     */
    stopAnimate: function () {
        const {lat, lng} = this.endData;
        this.isAnimate = false;
        this.startData = this.endData;
        this.setLatLng({ lat, lng });
    },
    
    animate: function () {
        const { lat, lng } = this.endData;
       
        // this.isAnimate = true;
        // const nowTime = Date.now();
        // const endTime = this.startTime + this.endData.duration;
        // const t = nowTime - this.startTime;
        
        // const lat = this.startData.lat + ((this.endData.lat - this.startData.lat) / this.endData.duration) * t;
        // const lng = this.startData.lng + ((this.endData.lng - this.startData.lng) / this.endData.duration) * t;
        
        
        
        // this.setLatLng({ lat, lng });
        
        // if(nowTime < endTime && this.isAnimate){
        //     requestAnimationFrame(this.animate.bind(this));
        // }else{
        //     this.startData = this.endData;
        //     this.isAnimate = false;
        // }
    }
});

L.animatedMarker = function (latlngs, options) {
    return new L.AnimateMarker(latlngs, options);
};