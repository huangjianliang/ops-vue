import { computed, onBeforeMount } from "vue";
import { useGlobalStore } from "@/store";

/**
 * @description 切换主题
 * */
export const useTheme = () => {
	const globalStore = useGlobalStore();
	const themeConfig = computed(() => globalStore.themeConfig);

	// 切换暗黑模式
	const switchDark = () => {
		const body = document.documentElement;
		if (themeConfig.value.isDark) body.setAttribute("class", "dark");
		else body.setAttribute("class", "");
	};

	
	onBeforeMount(() => {
		switchDark();
	});

	return {
		switchDark
	};
};
