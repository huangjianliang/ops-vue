const toString = Object.prototype.toString;

/**
 * @description 判断值是否为某个类型
 * @param {*} val 
 * @param {*} type 
 * @returns 
 */
export const is = (val, type) => {
    return toString.call(val) === `[object ${type}]`;
};

/**
 * @description 是否为函数
 * @param {*} val 
 * @returns 
 */
export const isFunction = (val) => {
    return is(val, "Function");
};

/**
 * @description:  是否为数组
 * @param {*} val 
 */
export const isArray = (val) => {
	return val && Array.isArray(val);
};