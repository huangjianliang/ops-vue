import { isArray } from "@/utils/is";
import { now } from "@vueuse/core";

/**
 * @description 获取localStorage
 * @param {String} key Storage名称
 * @return string
 */
// export function localGet(key: string) {
// 	const value = window.localStorage.getItem(key);
// 	try {
// 		return JSON.parse(window.localStorage.getItem(key) as string);
// 	} catch (error) {
// 		return value;
// 	}
// }

/**
 * @description 存储localStorage
 * @param {String} key Storage名称
 * @param {Any} value Storage值
 * @return void
 */
// export function localSet(key: string, value: any) {
// 	window.localStorage.setItem(key, JSON.stringify(value));
// }

/**
 * @description 清除localStorage
 * @param {String} key Storage名称
 * @return void
 */
// export function localRemove(key: string) {
// 	window.localStorage.removeItem(key);
// }

/**
 * @description 清除所有localStorage
 * @return void
 */
// export function localClear() {
// 	window.localStorage.clear();
// }

/**
 * @description 对象数组深克隆
 * @param {Object} obj 源对象
 * @return object
 */
// export function deepCopy<T>(obj: any): T {
// 	let newObj: any;
// 	try {
// 		newObj = obj.push ? [] : {};
// 	} catch (error) {
// 		newObj = {};
// 	}
// 	for (let attr in obj) {
// 		if (typeof obj[attr] === "object") {
// 			newObj[attr] = deepCopy(obj[attr]);
// 		} else {
// 			newObj[attr] = obj[attr];
// 		}
// 	}
// 	return newObj;
// }

/**
 * @description 判断数据类型
 * @param {Any} val 需要判断类型的数据
 * @return string
 */
// export function isType(val: any) {
// 	if (val === null) return "null";
// 	if (typeof val !== "object") return typeof val;
// 	else return Object.prototype.toString.call(val).slice(8, -1).toLocaleLowerCase();
// }

/**
 * @description 生成随机数
 * @param {Number} min 最小值
 * @param {Number} max 最大值
 * @return number
 */
// export function randomNum(min: number, max: number): number {
// 	let num = Math.floor(Math.random() * (min - max) + max);
// 	return num;
// }

/**
 * @description 获取当前时间
 * @return string
 */
export const getTimeState = () => {
	// 获取当前时间
	let timeNow = new Date();
	// 获取当前小时
	let hours = timeNow.getHours();
	// 判断当前时间段
	if (hours >= 6 && hours <= 10) return `早上好 ⛅`;
	if (hours >= 10 && hours <= 14) return `中午好 🌞`;
	if (hours >= 14 && hours <= 18) return `下午好 🌞`;
	if (hours >= 18 && hours <= 24) return `晚上好 🌛`;
	if (hours >= 0 && hours <= 6) return `凌晨好 🌛`;
};

/**
 * @description 获取浏览器默认语言
 * @return string
 */
// export function getBrowserLang() {
// 	let browserLang = navigator.language ? navigator.language : navigator.browserLanguage;
// 	let defaultBrowserLang = "";
// 	if (browserLang.toLowerCase() === "cn" || browserLang.toLowerCase() === "zh" || browserLang.toLowerCase() === "zh-cn") {
// 		defaultBrowserLang = "zh";
// 	} else {
// 		defaultBrowserLang = "en";
// 	}
// 	return defaultBrowserLang;
// }

/**
 * @description 递归查询当前路由所对应的路由
 * @param {Array} menuList 菜单列表
 * @param {String} path 当前地址
 * @return array
 */
// export function getTabPane<T, U>(menuList: any[], path: U): T {
// 	let result: any;
// 	for (let item of menuList || []) {
// 		if (item.path === path) result = item;
// 		const res = getTabPane(item.children, path);
// 		if (res) result = res;
// 	}
// 	return result;
// }

/**
 * @description 使用递归处理路由菜单，生成一维数组
 * @param {Array} menuList 所有菜单列表
 * @param {Array} newArr 菜单的一维数组
 * @return array
 */
// export function handleRouter(routerList: Menu.MenuOptions[], newArr: string[] = []) {
// 	routerList.forEach((item: Menu.MenuOptions) => {
// 		typeof item === "object" && item.path && newArr.push(item.path);
// 		item.children && item.children.length && handleRouter(item.children, newArr);
// 	});
// 	return newArr;
// }

/**
 * @description 扁平化数组对象
 * @param {Array} arr 数组对象
 * @return array
 */
export function getFlatArr(arr) {
	return arr.reduce((pre, current) => {
		let flatArr = [...pre, current];
		if (current.children) flatArr = [...flatArr, ...getFlatArr(current.children)];
		return flatArr;
	}, []);
}

/**
 * @description 格式化表格单元格默认值
 * @param {Number} row 行
 * @param {Number} col 列
 * @param {String} callValue 当前单元格值
 * @return string
 * */
// export function defaultFormat(row: number, col: number, callValue: any) {
// 	// 如果当前值为数组,使用 / 拼接（根据需求自定义）
// 	if (isArray(callValue)) return callValue.length ? callValue.join(" / ") : "--";
// 	return callValue ?? "--";
// }

/**
 * @description 处理无数据情况
 * @param {String} callValue 需要处理的值
 * @return string
 * */
export function formatValue(callValue) {
	// 如果当前值为数组,使用 / 拼接（根据需求自定义）
	if (isArray(callValue)) return callValue.length ? callValue.join(" / ") : "--";
	return callValue ?? "--";
}

/**
 * @description 根据枚举列表查询当需要的数据（如果指定了 label 和 value 的 key值，会自动识别格式化）
 * @param {String} callValue 当前单元格值
 * @param {Array} enumData 枚举列表
 * @param {String} type 过滤类型（目前只有 tag）
 * @return string
 * */
export function filterEnum(callValue, enumData, searchProps, type) {
	const value = searchProps?.value ?? "value";
	const label = searchProps?.label ?? "label";
	let filterData = {};
	if (Array.isArray(enumData)) filterData = enumData.find((item) => item[value] === callValue);
	if (type == "tag") return filterData?.tagType ? filterData.tagType : "";
	return filterData ? filterData[label] : "--";
}

/**
 * 获取当前时间  YYYY-MM-DD HH:mm:ss
 */
export function getNowDate() {
	const nowDate = new Date();
	const date = {
		year: nowDate.getFullYear(),
		month: nowDate.getMonth() + 1,
		day: nowDate.getDate(),
		hours: nowDate.getHours(),
		minutes: nowDate.getMinutes(),
		seconds: nowDate.getSeconds()
	};
	
	const newmonth = date.month < 10 ? "0" + date.month : date.month;
    const newday = date.day < 10 ? "0" + date.day : date.day;
    const newHours = date.hours < 10? "0" + date.hours : date.hours;
    const newminutes = date.minutes < 10 ? "0" + date.minutes : date.minutes;
    const newseconds = date.seconds < 10 ? "0" + date.seconds : date.seconds;

	return {
		year: date.year,
		month: newmonth,
		day: newday,
		hour: date.hours,
		minute: newminutes,
		second: newseconds
	};
}

/**
 * 根据时间戳获取时间
 */
export function getTimeFromStamp(stamp) {
	let date = new Date(stamp)
    let Y = date.getFullYear() + '-'
    let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
    let D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' '
    let h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':'
    let m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':'
    let s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds())
    return Y + M + D + h + m + s;
}
