import kuangkaBatteryHeavy from '@/assets/images/map/kuangka-battery-heavy.png';
import pointPng from '@/assets/images/map/point.png';
import { iconSizeMap } from '@/constant/icon';

/**
 * 添加车辆图标
 * @param {*} map 
 * @param {*} data 
 * @param {*} vehicleMarkerMap 
 */
export const addVehicleMarker = (map, data, vehicleMarkerMap) => {
    const { lng, lat } = data;
    
    const latlng = [lat, lng];
    const zoom = map.getZoom();
    const myIcon = getIcon(zoom);
    
    const marker = new L.animatedMarker({ lat, lng, bearing: 0 }, {
        icon: myIcon
    }).addTo(map);
    
    vehicleMarkerMap = {
        'marker': marker,
        'time': new Date().getTime(),
        'moveFn': new L.PosAnimation()
    };
    
    return vehicleMarkerMap;
};

/**
 * 更新车辆图标
 
 * @param {*} map 
 * @param {*} data 
 * @param {*} vehicleMarkerMap 
 */
export const updateVehicleMarker = (map, data, vehicleMarkerMap) => {
    const { lng, lat } = data;
    
    if(!vehicleMarkerMap['marker']){
        vehicleMarkerMap = addVehicleMarker(map, data, vehicleMarkerMap);
    }else{
        const now = new Date().getTime();
        const { time, moveFn, marker } = vehicleMarkerMap;
        const delta = (now - time) / 1000;
        let catchTranstion = "all " + delta + "s linear";
        
        vehicleMarkerMap['time'] = now;
        marker._icon.style[L.DomUtil.TRANSITION] = catchTranstion;
        // marker.icon.rotate(e3005, delta);
        marker.setLatLng([lat, lng]);
    }
    return vehicleMarkerMap;
};

/**
 * 隐藏车辆图标
 * @param {*} vehicleMarkerMap 
 */
export const hideVehicleMarker = (vehicleMarkerMap) => {
    if(!vehicleMarkerMap['marker']) return;
    
    vehicleMarkerMap['marker']._icon.style[L.DomUtil.TRANSITION] = 'none';
    vehicleMarkerMap['marker'].setOpacity(0);
};

/**
 * 显示车辆图标
 * @param {*} vehicleMarkerMap 
 */
export const showVehicleMarker = (vehicleMarkerMap) => {
    if(!vehicleMarkerMap['marker']) return;
    
    vehicleMarkerMap['marker']._icon.style[L.DomUtil.TRANSITION] = "all" + 1000 + "ms linear";
    vehicleMarkerMap['marker'].setOpacity(1);
};

/**
 * 更新车辆图标大小
 * @param {*} map 
 * @param {*} vehicleMarkerMap 
 * @param {*} realtimeData 
 */
export const updateVehicleMarkerSize = (map, vehicleMarkerMap, realtimeData) => {
    if(!vehicleMarkerMap['marker']) return;
    
    const myIcon = getIcon(map.getZoom());
    const markerData = { lat: realtimeData[0], lng: realtimeData[1], bearing: 0 };
    vehicleMarkerMap['marker'].updateIcon(markerData, {icon: myIcon});
};

/**
 * 获取marker icon
 * @param {*} zoom 
 * @returns 
 */
export const getIcon = (zoom) => {
    // const { w, h } = iconSizeMap[zoom];
    // const myIcon = L.icon({
    //     iconSize: [w, h],
    //     iconUrl: kuangkaBatteryHeavy
    // });
    
    const myIcon1 = L.icon({
        iconUrl: pointPng,
        iconSize: [30, 30]
    });
    
    return myIcon;
};