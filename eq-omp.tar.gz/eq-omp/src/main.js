import { createApp } from 'vue';
import ElementPlus from 'element-plus';
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import infiniteScroll  from 'vue-infinite-scroll';

import router from './router';
import store from './store';
import App from './App.vue';

// element icons
import * as Icons from "@element-plus/icons-vue";

import 'element-plus/dist/index.css';
// iconfont 
import "@/assets/iconfont/iconfont.scss";
// 字体
import "@/assets/fonts/font.scss";
// 自定义 element css
import '@/styles/element.scss';
// 公共样式
import '@/styles/common.scss';
// 自定义暗黑样式
import '@/styles/element-dark.scss';
// 重置默认样式
import '@/styles/reset.scss';
// import zhLocale from 'element-plus/lib/locale/lang/zh-cn'

import '@/plugin/eq-transtionMarker.js';

const app = createApp(App);

// 注册element Icons组件
Object.keys(Icons).forEach(key => {
	app.component(key, Icons[key]);
});

app.use(store).use(router).use(infiniteScroll ).use(ElementPlus,{
	locale: zhCn,
}).mount('#app')
